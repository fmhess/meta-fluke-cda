/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: usbdescriptor.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#ifndef	__USBDESCRIPTION_H__
#define	__USBDESCRIPTION_H__

#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <unistd.h>

#ifdef __cplusplus
extern "C"
{
#endif
#include <libudev.h>
#ifdef __cplusplus
}
#endif

#include "nrpzmodule.h"
#include "refcnt.h"

#define	DEV_TYPE_LEN	64	// number of character for the device type
#define	DEV_SERIAL_LEN	64	// number of character for the serial id
#define	RESOURCE_ID_LEN	128	// number of character for the resource id descriptor

namespace nrplib
{

class UsbDescriptor : public RefObj, private noncopyable {
public:
 	/**
	 * Constructor
	 */
	 UsbDescriptor(struct udev_device *dev);
 	/**
	 * Destructor
	 */
	~UsbDescriptor();
 	/**
	 * fill the usb descriptor from the data's located in parameter dirname
	 */
	bool isNrpz() const { return m_nrpz; }
	/**
	 * getDeviceName()
	 */
	const char *getDeviceName()
	{
		return udev_device_get_devnode(m_udev);
	}	
 	/**
	 * check if sensor firmware is loaded
	 */
	bool isFirmwareLoaded()
	{
		int		handle;
		bool	mode;

		handle = ::open(getDeviceName(), O_RDWR|O_NONBLOCK);

		if (handle == -1)
			return false;

		mode = !::ioctl(handle, NRPZ_START, 0);

		::close(handle);

		return mode;
	}	
 	/**
	 * check if sensor firmware is ready to communicate
	 */
	bool isDeviceReady()
	{
		int		handle;
		bool	ready;

		handle = ::open(getDeviceName(), O_RDWR|O_NONBLOCK);

		if (handle == -1)
			return false;

		ready = (::ioctl(handle, NRPZ_GETDEVICEREADY, 0) == 1);

		::close(handle);

		return ready;
	}
 	/**
	 * get rescource descriptor
	 */
	char *getResource() { return m_resource; }
 	/**
	 * get sensor type string
	 */
	char *getType() { return m_type; }
 	/**
	 * get vendor id
	 */
	long getVendor() { return m_vendor; }
 	/**
	 * get vendor id
	 */
	long getProduct() { return m_product; }
 	/**
	 * get serial number string
	 */
	char *getSerial() { return m_serial; }
 	/**
	 * get port number
	 */
	int getPort() const { return m_port; }
 	/**
	 * get hub number
	 */
	int getHub() const { return m_hub; }
 	/**
	 * get hub type
	 */
	unsigned long getHubType() { return (m_hubvendor << 16) + m_hubproduct; }
 	/**
	 * get internal device path
	 */
	const char * getDevPath() { return udev_device_get_devpath(m_udev); }
private:
	long			m_minor;					// minor device id
	int				m_hub;						// root hub number
	long			m_port;						// hub port number
	long			m_vendor;					// vendor id
	long			m_product;					// product id
	char			m_type[DEV_TYPE_LEN];		// sensor type
	char			m_serial[DEV_SERIAL_LEN];	// serial number
	char			m_resource[RESOURCE_ID_LEN];// resource name

	long			m_hubvendor;				// hub vendor id
	long			m_hubproduct;				// hub product id

	bool			m_nrpz;						// true if nrpz device
	struct udev_device *	m_udev;				// udev device reference;
};

typedef RefCntPtr<UsbDescriptor>	UsbDescriptorPtr; 

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

