/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: nrpdevlist.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#ifndef	__NRPDEVLIST_H__
#define	__NRPDEVLIST_H__

#include <vector>
#include <list>
#include <set>
#include <string.h>

#include "condition.h"
#include "common.h"
#include "exception.h"
#include "mutex.h"
#include "thread.h"
#include "nrpdevice.h"
#include "usbcallback.h"
#include "sensorcallback.h"

namespace nrplib
{
    
typedef struct {
   unsigned long  vendor;
   unsigned long  product;
   char           serial[64];
   bool           in_use;
   pid_t          pid;
} NrpOpenSensorInfo;

typedef struct {
    bool              init;
    sem_t             sem;
    NrpOpenSensorInfo sensors[128];
} NrpShmData;

class NrpDevList : private noncopyable
{
public:
 	/**
	 * Constructor
	 */
	 NrpDevList();
 	/**
	 * Destructor
	 */
	~NrpDevList();

	UsbCallBack &		deviceChangedCallback() { return m_deviceChangedCallback; }
	SensorCallBack &	dataAvailableCallback() { return m_dataAvailableCallback; }
	SensorCallBack &	commandAcceptedCallback() { return m_commandAcceptedCallback; }
	SensorCallBack &	errorOccurredCallback() { return m_errorOccurredCallback; }
	SensorCallBack &	stateChangedCallback() { return m_stateChangedCallback; }
	SensorCallBack &	stillAliveCallback() { return m_stillAliveCallback; }

	long	getData(long session, long *pBlockType, long *pGroupNr, long *pParamNr);
	long	getFloatArrayLength(long session, long * pSize);
	long	getFloatArray(long session, float *pArray, long arraySize, long *pReadCount);
	long	getFloatResult(long session, float *pFloatVal1, float *pFloatVal2, float *pFloatVal3);
	long	getLongResult(long session, long *pLongVal1, long *pLongVal2, long *pLongVal3);
	long	getBitfieldResult(long session, long *pBitVal1, long *pBitVal2, long *pBitVal3);
	long	getStringResultLength(long session, long * pSize);
	long	getStringResult(long session, char *pBuffer, long size);
	long	getBinaryResultLength(long session, long * pSize);
	long	getBinaryResult(long session, unsigned char *pBuffer, long buflen, long *size);
	long	getAuxFloatArrayLength(long session, long * pSize);
	long	getAuxFloatArray(long session, float * pResult, float * pAux1, float * pAux2, long arrayLength, long * pReadCount);
	long	emptyAllBuffers(long session);
	long	getTriggerState(long session, long *state);
	long	getError(long session, long *pError);
	long	emptyErrorQueue(long session);
	long	sendCommand(long session, const char *command, long timeout);
	long	writeDL(long session, const void *data, long count, long timeout);
	long	sendBinaryBlock(long session, const char *command, void *pBuffer, long count, long timeout);
	long	sendVendorInRequest(long session, char *pBuffer, long count, long request, long index);
	long	sendVendorOutRequest(long session, long request, long index, long value);
	long	dataAvailable(long session, long *pDataCount);
	long	openSensor(const char *resourceDescriptor, long *pHandle);
	long	closeSensor(long session);
	long	clearDevice(long session);
	long	setNotifyCallbackDeviceChanged(Nrp_DeviceChangedFuncPtr callbackPtr, long usrArgument);
	long	setNotifyCallbackDataAvailable(Nrp_DataAvailableFuncPtr callbackPtr, long usrArgument);
	long	setNotifyCallbackCommandAccepted(Nrp_CommandAcceptedFuncPtr callbackPtr, long usrArgument);
	long	setNotifyCallbackErrorOccurred(Nrp_ErrorOccurredFuncPtr callbackPtr, long usrArgument);
	long	setNotifyCallbackStillAlive(Nrp_StillAliveFuncPtr callbackPtr, long usrArgument);
	long	setNotifyCallbackStateChanged(Nrp_StateChangedFuncPtr callbackPtr, long usrArgument);
	long	setAttribute(long session, unsigned long attrName, long attrValue);
	long	getAttribute(long session, unsigned long attrName, void* pAttrValue);
	long	getDescriptor(long session, struct nrpz_sensor_info * descr);
	long	getSensorInfo(long session, char *name, char *type, char *serial);
	long	lockDeviceList();
	long	getDeviceListLength(long *pLength);
	long	getDeviceInfo(long index, char *name, char *type, char *serial, long *pIsConnected);
	long	getDeviceStatusZ5(void) { return m_nrpz5; }
	long	getDeviceInfoZ5(long index, char *name, char *type, char *serial, long *pIsConnected);
	long	discardResult(long lSession);
	long	getResourceName(long index, char *resource, unsigned int maxLen);
	long	getPortResource(long HubIndex, long PortIndex, char* Resource);
	long	getRootHubCount() const { return m_maxRootHub+1; }
	long	getHubPortCount() const { return m_maxPort+1; }
	long	disableFirmwareLoad(void (*func)(const char *resourceDescriptor)) { m_disableFirmwareLoad = func; return 0; }
    long    getUsageMap(char *cpMap, unsigned long nMapSize, unsigned long *pulRetSize);

	typedef std::list<NrpDevicePtr>::iterator			NrpDevListIter;
	typedef std::set<session_t>::iterator				SessionIdIter;
	typedef std::vector<struct udev_device *>::iterator WaitDeviceListIter;
protected:
	/**
	 * return the nrp device handled by session number
	 */
	NrpDevicePtr 		getNrpDevice(Synchronize &nrpdev_sync, long session);
	/**
	 * add pluged NRP Devices
	 */
	void addDevice(struct udev_device *dev);
	/**
	 * remove unpluged NRP Devices
	 */
	void delDevice(struct udev_device *dev);
	/**
	 * wakeup pending WaitForEvent
	 */
	int wakeUpSelect();
	/**
	 * helper for calling threaded dispatch method
	 */
	static void *	dispatchHelper(void *ptr);
	/**
	 * Thread for watching events on usb bus
	 */
	void 			dispatch();
	/**
	 * do handle the usb events event
	 */
	void handleUsbEvent();
	/**
	 * find a rescource descriptor and return the session id
	 */
	bool	findResource(const char * Resource, session_t &session);
	/**
	 * list of current available usb devices
	 */
	std::vector<NrpDevicePtr> 	m_devices;
	/**
	 * usb device changed callback function
	 */
	UsbCallBack		m_deviceChangedCallback;
	SensorCallBack	m_dataAvailableCallback;
	SensorCallBack	m_commandAcceptedCallback;
	SensorCallBack	m_errorOccurredCallback;
	SensorCallBack	m_stateChangedCallback;
	SensorCallBack	m_stillAliveCallback;
	/**
	 * mutex semaphore
	 */
	Mutex	m_mutex;
	/**
	 * thread ID
	 */
	Thread		m_thread;

	unsigned			m_devCnt;	// number of active usb devices
	unsigned			m_sessionCnt;	// highest used session number
	long				m_maxRootHub;	// max. usb root hub number
	long				m_maxPort;	// max. usb port number
	
	std::vector<struct udev_device *> m_waitDevices;

    NrpShmData* m_shmData; 

	std::list<NrpDevicePtr>		m_devList;	// list of currently sensor usb devices
	std::set<session_t>		m_idFreeSet;	// currently unused session IDs
	std::vector<UsbDescriptorPtr>	m_devInfo;	// temporary copy of m_devList usb descriptors for getDeviceInfo

	void				(*m_disableFirmwareLoad)(const char *resourceDescriptor);

	long				m_nrpz5;		// number of attached nrpz5 hubs
	/*
	 * OS specific members
	 */
	int				m_pipe[2];		// helper pipe select system call synchronisation
	struct udev *			m_udev;
	struct udev_device *		m_udevdev;
	struct udev_monitor *		m_udevmon;
	int 				m_udevfd;
	Condition			m_cond;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

