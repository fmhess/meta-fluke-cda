/***************************************************************************
***************************************************************************/

#include "NrpFile.h"
#include <stdio.h>
#include <ctype.h>
#if defined (LINUX)
  #include <sys/types.h>
  #include <unistd.h>
  #include <stddef.h>
#else
  #include "io.h"
#endif
#include "fcntl.h"


#define _tcsncmp strncmp
#define _T(x)    x
#define NL       _T("\n")


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
//#define new DEBUG_NEW
#endif


#ifdef DEBUG
void Dump( unsigned char *p, unsigned int iSiz )
{
  unsigned int i;

  fprintf( stderr, "Dumping %lu bytes...\n", iSiz );
  fprintf( stderr, "------------------------------\n" );
  for ( i = 0; i < iSiz; i++ )
  {
     if ( (i % 16) == 0 )
     {
         if ( i  )
             fprintf( stderr, "\n" );
         fprintf( stderr, "%08x: ", i );
     }

     fprintf( stderr, "%02x ", *(p + i) );
  }
  fprintf( stderr, "\n" );
  fprintf( stderr, "------------------------------\n" );
}
#endif


/***************************************************************************
SPECIFICATION: Construction/Destruction
PARAMETERS:
SIDE EFFECTS:
RETURN VALUES:
LAST CHANGE:  03.04.2001
***************************************************************************/
CNrpFileHeader::CNrpFileHeader( const char *cpFlashFile, CHECK_DEVICE_INFO *pDevInfo )
{
    m_iFh = -1;

    if ( cpFlashFile && strlen( cpFlashFile ) )
    {
        m_cpFlashFile = new char[ strlen( cpFlashFile ) + 1 ];
        strcpy( m_cpFlashFile, cpFlashFile );
    }
    else
        m_cpFlashFile = 0;

    m_cpErrorMsg = 0;
    m_bInRamOnly = false;

    StoreDeviceInfo( pDevInfo );

}


CNrpFileHeader::CNrpFileHeader( CHECK_DEVICE_INFO *pDevInfo, void *pFileData )
{
    m_iFh         = -1;
    m_cpFlashFile = 0;

    memcpy( &m_sFileHeader, pFileData, sizeof( m_sFileHeader ) );

    m_cpErrorMsg = 0;
    m_bInRamOnly = false;

    StoreDeviceInfo( pDevInfo );

}


CNrpFileHeader::~CNrpFileHeader()
{
    if ( m_iFh >= 0 )
    {
        close( m_iFh );
        m_iFh = -1;
    }

    if ( m_cpFlashFile )
        delete [] m_cpFlashFile;

    if ( m_cpErrorMsg )
        delete [] m_cpErrorMsg;

    m_cpFlashFile = 0;
}


int CNrpFileHeader::Error( const char *cpError )
{
    int iNewLen = 0;

    iNewLen = strlen( cpError ) + 2;
    if ( m_cpErrorMsg )
        iNewLen += strlen( m_cpErrorMsg );

    char *cpNewMsg = new char [ iNewLen ];
    if ( m_cpErrorMsg )
    {
        strcpy( cpNewMsg, m_cpErrorMsg );
        strcat( cpNewMsg, cpError );
        strcat( cpNewMsg, "\n" );
        delete [] m_cpErrorMsg;
        m_cpErrorMsg = cpNewMsg;
    }
    else
    {
        strcpy( cpNewMsg, cpError );
        strcat( cpNewMsg, "\n" );
        m_cpErrorMsg = cpNewMsg;
    }

    return iNewLen - 1;
}


unsigned int CNrpFileHeader::Hex( const char *cpIn, unsigned short usLen )
{
    unsigned int uiRet = 0;
    char         c;

    while ( usLen )
    {
        c = toupper( *cpIn );

        if ( (c < '0') || (c > 'F') )
            break;
        if ( (c > '9') && (c < 'A') )
            break;

        uiRet <<= 4;
        cpIn++;
        c -= '0';
        if ( c > 9 )
            c -= 7;
        uiRet += c;
    }

    return uiRet;
}

void CNrpFileHeader::StoreDeviceInfo( CHECK_DEVICE_INFO *pDevInfo )    // Endian-safe
{
    memset( &m_sDevInfo, 0x00, sizeof( m_sDevInfo ) );

    if ( pDevInfo )
    {
        m_sDevInfo.BitmaskPermit = pDevInfo->BitmaskPermit;
        m_sDevInfo.BitmaskRefuse = pDevInfo->BitmaskRefuse;
        m_sDevInfo.iProductID    = pDevInfo->iProductID;
        m_sDevInfo.iVendorID     = pDevInfo->iVendorID;
        strncpy( m_sDevInfo.szHwSubVariant, pDevInfo->szHwSubVariant, sizeof(m_sDevInfo.szHwSubVariant) );
        strncpy( m_sDevInfo.szHwVariant,    pDevInfo->szHwVariant,    sizeof(m_sDevInfo.szHwVariant) );
        strncpy( m_sDevInfo.szHwVersion,    pDevInfo->szHwVersion,    sizeof(m_sDevInfo.szHwVersion) );
        strncpy( m_sDevInfo.szManufacturer, pDevInfo->szManufacturer, sizeof(m_sDevInfo.szManufacturer) );
        strncpy( m_sDevInfo.szProduct,      pDevInfo->szProduct,      sizeof(m_sDevInfo.szProduct) );
        strncpy( m_sDevInfo.szSerialNumber, pDevInfo->szSerialNumber, sizeof(m_sDevInfo.szSerialNumber) );
    }
}



/***************************************************************************
SPECIFICATION: All check items are verified in this function
PARAMETERS:
SIDE EFFECTS:
RETURN VALUES: true if check is passed, false if not
CREATED:       03.04.2001
LAST CHANGE:   09.07.2001
***************************************************************************/
bool CNrpFileHeader::PerformCheck()
{
    // If a filename was given, we read the header from the file,
    // otherwise a header was given from "outside" through the
    // constructor!
    if ( m_cpFlashFile )
    {
        if ( ! ReadHeader() )
            return false;
    }

    DisplayHeader(  &m_sFileHeader );
    DisplayDevInfo( &m_sDevInfo );

    if ( _tcsncmp( m_sFileHeader.hMagicHeader, _T("fuhdr_01"), 8 ) )
    {
        Error( _T("Not a valid NRP file !") );
        return false;
    }

    m_bInRamOnly = (m_sFileHeader.hSectionDescriptor == 0x02);

    ENABLE_MASK *msk = 0;
#if defined(__powerpc__)
    ENABLE_MASK_U uMsk = m_sFileHeader.hEnableMask;
    Swap( &uMsk.s );
    msk = &uMsk.bm;
#else
    msk = &m_sFileHeader.hEnableMask.bm;
#endif

    char s[1024];

    if ( msk->HWSubVariantFrom ||
         msk->HWSubVariantTo   ||
         msk->HWVariantFrom    ||
         msk->HWVariantTo      ||
         msk->HWVersionFrom    ||
         msk->HWVersionTo      ||
         msk->BitmaskPermit    ||
         msk->BitmaskRefuse )
    {
        // DEV_INFO is already here !!!

        /*
        if (! ReadSensorData())
        {
            Error( _T("Error in reading device info !") );
            return false;
        }
        */
    }

#if defined (DEBUG)
    fprintf( stderr, "PerformCheck() for\n" );
    if ( msk->BitmaskRefuse    ) fprintf( stderr, "+ BitmaskRefuse\n"    );
    if ( msk->BitmaskPermit    ) fprintf( stderr, "+ BitmaskPermit\n"    );
    if ( msk->HWSubVariantTo   ) fprintf( stderr, "+ HWSubVariantTo\n"   );
    if ( msk->HWSubVariantFrom ) fprintf( stderr, "+ HWSubVariantFrom\n" );
    if ( msk->HWVariantTo      ) fprintf( stderr, "+ HWVariantTo\n"      );
    if ( msk->HWVariantFrom    ) fprintf( stderr, "+ HWVariantFrom\n"    );
    if ( msk->HWVersionTo      ) fprintf( stderr, "+ HWVersionTo\n"      );
    if ( msk->HWVersionFrom    ) fprintf( stderr, "+ HWVersionFrom\n"    );
    if ( msk->SerialNrTo       ) fprintf( stderr, "+ SerialNrTo\n"       );
    if ( msk->SerialNrFrom     ) fprintf( stderr, "+ SerialNrFrom\n"     );
    if ( msk->UsbProdStrg      ) fprintf( stderr, "+ UsbProdStrg\n"      );
    if ( msk->UsbManufStrg     ) fprintf( stderr, "+ UsbManufStrg\n"     );
    if ( msk->UsbProductID     ) fprintf( stderr, "+ UsbProductID\n"     );
    if ( msk->UsbVendorID      ) fprintf( stderr, "+ UsbVendorID\n"      );
    fprintf( stderr, "...\n" );
#endif

    if ( msk->UsbManufStrg )
    {
        if ( strcmp( m_sDevInfo.szManufacturer, m_sFileHeader.hManufactString ) )
        {
            sprintf( s, _T("USB manufacturer strings do not match !")NL
                        _T("Device: %s")NL
                        _T("File: %s"),
                        m_sDevInfo.szManufacturer,
                        m_sFileHeader.hManufactString );

            Error( s );
            return false;
        }
    }

    if ( msk->UsbProdStrg )
    {
        if ( strcmp( m_sDevInfo.szProduct, m_sFileHeader.hProductString ) )
        {
            sprintf( s, _T("USB product strings do not match !")NL
                        _T("Device: %s")NL
                        _T("File: %s"),
                        m_sDevInfo.szProduct,
                        m_sFileHeader.hProductString );
            Error( s );
            return false;
        }
    }

    if ( msk->UsbVendorID )
    {
#if defined(__powerpc__)
        unsigned int uiFHVenID = Swap( m_sFileHeader.hVendorID );
        unsigned int uiDIVenID = (m_sDevInfo.iVendorID >> 16) & 0x0000ffff;
#else
        unsigned int uiFHVenID = m_sFileHeader.hVendorID;
        unsigned int uiDIVenID = m_sDevInfo.iVendorID;
#endif

        if ( uiFHVenID != uiDIVenID )
        {
            sprintf( s, _T("USB vendor IDs do not match !")NL
                        _T("Device: 0x%04X")NL
                        _T("File:   0x%04X"),
                        (unsigned short)uiDIVenID,
                        (unsigned short)uiFHVenID );
            Error( s );
            return false;
        }
    }

    if ( msk->UsbProductID )
    {
#if defined(__powerpc__)
        unsigned int uiFHProdID = Swap( m_sFileHeader.hProductID );
        unsigned int uiDIProdID = (m_sDevInfo.iProductID >> 16) & 0x0000ffff;
#else
        unsigned int uiFHProdID = m_sFileHeader.hProductID;
        unsigned int uiDIProdID = m_sDevInfo.iProductID;
#endif
        if ( uiFHProdID != uiDIProdID )
        {
            sprintf( s, _T("USB product IDs do not match !")NL
                        _T("Device: 0x%04X")NL
                        _T("File:   0x%04X"),
                        (unsigned short)uiDIProdID,
                        (unsigned short)uiFHProdID );
            Error( s );
            return false;
        }
    }


    if ( msk->SerialNrFrom )
    {
        if ( strcmp( m_sFileHeader.hSerialNumberFrom, m_sDevInfo.szSerialNumber ) > 0 )
        {
            sprintf( s, _T("Serialnumber is not in the permitted range !")NL
                        _T("Lowest  SN: %s")NL
                        _T("Current SN: %s"),
                        m_sFileHeader.hSerialNumberFrom,
                        m_sDevInfo.szSerialNumber );
            Error( s );
            return false;
        }
    }


    if ( msk->SerialNrTo )
    {
        if ( strcmp( m_sFileHeader.hSerialNumberTo, m_sDevInfo.szSerialNumber ) < 0 )
        {
            sprintf( s, _T("Serialnumber is not in the permitted range !")NL
                        _T("Highest SN: %s")NL
                        _T("Current SN: %s"),
                        m_sFileHeader.hSerialNumberTo,
                        m_sDevInfo.szSerialNumber );
            Error( s );
            return false;
        }
    }


    if ( msk->HWVersionFrom )
    {
        if ( strcmp( m_sFileHeader.hHwVersionFrom, m_sDevInfo.szHwVersion ) > 0 )
        {
            sprintf( s, _T("HW version is not in the permitted range !")NL
                        _T("Lowest  HV: %s")NL
                        _T("Current HV: %s"),
                        m_sFileHeader.hHwVersionFrom,
                        m_sDevInfo.szHwVersion );
            Error( s );
            return false;
        }
    }


    if ( msk->HWVersionTo )
    {
        if ( strcmp( m_sFileHeader.hHwVersionTo, m_sDevInfo.szHwVersion ) < 0 )
        {
            sprintf( s, _T("HW version is not in the permitted range !")NL
                        _T("Highest HV: %s")NL
                        _T("Current HV: %s"),
                        m_sFileHeader.hHwVersionTo,
                        m_sDevInfo.szHwVersion );
            Error( s );
            return false;
        }
    }


    if ( msk->HWVariantFrom )
    {
        if ( strcmp( m_sFileHeader.hHwVariantFrom, m_sDevInfo.szHwVariant ) > 0 )
        {
            sprintf( s, _T("HW variant is not in the permitted range !")NL
                        _T("Lowest  HV: %s")NL
                        _T("Current HV: %s"),
                        m_sFileHeader.hHwVariantFrom,
                        m_sDevInfo.szHwVariant );
            Error( s );
            return false;
        }
    }


    if ( msk->HWVariantTo )
    {
        if ( strcmp( m_sFileHeader.hHwVariantTo, m_sDevInfo.szHwVariant ) < 0 )
        {
            sprintf( s, _T("HW variant is not in the permitted range !")NL
                        _T("Highest HV: %s")NL
                        _T("Current HV: %s"),
                        m_sFileHeader.hHwVariantTo,
                        m_sDevInfo.szHwVariant );
            Error( s );
            return false;
        }
    }


    if ( msk->HWSubVariantFrom )
    {
        if ( strcmp( m_sFileHeader.hHwSubVariantFrom, m_sDevInfo.szHwSubVariant ) > 0 )
        {
            sprintf( s, _T("HW subvariant is not in the permitted range !")NL
                        _T("Lowest  HV: %s")NL
                        _T("Current HV: %s"),
                        m_sFileHeader.hHwSubVariantFrom,
                        m_sDevInfo.szHwSubVariant );
            Error( s );
            return false;
        }
    }


    if ( msk->HWSubVariantTo )
    {
        if ( strcmp( m_sFileHeader.hHwSubVariantTo, m_sDevInfo.szHwSubVariant ) < 0 )
        {
            sprintf( s, _T("HW subvariant is not in the permitted range !")NL
                        _T("Highest HV: %s")NL
                        _T("Current HV: %s"),
                        m_sFileHeader.hHwSubVariantTo,
                        m_sDevInfo.szHwSubVariant );
            Error( s );
            return false;
        }
    }


    if ( msk->BitmaskPermit )
    {
        unsigned int dm     = m_sDevInfo.BitmaskPermit;
        unsigned int fm     = m_sFileHeader.hPermitMask;
        unsigned int h      = 0x80000000;
        bool         refuse = false;

        for (int i=0; i<32; i++)
        {
            if ((h & fm) & (h & ~dm))
            {
                refuse = true;
                break;
            }
            h >>= 1;
        }

        if ( refuse )
        {
            sprintf( s, _T("Bitmaskpermission rejected (permission bitmask) !")NL
                        _T("File   BM: %08X")NL
                        _T("Device BM: %08X"), fm, dm);
            Error( s );
            return false;
        }
    }


    if ( msk->BitmaskRefuse )
    {
        unsigned int dm     = m_sDevInfo.BitmaskRefuse;
        unsigned int fm     = m_sFileHeader.hRefuseMask;
        unsigned int h      = 0x80000000;
        bool         refuse = false;

        for (int i=0; i<32; i++)
        {
            if ((h & ~fm) & (h & dm))
            {
                refuse = true;
                break;
            }
            h >>= 1;
        }

        if ( refuse )
        {
            sprintf( s, _T("Bitmaskpermission rejected (refuse bitmask) !")NL
                        _T("File   BM: %08X")NL
                        _T("Device BM: %08X"), fm, dm);
            Error( s );
            return false;
        }
    }

    return true;
}



/***************************************************************************
SPECIFICATION: Reads flash header file
PARAMETERS:
SIDE EFFECTS:
RETURN VALUES:
CREATED:       03.04.2001
LAST CHANGE:   19.07.2001
***************************************************************************/
bool CNrpFileHeader::ReadHeader()
{
    bool boRet = true;

    if ( ! m_cpFlashFile )
        return false;

    m_iFh = open( m_cpFlashFile, O_RDONLY );
    if ( m_iFh < 0 )
        return false;

    unsigned int uiNrBytes = read( m_iFh, &m_sFileHeader, sizeof( m_sFileHeader ) );

    if ( uiNrBytes != sizeof( m_sFileHeader ) )
    {
        Error( _T("Unable to read file header !") );
        boRet = false;
  }

  close( m_iFh );
  m_iFh = -1;

  return boRet;
}



/***************************************************************************
SPECIFICATION:
PARAMETERS:
SIDE EFFECTS:
RETURN VALUES:
CREATED:       06.07.2001
LAST CHANGE:   06.07.2001
***************************************************************************/
bool CNrpFileHeader::TestInRamOnly()
{
  return m_bInRamOnly;
}


char * CNrpFileHeader::GetErrorText( void )
{
    if ( m_cpErrorMsg )
        return m_cpErrorMsg;

    return (char*)"";
}

void CNrpFileHeader::DisplayHeader( FLASH_FILE_HEADER *pHd )
{
    if ( ! pHd )
        return;

#if defined (DEBUG)
    int i;

    fprintf( stderr, "FLASH_FILE_HEADER\n" );
    fprintf( stderr, "-----------------\n" );
    fprintf( stderr, "Offset of hMagicHeader: %d\n", offsetof( FLASH_FILE_HEADER, hMagicHeader ) );
    fprintf( stderr, "Offset of hLength     : %d\n", offsetof( FLASH_FILE_HEADER, hLength ) );

    fprintf( stderr, "hMagicHeader      : " );
    for ( i = 0; i < 8; i++ )
    {
        if ( pHd->hMagicHeader[i] >= 0x20 )
            fprintf( stderr, "'%c' ", pHd->hMagicHeader[i] );
        else
            fprintf( stderr, "0x%02x ", pHd->hMagicHeader[i] );
    }
    fprintf( stderr, "\n" );

    fprintf( stderr, "hLength           : 0x%04x\n", pHd->hLength            );
    fprintf( stderr, "hEnableMask       : 0x%04x\n", pHd->hEnableMask.s      );
    fprintf( stderr, "hTargetAddress    : 0x%08x\n", pHd->hTargetAddress     );
    fprintf( stderr, "hStartAddress     : 0x%08x\n", pHd->hStartAddress      );
    fprintf( stderr, "hVendorID         : 0x%04x\n", pHd->hVendorID          );
    fprintf( stderr, "hProductID        : 0x%04x\n", pHd->hProductID         );
    fprintf( stderr, "hManufactString   : '%s'\n",   pHd->hManufactString    );
    fprintf( stderr, "hProductString    : '%s'\n",   pHd->hProductString     );
    fprintf( stderr, "hSerialNumberFrom : '%s'\n",   pHd->hSerialNumberFrom  );
    fprintf( stderr, "hSerialNumberTo   : '%s'\n",   pHd->hSerialNumberTo    );
    fprintf( stderr, "hHwVersionFrom    : '%s'\n",   pHd->hHwVersionFrom     );
    fprintf( stderr, "hHwVersionTo      : '%s'\n",   pHd->hHwVersionTo       );
    fprintf( stderr, "hHwVariantFrom    : '%s'\n",   pHd->hHwVariantFrom     );
    fprintf( stderr, "hHwVariantTo      : '%s'\n",   pHd->hHwVariantTo       );
    fprintf( stderr, "hHwSubVariantFrom : '%s'\n",   pHd->hHwSubVariantFrom  );
    fprintf( stderr, "hHwSubVariantTo   : '%s'\n",   pHd->hHwSubVariantTo    );
    fprintf( stderr, "hPermitMask       : 0x%08x\n", pHd->hPermitMask        );
    fprintf( stderr, "hRefuseMask       : 0x%08x\n", pHd->hRefuseMask        );
    fprintf( stderr, "hSectionDescriptor: 0x%02x\n", pHd->hSectionDescriptor );
#endif
}

void CNrpFileHeader::DisplayDevInfo( CHECK_DEVICE_INFO *pInfo )
{
    if ( ! pInfo )
        return;

#if defined (DEBUG)
    fprintf( stderr, "CHECK_DEVICE_INFO\n" );
    fprintf( stderr, "-----------------\n" );
    fprintf( stderr, "BitmaskPermit : 0x%08x\n", pInfo->BitmaskPermit  );
    fprintf( stderr, "BitmaskRefuse : 0x%08x\n", pInfo->BitmaskRefuse  );
    fprintf( stderr, "iVendorID     : 0x%08x\n", pInfo->iVendorID      );
    fprintf( stderr, "iProductID    : 0x%08x\n", pInfo->iProductID     );
    fprintf( stderr, "szManufacturer: '%s'\n",   pInfo->szManufacturer );
    fprintf( stderr, "szProduct     : '%s'\n",   pInfo->szProduct      );
    fprintf( stderr, "szSerialNumber: '%s'\n",   pInfo->szSerialNumber );
    fprintf( stderr, "szHwVersion   : '%s'\n",   pInfo->szHwVersion    );
    fprintf( stderr, "szHwVariant   : '%s'\n",   pInfo->szHwVariant    );
    fprintf( stderr, "szHwSubVariant: '%s'\n",   pInfo->szHwSubVariant );
#endif
}



#if defined(__powerpc__)
void CNrpFileHeader::Swap( unsigned short *pUShort )
{
    if ( ! pUShort )
        return;

    unsigned short s;
    s  = (*pUShort & 0xff00) >> 8;
    s |= (*pUShort & 0x00ff) << 8;
    *pUShort = s;
}

void CNrpFileHeader::Swap( short *pShort )
{
  Swap( (unsigned short *)pShort );
}


void CNrpFileHeader::Swap( unsigned int *pUInt )
{
  if ( ! pUInt )
    return;

  unsigned int i;
  i  = (*pUInt & 0xff000000) >> 24;
  i |= (*pUInt & 0x00ff0000) >> 8;
  i |= (*pUInt & 0x0000ff00) << 8;
  i |= (*pUInt & 0x000000ff) << 24;
  *pUInt = i;
}

void CNrpFileHeader::Swap( int *pInt )
{
    return Swap( (unsigned int *)pInt );
}

unsigned short CNrpFileHeader::Swap( unsigned short usIn )
{
    Swap( &usIn );
    return usIn;
}

short CNrpFileHeader::Swap( short sIn )
{
    Swap( &sIn );
    return sIn;
}

unsigned int CNrpFileHeader::Swap( unsigned int uiIn )
{
    Swap( &uiIn );
    return uiIn;
}

int CNrpFileHeader::Swap( int iIn )
{
    Swap( &iIn );
    return iIn;
}

#endif





unsigned long _crctbl[] = {
0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f,
0xe963a535, 0x9e6495a3, 0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988,
0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 0x1db71064, 0x6ab020f2,
0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9,
0xfa0f3d63, 0x8d080df5, 0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172,
0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b, 0x35b5a8fa, 0x42b2986c,
0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423,
0xcfba9599, 0xb8bda50f, 0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924,
0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d, 0x76dc4190, 0x01db7106,
0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d,
0x91646c97, 0xe6635c01, 0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e,
0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 0x65b0d9c6, 0x12b7e950,
0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7,
0xa4d1c46d, 0xd3d6f4fb, 0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0,
0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 0x5005713c, 0x270241aa,
0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81,
0xb7bd5c3b, 0xc0ba6cad, 0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a,
0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683, 0xe3630b12, 0x94643b84,
0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb,
0x196c3671, 0x6e6b06e7, 0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc,
0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 0xd6d6a3e8, 0xa1d1937e,
0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55,
0x316e8eef, 0x4669be79, 0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236,
0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 0xc5ba3bbe, 0xb2bd0b28,
0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f,
0x72076785, 0x05005713, 0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38,
0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21, 0x86d3d2d4, 0xf1d4e242,
0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69,
0x616bffd3, 0x166ccf45, 0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2,
0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 0xaed16a4a, 0xd9d65adc,
0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693,
0x54de5729, 0x23d967bf, 0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94,
0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d };


#define _crc(accum,delta) (accum)=_crctbl[((accum)^(delta))&0xff]^((accum)>>8)


CChecksum::CChecksum()
{
  ResetAccumulation();
}


CChecksum::~CChecksum()
{

}


void CChecksum::Accumulate( unsigned char ucDelta )
{
#if defined(DEBUG)
//  fprintf( stderr, "CRC 0x%08x + 0x%02x --> ", m_dwChecksum, ucDelta );
#endif

  _crc( m_dwChecksum, ucDelta );

#if defined(DEBUG)
//  fprintf( stderr, "0x%08x\n", m_dwChecksum );
#endif
}


void CChecksum::ResetAccumulation()
{
  m_dwChecksum = 0xffffffff;
}


unsigned int CChecksum::GetValue()
{
  return m_dwChecksum;
}


unsigned int CChecksum::GetFileChecksum( int iFh, unsigned int uiOffset )
{
  unsigned char aBuf[ 0x0100 ];
  unsigned int  uiCount;

  if ( uiOffset )
      lseek( iFh, uiOffset, SEEK_SET );  // push the file pointer to offset

  ResetAccumulation();

  do
  {
    uiCount = read( iFh, aBuf, sizeof( aBuf ) );

    for ( unsigned int ui = 0; ui < uiCount; ui++ )
      Accumulate( aBuf[ ui ] );

  } while ( uiCount );

  return GetValue();
}


unsigned int CChecksum::MemChecksum( unsigned char *pData, unsigned long ulSize, unsigned long ulOffset )
{
  ResetAccumulation();

#if defined(DEBUG)
//  Dump( pData + ulOffset, ulSize - ulOffset );
#endif

  for ( unsigned long ul = ulOffset; ul < ulSize; ul++ )
    Accumulate( pData[ ul ] );

  return GetValue();
}



