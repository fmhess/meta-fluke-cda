/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: usbdescriptor.cpp $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/stat.h>

#include "common.h"
#include "usbdescriptor.h"

using namespace nrplib;

// whatinfo indentification string
static const char * const whatinfo = "@(#) "__FILE__": "__DATE__" "__TIME__"";

static int set_lvalue(const char *str, int base, long &v)
{
	char *end;

	if (!str)
		return -1;

	v = strtol(str, &end, base);
	if (*end)
		return -1;

	return 0;
}

static int copy_svalue(const char *str, char *dst, size_t len)
{
	size_t l;

	if (!str)
		return -1;

	if (!len)
		return -1;

	--len;

	l = strlen(str);
	if (l > len )
		l = len;

	memcpy(dst, str, l);
	dst[l] = 0;

	return 0;
}

//
// read the device proc entry and fill the usb descriptor
//
UsbDescriptor::UsbDescriptor(struct udev_device *dev) :
	m_minor(0),
	m_hub(0),
	m_port(0),
	m_vendor(0),
	m_product(0),
	m_hubvendor(0),
	m_hubproduct(0),
	m_nrpz(false)
{
	const char *driver;
	const char *sysname;

	m_udev = udev_device_ref(dev);

	m_type[0] = 0;
	m_serial[0] = 0;
	m_resource[0] = 0;

	if (set_lvalue(udev_device_get_sysnum(dev), 10, m_minor))
		return;

	dev = udev_device_get_parent(dev);
	if (!dev)
		return;

	driver = udev_device_get_property_value(dev, "DRIVER");
	if (!driver)
		return;

	if (strcmp(driver, DRIVER_NAME))
		return;

	dev = udev_device_get_parent(dev);
	if (!dev)
		return;

	if (set_lvalue(udev_device_get_sysattr_value(dev, "idVendor"), 16, m_vendor))
		return;

	if (set_lvalue(udev_device_get_sysattr_value(dev, "idProduct"), 16, m_product))
		return;

	if (copy_svalue(udev_device_get_sysattr_value(dev, "product"), m_type, sizeof(m_type)))
		return;

	if (copy_svalue(udev_device_get_sysattr_value(dev, "serial"), m_serial, sizeof(m_serial)))
		return;

	sysname = udev_device_get_sysname(dev);
	if (!sysname)
		return;

	if (set_lvalue(udev_device_get_sysnum(dev), 10, m_port))
		return;

	m_resource[0] = 0;
	snprintf(m_resource, sizeof(m_resource), "USB::0x%04lx::0x%04lx::%s", m_vendor, m_product, m_serial);

	m_hub = 0;
	m_hubvendor = 0;
	m_hubproduct = 0;

	dev = udev_device_get_parent(dev);
	if (dev) {
		const char *subsystem = udev_device_get_subsystem(dev);

		if (subsystem && !strcmp(subsystem, "usb")) {
			set_lvalue(udev_device_get_sysattr_value(dev, "idVendor"), 16, m_hubvendor);
			set_lvalue(udev_device_get_sysattr_value(dev, "idProduct"), 16, m_hubproduct);
		}
	}

	m_hub = atoi(sysname);
	m_nrpz = true;

#ifdef DEBUG
	fprintf(
		stderr,
		"usbdescr:\n"
		" minor: %lu\n"
		" hub: %d\n"
		" port: %ld\n"
		" vendor: %04lx\n"
		" product: %04lx\n"
		" type: %s\n"
		" serial: %s\n"
		" resource: %s\n"
		" hubvendor: %08lx\n"
		" hubproduct: %08lx\n",
		m_minor,
		m_hub,
		m_port,
		m_vendor,
		m_product,
		m_type,
		m_serial,
		m_resource,
		m_hubvendor,
		m_hubproduct
	);
#endif
}

UsbDescriptor::~UsbDescriptor()
{
	udev_device_unref(m_udev);
}

/* vi:set ts=4 sw=4: */

