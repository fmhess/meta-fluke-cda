/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpLib
 *
 * $Workfile: fwupdater.cpp $
 *
 * Author: Juergen D. Geltinger
 *
 * Date of creation: 08-DEC-2008
 *
 ***************************************************************************/


#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>

#include "fwupdater.h"
#include "NrpFile.h"
#include "unzip.h"

#include "nrplib.h"

#define DWLOW(x)   (unsigned int)(x & 0xffff)
#define DWHIGH(x)  (unsigned int)(x >> 16)
#define _TIMO_     10000

#define THRET_T         void *
#define _tcsncpy        strncpy
#define MAX_PATH        1024

void Sleep( unsigned long lMilli )
{
    usleep( 1000 * lMilli );
}


unsigned long GetTickCount( void )
{
    static long long llLastCall = 0;
    unsigned long    dwRet      = 0;
    struct timeval   sTime;

    gettimeofday( &sTime, 0 );

    /* Computing Milliseconds since EPOCH... */
    long long llMilli;
    llMilli  = sTime.tv_sec;
    llMilli *= 1000;
    llMilli += sTime.tv_usec / 1000;

    if ( 0 == llLastCall )
    {
        llLastCall = llMilli;
        dwRet      = 0;
    }
    else
    {
        dwRet = (unsigned long)(llMilli - llLastCall);
    }

    return dwRet;
}


CATOF::CATOF( void )
{
    char szTest[20];
    sprintf( szTest, "%4.2f", 1.23 );
    m_cDecimalPoint = szTest[1];
    if ( m_cDecimalPoint == '.' )
        m_cComma = ',';
    else
        m_cComma = '.';
}

CATOF::~CATOF( void )
{
}

double CATOF::ATOF( const char *cpData )
{
    char szNumber[81];
    int  iLen;

    memset( szNumber, 0x00, sizeof( szNumber ) );
    strncpy( szNumber, cpData, sizeof( szNumber ) - 1 );

    iLen = strlen( szNumber );

    for ( int i = 0; i < iLen; i++ )
    {
        if ( szNumber[i] == m_cComma )
            szNumber[i] = m_cDecimalPoint;
    }

    return atof( szNumber );
}

long GetLongVersion( const char *cpVer )
{
    int  iaVer[3];
    int  iIdx = 0;
    char szNumber[81];
    char *cpDot;

    memset( szNumber, 0x00, sizeof( szNumber ) );
    memset( iaVer,    0x00, sizeof( iaVer    ) );
    strncpy( szNumber, cpVer, sizeof( szNumber ) - 1 );

    while ( strlen( szNumber ) && (iIdx < 3) )
    {
        cpDot = strchr( szNumber, '.' );
        if ( cpDot )
            *cpDot = 0x00;

        iaVer[ iIdx ] = atoi( szNumber );
        if ( iaVer[ iIdx ] <  0 ) iaVer[ iIdx ] =  0;
        if ( iaVer[ iIdx ] > 99 ) iaVer[ iIdx ] = 99;

        if ( cpDot )
            strcpy( szNumber, cpDot + 1 );
        else
            strcpy( szNumber, "" );

        iIdx++;
    }

    return 10000 * iaVer[0] + 100 * iaVer[1] + iaVer[2];
}


CFwUpdater *CFwUpdater::m_pInstance = 0;

CFwUpdater *CFwUpdater::GetInstance( const char *cpResourceName, const char *cpNrpFile )
{
    if ( CFwUpdater::m_pInstance == NULL )
    {
        if ( ! cpResourceName || ! cpNrpFile )
        {
#ifdef DEBUG
            fprintf(stderr,">%s: 'ResourceName' or 'NrpFile' missing\n",__FUNCTION__);
#endif
            return 0;
        }

        CFwUpdater::m_pInstance = new CFwUpdater( cpResourceName, cpNrpFile );
#ifdef DEBUG
        fprintf(stderr,">%s: Instance = 0x%08lx\n",__FUNCTION__,(unsigned long)CFwUpdater::m_pInstance);
#endif
    }

    return CFwUpdater::m_pInstance;
}


CFwUpdater *CFwUpdater::Destroy( void )
{
    if ( CFwUpdater::m_pInstance != NULL )
    {
        delete CFwUpdater::m_pInstance;
        CFwUpdater::m_pInstance = NULL;
    }

    return CFwUpdater::m_pInstance;
}


void CFwUpdater::SensorArrived( const char *cpResourceName )
{
#ifdef DEBUG
    fprintf(stderr,">%s( cpRes = '%s' )\n",__FUNCTION__, cpResourceName);
#endif

    CFwUpdater *pFwu = GetInstance();

    if ( ! pFwu )
    {
#ifdef DEBUG
        fprintf(stderr,">%s: No CFwUpdater Instance\n",__FUNCTION__);
#endif
        return;
    }

    strncpy( pFwu->m_szArrivedSensor, cpResourceName, sizeof( pFwu->m_szArrivedSensor ) - 1 );
}


CFwUpdater::CFwUpdater( const char *cpResourceName, const char *cpNrpFile )
: m_iStopThread(-1)
, m_lStatus(NRP_SUCCESS)
, m_eState(FWUST_IDLE)
, m_lDevice(0)
, m_hThread(0)
, m_uiThreadID(0)
, m_nFilesToInstall(0)
, m_nFileCurrentInstall(0)
, m_uiSizeNrpFile(0)
, m_pDataNrpFile(0)
, m_iProgress(0)

{
#ifdef DEBUG
    fprintf(stderr,">%s( %s, %s )\n",__FUNCTION__, cpResourceName, cpNrpFile );
#endif

    memset( m_szResourceName,    0x00, sizeof( m_szResourceName    ) );
    memset( m_szNrpFileFromUser, 0x00, sizeof( m_szNrpFileFromUser ) );
    memset( m_szInstallFile,     0x00, sizeof( m_szInstallFile     ) );
    memset( m_szProgressInfo,    0x00, sizeof( m_szProgressInfo    ) );


    if ( cpNrpFile )
    {
        strncpy( m_szNrpFileFromUser, cpNrpFile, sizeof( m_szNrpFileFromUser ) - 1 );
    }

    if ( cpResourceName )
    {
        strncpy( m_szResourceName, cpResourceName, sizeof( m_szResourceName ) - 1 );
    }
}


CFwUpdater::~CFwUpdater()
{
#ifdef DEBUG
    fprintf(stderr,">%s: Instance = 0x%08lx\n",__FUNCTION__,(unsigned long)this);
#endif

    // Stopping thread (if any)...
    if ( m_iStopThread == 0 )
    {
        if ( m_eState != FWUST_IDLE )
        {
            m_eState = FWUST_CANCEL;
            while ( m_eState != FWUST_IDLE )
                Sleep(10);

        }

        // Now finish thread...
        m_iStopThread++;

        while ( m_iStopThread < 2 )
            Sleep( 1 );

    }


    if ( m_pDataNrpFile )
    {
        delete [] m_pDataNrpFile;
        m_pDataNrpFile = 0;
    }
    m_uiSizeNrpFile = 0;

}


void CFwUpdater::SetUpdateFile( const char *cpNrpFile )
{
    if ( cpNrpFile )
    {
        strncpy( m_szNrpFileFromUser, cpNrpFile, sizeof( m_szNrpFileFromUser ) - 1 );
    }
}


bool CFwUpdater::IsFwUpdateDevice( const char *cpRes )
{
    // USB::0x0aad::0x0003::999001

    unsigned int uiProduct = 0;

    const char * cpColon = strstr( cpRes, "::" );
    if ( ! cpColon )
        return false;

	cpColon = strstr( cpColon + 2, "::" );
    if ( ! cpColon )
        return false;

    if ( 1 != sscanf( cpColon + 2, "%x", &uiProduct ) )
        return false;

    if ( (uiProduct == 0x0023) || (uiProduct == 0x0004) )
        return true;

    return false;
}



THRET_T CFwUpdater::Thread( void *pData )
{
    CATOF             ATOF;
    CHECK_DEVICE_INFO sDevInfo;
    unsigned int      dwTimo          = 0;
    unsigned int      dwTimo60Pct     = 0;
    int               iSensorProgress = 0;
    unsigned char     *cpDownloadData = 0;
    unsigned int      uiDownloadSize  = 0;
    unsigned int      uiTotalWrites   = 0;
    bool              boSetUpd        = false;

#ifdef DEBUG
    fprintf(stderr,">%s\n",__FUNCTION__);
#endif

    CFwUpdater *pThis = reinterpret_cast<CFwUpdater *>(pData);

    if ( ! pThis )
        return (THRET_T)(-1);

    // Storage for ORIGINAL FW-Version
    memset( pThis->m_szVersion, 0x00, sizeof( pThis->m_szVersion ) );


#ifdef DEBUG
    fprintf(stderr,">%s: CFwUpdater = 0x%08lx\n",__FUNCTION__, (unsigned long)pThis );
    fprintf(stderr,">%s: %d Files...\n",__FUNCTION__, pThis->m_nFilesToInstall );
    for ( unsigned int f = 0; f < pThis->m_nFilesToInstall; f++ )
        fprintf(stderr,">%s: File = %s\n",__FUNCTION__, pThis->m_szInstallFile[ f ] );
#endif

    while ( ! pThis->m_iStopThread )
    {

        switch ( pThis->m_eState )
        {
//          #################################################################################
            case FWUST_IDLE:    // Nothing to do
                break;


//          #################################################################################
            case FWUST_PREPARE: // A resource-name and a list of update-filename(s)
            {                   //    are given. Pointer to CUsbLayer is valid
                long lTestStatus;

#if defined(DEBUG)
                fprintf( stderr, "FWUST_PREPARE\n" );
#endif

                DisableFirmwareLoad( 0 );   // "Normal" NrpLib operation (= supplies only
                                            //   sensors with already running Firmware;
                                            //   no 'Boot' devices)
                memset( pThis->m_szArrivedSensor, 0x00, sizeof( pThis->m_szArrivedSensor ) );

                pThis->SetProgressInfo( "Trying to open sensor %s", pThis->m_szResourceName );

                dwTimo = _TIMO_;                    // For up to 6 seconds we try
                                                    // to open the sensor. If this is
                long lTestOpen;                     // successful, the sensor is connected
                                                    // and we can continue...
                dwTimo60Pct  = 6 * dwTimo;
                dwTimo60Pct /= 10;
                dwTimo60Pct += GetTickCount();
                dwTimo      += GetTickCount();
                boSetUpd     = true;

                if ( ! strcmp( "*", pThis->m_szResourceName ) ) // If the users selected ANY
                {                                               // sensor, we reduce the 60% TIMO
                    dwTimo60Pct = GetTickCount() + 500;
                }

                do
                {
                    lTestStatus = NRP_SUCCESS;
                    lTestOpen   = 0;

                    // -----------------------------------------------------------
                    // Do we already have an update device...?
                    // (This is unlikely, but possible. For example in case
                    //  of a defective firmware where only the bootloader
                    //  in the device is still active)
                    // -----------------------------------------------------------
                    if ( pThis->m_szArrivedSensor[0] )
                    {
                        try
                        {
                            NrpOpenSensor( pThis->m_szArrivedSensor, &pThis->m_lDevice );
                            pThis->m_eState  = FWUST_CHECK;
                            DisableFirmwareLoad( 0 );
                            memset( pThis->m_szArrivedSensor, 0x00, sizeof( pThis->m_szArrivedSensor ) );
                        }
                        catch ( ... )
                        {
                            // The sensor might have been disconnected in the meantime

                            pThis->m_lStatus = NRP_ERROR_DEVICE_DISCONNECTED;
                            pThis->SetProgressInfo( "Sensor %s has been disconnected", pThis->m_szResourceName );

                            pThis->m_lDevice = 0;
                            pThis->m_eState  = FWUST_DONE;
                        }
                        break;
                    }

                    try
                    {
                        lTestStatus = NrpOpenSensor( pThis->m_szResourceName, &lTestOpen );

#if defined(DEBUG)
                        fprintf( stderr, "FWUST_PREPARE: Got a pTestOpen device (%s)\n",
                                                         pThis->m_szResourceName );
                        fprintf( stderr, "FWUST_PREPARE: NrpOpenSensor(%s) -> Session = %ld\n",
                                                         pThis->m_szResourceName, lTestOpen );
                        fprintf( stderr, "FWUST_PREPARE: NrpOpenSensor(%s) -> Status  = 0x%08x\n",
                                                         pThis->m_szResourceName, lTestStatus );
//                      lTestStatus = NRP_SUCCESS;
#endif
                    }
                    catch ( ... )
                    {
#if defined(DEBUG)
                        char szMsg[128];
                        sprintf( szMsg, "FWUST_PREPARE: OpenDevice( %s ) throwed an exception\n",
                                        pThis->m_szResourceName );
                        fprintf( stderr, szMsg );
#endif
                        lTestStatus = NRP_ERROR_DEVICE_DISCONNECTED;
                    }

                    if ( ! lTestOpen )
                        lTestStatus = NRP_ERROR_DEVICE_DISCONNECTED;

                    if ( lTestStatus == NRP_SUCCESS )
                    {
                        char szName[128];
                        char szType[128];
                        char szSerial[128];

                        memset( szName,   0x00, sizeof( szName )   );
                        memset( szType,   0x00, sizeof( szType )   );
                        memset( szSerial, 0x00, sizeof( szSerial ) );

                        // If we opened "ANY" sensor, we set the resource name to more details
                        if ( ! strcmp( "*", pThis->m_szResourceName ) )
                        {

#if defined(DEBUG)
                            fprintf( stderr, "FWUST_PREPARE: GetSensorInfo\n" );
#endif

                            try
                            {
                                NrpGetSensorInfo( lTestOpen, szName, szType, szSerial );
                                strncpy( pThis->m_szResourceName, szName, sizeof( pThis->m_szResourceName ) );
                            }
                            catch ( ... )
                            {
                            }
#if defined(DEBUG)
                            fprintf( stderr, "FWUST_PREPARE: GetSensorInfo '%s' '%s' '%s'\n", szName, szType, szSerial );
#endif
                        } // resource name is "*"


                        if ( ! strcmp( "*", pThis->m_szResourceName )   // ANY Sensor requested
                          &&   strcmp( "NRP-Z81", szType )              // the current one is NOT a Z81
                          && boSetUpd
                          && ! strlen( pThis->m_szVersion) )            // Version yet unknown
                        {
                            char szVer[ 128 ];
                            long lDataCount = 0;


                            try
                            {
                                NrpEmptyAllBuffers( lTestOpen );
                                NrpSendCommand( lTestOpen, "SYSTEM:INFO? \"SW BUILD\"", 1000 );
                            }
                            catch ( ... )
                            {
                                char szMsg[256];
#if defined(DEBUG)
                                fprintf( stderr, "FWUST_CHECK: NrpSendCommand() failed\n" );
#endif
                                pThis->m_lStatus = NRP_ERROR_NOT_CONNECTED_SENSOR;
                                NrpGetErrorText( pThis->m_lStatus, szMsg, sizeof( szMsg ) );
                                pThis->SetProgressInfo( szMsg );

                                pThis->m_eState = FWUST_TIMO;
                            }


                            do
                            {
                                // Already an error in NrpSendCommand() above ?
                                if ( pThis->m_eState == FWUST_TIMO )
                                    break;

                                try
                                {
                                    NrpDataAvailable( lTestOpen, &lDataCount );
                                }
                                catch ( ... )
                                {
                                    char szMsg[256];
#if defined(DEBUG)
                                    fprintf( stderr, "FWUST_CHECK: NrpDataAvailable() failed\n" );
#endif
                                    pThis->m_lStatus = NRP_ERROR_NOT_CONNECTED_SENSOR;
                                    NrpGetErrorText( pThis->m_lStatus, szMsg, sizeof( szMsg ) );
                                    pThis->SetProgressInfo( szMsg );

                                    pThis->m_eState = FWUST_TIMO;
                                    break;
                                }

#if defined(DEBUG)
                                fprintf( stderr, "FWUST_PREPARE: DataCount = %ld\n", lDataCount );
#endif

                                if ( lDataCount != 0 )
                                {
                                    try
                                    {
                                        NrpGetStringResult( lTestOpen, szVer, sizeof( szVer ) - 1 );
                                        strncpy( pThis->m_szVersion, szVer, sizeof( pThis->m_szVersion ) );
#if defined(DEBUG)
                                        fprintf( stderr, "FWUST_PREPARE: m_szVersion = %s\n", pThis->m_szVersion );
#endif
                                        break;
                                    }
                                    catch ( ... )
                                    {
                                        char szMsg[256];
#if defined(DEBUG)
                                        fprintf( stderr, "FWUST_CHECK: NrpGetStringResult() failed\n" );
#endif
                                        pThis->m_lStatus = NRP_ERROR_STRING_QUEUE_EMPTY;
                                        NrpGetErrorText( pThis->m_lStatus, szMsg, sizeof( szMsg ) );
                                        pThis->SetProgressInfo( szMsg );

                                        pThis->m_eState = FWUST_TIMO;
                                        break;
                                    }
                                }

                                if ( GetTickCount() > dwTimo )
                                {
#if defined(DEBUG)
                                    fprintf( stderr, "FWUST_PREPARE: Timeout while reading SW BUILD!!!\n" );
#endif

                                    pThis->SetProgressInfo( "Timeout while reading FW version of\nsensor %s", pThis->m_szResourceName );

                                    pThis->m_eState  = FWUST_TIMO;      // Timeout. No more operations
                                    break;
                                }

                                Sleep( 100 );

                            } while( true );

                        } // asking for Version of sensors other than Z81

#if defined(DEBUG)
                        fprintf( stderr, "FWUST_PREPARE: closing pTestOpen device\n" );
#endif
                        try
                        {
                            NrpCloseSensor( lTestOpen );
                        }
                        catch ( ... )
                        {
                        }

                        lTestOpen = 0;

                        if ( pThis->m_eState == FWUST_TIMO )    // Timeout while reading SW BUILD
                            break;

                        pThis->SetProgressInfo( "Sensor %s found", pThis->m_szResourceName );


                        // All files done...???
                        if ( pThis->m_nFileCurrentInstall >= pThis->m_nFilesToInstall )
                        {
                            // Yes; all files downloaded --> READY !!!
                            // ---------------------------------------
                            pThis->m_eState = FWUST_CLEANUP;
                            break;

                        }


                        pThis->m_eState  = FWUST_OPENDEV;   // Sensor found
                        memset( pThis->m_szArrivedSensor, 0x00, sizeof( pThis->m_szArrivedSensor ) );
                        Sleep(300);                         // (could be opened successfully)
                        break;
                    }

                    if ( boSetUpd && (GetTickCount() > dwTimo60Pct) )       // If we have not seen a sensor
                    {                                                       // during the first half of our
                                                                            // timeout, we'll accept a possible
                                                                            // firmware-update device anyway...
                                                                            //
                        DisableFirmwareLoad( CFwUpdater::SensorArrived );   // This prevents NrpLib from
                                                                            // starting the application
                                                                            // code in the sensor

                        pThis->SetProgressInfo( "Bootloader of %s ?", pThis->m_szResourceName );
                                                boSetUpd = false;
                    }

                    if ( GetTickCount() > dwTimo )
                    {
#if defined(DEBUG)
                        fprintf( stderr, "FWUST_PREPARE: Timeout !!!\n" );
#endif

                        pThis->SetProgressInfo( "Timeout while searching sensor %s", pThis->m_szResourceName );

                        pThis->m_eState  = FWUST_TIMO;      // Timeout. No more operations
                        break;
                    }

                    Sleep( 200 );

                } while (1);    // Loop will be finished by either a found sensor
                                // or by a timeout
            }   break;


//          #################################################################################
            case FWUST_OPENDEV: // A sensor with a given resource-name is available; a list
                                // of update-filename(s) is given...

#if defined(DEBUG)
                fprintf( stderr, "FWUST_OPENDEV\n" );
#endif

                // We open the sensor now...
                try
                {
                    NrpOpenSensor( pThis->m_szResourceName, &pThis->m_lDevice );
                    pThis->m_eState  = FWUST_CHECK;
                }
                catch ( ... )
                {
                    // The sensor might have been disconnected in the meantime

                    pThis->m_lStatus = NRP_ERROR_DEVICE_DISCONNECTED;
                    pThis->SetProgressInfo( "Sensor %s has been disconnected", pThis->m_szResourceName );

                    pThis->m_lDevice = 0;
                    pThis->m_eState  = FWUST_DONE;
                }
                break;


//          #################################################################################
            case FWUST_CHECK:   // Check correct sensor type etc...
            {
#if defined(DEBUG)
                fprintf( stderr, "FWUST_CHECK\n" );
#endif
                char szMsg[256];

                // First we read some device information from the
                // sensor and fill a 'sDevInfo' structure. This'll
                // be used for checking against the file info
                // ------------------------------------------------
                unsigned char     ucBuf[12];

                memset( ucBuf,     0x00, sizeof( ucBuf    ) );
                memset( &sDevInfo, 0x00, sizeof( sDevInfo ) );

                pThis->SetProgressInfo( "Checking whether sensor and file fit" );

                try
                {
                    NrpSendVendorInRequest( pThis->m_lDevice, (char *)ucBuf, 8, VRT_GET_DEVICE_INFO, VRI_DEVICE_BITMASK );
//                  sDevInfo.BitmaskPermit = *((unsigned int *)ucBuf);
//                  sDevInfo.BitmaskRefuse = *((unsigned int *)(ucBuf + 4));
                    sDevInfo.BitmaskPermit = CNrpFileHeader::Hex( (char *)ucBuf,       4 );
                    sDevInfo.BitmaskRefuse = CNrpFileHeader::Hex( (char *)(ucBuf + 4), 4 );
                }
                catch ( ... )
                {

#if defined(DEBUG)
                    fprintf( stderr, "FWUST_CHECK: unable to read VRI_DEVICE_BITMASK\n" );
#endif

                    pThis->m_lStatus = NRP_ERROR_CONFIGURATION_STORE;
                    NrpGetErrorText( pThis->m_lStatus, szMsg, sizeof( szMsg ) );
                    pThis->SetProgressInfo( szMsg );

                    pThis->m_eState = FWUST_DORESET;
                    break;
                }


                try
                {
                    NrpSendVendorInRequest( pThis->m_lDevice, (char *)ucBuf, 10, VRT_GET_DEVICE_INFO, VRI_HW_VERSION );
                    _tcsncpy( sDevInfo.szHwVersion, (const char *)ucBuf, sizeof( sDevInfo.szHwVersion ) );
                }
                catch ( ... )
                {
#if defined(DEBUG)
                    fprintf( stderr, "FWUST_CHECK: unable to read VRI_HW_VERSION\n" );
#endif

                    pThis->m_lStatus = NRP_ERROR_CONFIGURATION_STORE;
                    NrpGetErrorText( pThis->m_lStatus, szMsg, sizeof( szMsg ) );
                    pThis->SetProgressInfo( szMsg );

                    pThis->m_eState = FWUST_DORESET;
                    break;
                }


                try
                {
                    NrpSendVendorInRequest( pThis->m_lDevice, (char *)ucBuf, 10, VRT_GET_DEVICE_INFO, VRI_HW_VARIANT );
                    _tcsncpy( sDevInfo.szHwVariant, (const char *)ucBuf, sizeof( sDevInfo.szHwVariant ) );
                }
                catch ( ... )
                {
#if defined(DEBUG)
                    fprintf( stderr, "FWUST_CHECK: unable to read VRI_HW_VARIANT\n" );
#endif
                    pThis->m_lStatus = NRP_ERROR_CONFIGURATION_STORE;
                    NrpGetErrorText( pThis->m_lStatus, szMsg, sizeof( szMsg ) );
                    pThis->SetProgressInfo( szMsg );

                    pThis->m_eState = FWUST_DORESET;
                    break;
                }


                try
                {
                    NrpSendVendorInRequest( pThis->m_lDevice, (char *)ucBuf, 10, VRT_GET_DEVICE_INFO, VRI_HW_SUB_VARIANT );
                    _tcsncpy( sDevInfo.szHwSubVariant, (const char *)ucBuf, sizeof( sDevInfo.szHwSubVariant ) );
                }
                catch ( ... )
                {
#if defined(DEBUG)
                    fprintf( stderr, "FWUST_CHECK: unable to read VRI_HW_SUB_VARIANT\n" );
#endif
                    pThis->m_lStatus = NRP_ERROR_CONFIGURATION_STORE;
                    NrpGetErrorText( pThis->m_lStatus, szMsg, sizeof( szMsg ) );
                    pThis->SetProgressInfo( szMsg );

                    pThis->m_eState = FWUST_DORESET;
                    break;
                }

                char szName[128];
                NrpGetSensorInfo( pThis->m_lDevice,
                                  szName,
                                  sDevInfo.szProduct,
                                  sDevInfo.szSerialNumber );

                NrpGetVendorProductID( pThis->m_lDevice,
                                       sDevInfo.szManufacturer,
                                       sizeof(sDevInfo.szManufacturer),
                                       &sDevInfo.iVendorID,
                                       &sDevInfo.iProductID );
#if defined (__powerpc__)
                CNrpFileHeader::Swap( &sDevInfo.iVendorID );
                CNrpFileHeader::Swap( &sDevInfo.iProductID );
#endif


#if defined(DEBUG)
                fprintf( stderr, "pThis->m_lDevice        = 0x%08lx\n",pThis->m_lDevice );
                fprintf( stderr, "sDevInfo.szManufacturer = '%s'\n",   sDevInfo.szManufacturer );
                fprintf( stderr, "sDevInfo.szProduct      = '%s'\n",   sDevInfo.szProduct );
                fprintf( stderr, "sDevInfo.szSerialNumber = '%s'\n",   sDevInfo.szSerialNumber );
                fprintf( stderr, "sDevInfo.iVendorID      = 0x%08x\n", sDevInfo.iVendorID );
                fprintf( stderr, "sDevInfo.iProductID     = 0x%08x\n", sDevInfo.iProductID );
#endif

                // ------------------------------------------------

                // Now we have all necessary sensor information and can
                // check whether the sensor fits with the given NRP file

                CNrpFileHeader Checker( pThis->m_szInstallFile[pThis->m_nFileCurrentInstall], &sDevInfo );

                if ( ! Checker.PerformCheck() )
                {
#if defined(DEBUG)
                    fprintf( stderr, "Checker.PerformCheck() failed\n" );
                    fprintf( stderr, Checker.GetErrorText() );
#endif

                    pThis->m_nFileCurrentInstall = pThis->m_nFilesToInstall;
                    pThis->m_lStatus             = NRP_ERROR_INVALID_SENSOR_TYPE;
                    pThis->SetProgressInfo( "Failed. %s", Checker.GetErrorText() );

                    // Since the sensor will be reset, we don't need to
                    // close it HERE...!  It will be closed in the
                    // FWUST_DORESET case

                    DisableFirmwareLoad( CFwUpdater::SensorArrived );   // We want to "see" the sensor
                    pThis->m_eState = FWUST_DORESET;                    // after the RESET_ALL
                    break;
                }

                // Sensor and NRP file fit
                pThis->m_eState = FWUST_SETUP;
            }   break;


//          #################################################################################
            case FWUST_SETUP:   // Sending Vendor requests... FIRMWARE UPDATE REQUEST
#if defined(DEBUG)
                fprintf( stderr, "FWUST_SETUP\n" );
#endif
                pThis->SetProgressInfo( "Starting bootloader" );

                DisableFirmwareLoad( CFwUpdater::SensorArrived );   // This prevents NrpLib from
                                                                    // starting the application
                                                                    // code in the sensor

                try
                {
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_FWU_REQUEST, 1, 0 );
                }
                catch ( ... )
                {
                    char szMsg[256];
                    pThis->m_lStatus = NRP_ERROR_CONFIGURATION_STORE;
                    NrpGetErrorText( pThis->m_lStatus, szMsg, sizeof( szMsg ) );
                    pThis->SetProgressInfo( szMsg );
                }

                Sleep( 50 );

                pThis->m_eState  = FWUST_SETUPCLOSE;
                break;


//          #################################################################################
            case FWUST_SETUPCLOSE:   // Close "normal" NRP sensor...
#if defined(DEBUG)
                fprintf( stderr, "FWUST_SETUPCLOSE\n" );
#endif
                // Due to the FIRMWARE UPDATE REQUEST the sensor disconnects
                // and re-connects. Therefore we close the sensor now

                NrpCloseSensor( pThis->m_lDevice );

                pThis->m_lDevice = 0;
                pThis->m_eState  = FWUST_WAIT4UPDATEDEVICE;
                dwTimo           = _TIMO_ + GetTickCount();
                break;


//          #################################################################################
            case FWUST_WAIT4UPDATEDEVICE:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_WAIT4UPDATEDEVICE\n" );
#endif
                // We wait up to _TIMO_ milliseconds for the "update" device

                if ( pThis->m_szArrivedSensor[0] )
                {
#if defined(DEBUG)
                fprintf( stderr, "FWUST_WAIT4UPDATEDEVICE, Got Update-Sensor '%s'\n", pThis->m_szArrivedSensor );
#endif
                    Sleep( 500 );
                    pThis->m_eState = FWUST_OPENUPDATEDEVICE;
                    break;
                }
                else
                    Sleep( 10 );


                if ( GetTickCount() > dwTimo )
                {
                    pThis->SetProgressInfo( "Timeout while waiting for bootloader" );
                    pThis->m_eState = FWUST_TIMO;
                }

                break;


//          #################################################################################
            case FWUST_OPENUPDATEDEVICE:
            {
                //long lStat;

#if defined(DEBUG)
                fprintf( stderr, "FWUST_OPENUPDATEDEVICE\n" );
#endif

                pThis->SetProgressInfo( "Opening firmware update device" );

                // "Update" device arrived. We open it for further use
                try
                {

                    NrpOpenSensor( pThis->m_szArrivedSensor, &pThis->m_lDevice );

                    pThis->m_eState  = FWUST_PREPDOWNLOAD;

#if defined(DEBUG)
                    char szMsg[256];
                    fprintf( stderr, "FwUpdate Device opened (%s), m_lDevice = 0x%08x, lStat = 0x%08x\n", pThis->m_szArrivedSensor, pThis->m_lDevice, lStat );
                    NrpGetErrorText( lStat, szMsg, sizeof( szMsg ) );
                    pThis->SetProgressInfo( szMsg );
#endif
                }
                catch ( ... )
                {
                    // The sensor might have been disconnected in the meantime

                    pThis->m_lStatus = NRP_ERROR_DEVICE_DISCONNECTED;
                    pThis->SetProgressInfo( "Firmware update device has been disconnected" );
                    pThis->m_lDevice = 0;
                    pThis->m_eState  = FWUST_DORESET;
                }

            }   break;


//          #################################################################################
            case FWUST_PREPDOWNLOAD:
            {
#if defined(DEBUG)
                fprintf( stderr, "FWUST_PREPDOWNLOAD\n" );
#endif

                //unsigned char *cpHeader;
                FLASH_FILE_HEADER *cpHeader = 0;
                unsigned int   uiChecksum;
                unsigned int   uiFileSize;

                pThis->SetProgressInfo( "Processing %s", pThis->m_szInstallFile[pThis->m_nFileCurrentInstall] );

                // We're going to work directly with data from the memory...
                pThis->ReadNrpFileToMemory( pThis->m_szInstallFile[pThis->m_nFileCurrentInstall] ); // Does NOT modify header
                                                                                                    // according to PPC/i386 !!!

//              cpHeader = (FLASH_FILE_HEADER *)new unsigned char[ sizeof( FLASH_FILE_HEADER ) ];
                cpHeader = new FLASH_FILE_HEADER;
                memcpy( cpHeader, pThis->GetNrpHeaderData(), sizeof( FLASH_FILE_HEADER ) );

                CNrpFileHeader Checker( &sDevInfo, cpHeader );

//              cpDownloadData = cpHeader + Checker.GetHeaderSize();
                cpDownloadData = (unsigned char *)pThis->GetNrpHeaderData() + Checker.GetHeaderSize();
                uiFileSize     = pThis->GetNrpDataSize();
                uiDownloadSize = uiFileSize - Checker.GetHeaderSize();

#if defined(DEBUG)
                fprintf( stderr, "GetNrpHeaderData() -> %p\n",     pThis->GetNrpHeaderData() );
                fprintf( stderr, "cpDownloadData     -> %p\n",     cpDownloadData );
                fprintf( stderr, "uiFileSize            0x%08x\n", uiFileSize );
                fprintf( stderr, "uiDownloadSize        0x%08x\n", uiDownloadSize );
#endif

                if ( ! Checker.PerformCheck() )
                {
#if defined(DEBUG)
                    fprintf( stderr, "Checker.PerformCheck() failed\n" );
                    fprintf( stderr, Checker.GetErrorText() );
#endif

                    pThis->m_lStatus             = NRP_ERROR_INVALID_SENSOR_TYPE;
                    pThis->m_nFileCurrentInstall = pThis->m_nFilesToInstall;
                    pThis->SetProgressInfo( "Failed. %s", Checker.GetErrorText() );

                    // Since the sensor will be reset, we don't need to
                    // close it HERE...! It is done in FWUST_DORESET

                    pThis->m_eState = FWUST_DORESET;
                    break;
                }

#if defined(DEBUG)
                Dump( (unsigned char *)pThis->GetNrpHeaderData(), uiFileSize );
#endif

                CChecksum cs;
                uiChecksum = cs.MemChecksum( (unsigned char *)pThis->GetNrpHeaderData(), uiFileSize, Checker.GetHeaderSize() );

#if defined(DEBUG)
                fprintf( stderr, "uiChecksum            0x%08x\n", uiChecksum );
#endif

                try
                {
                    pThis->SetProgressInfo( "Downloading data (%s)...", pThis->m_szInstallFile[pThis->m_nFileCurrentInstall] );

                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_SEND_DATA,    VRI_FILESIZE_LOW,         DWLOW (uiDownloadSize)          );
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_SEND_DATA,    VRI_FILESIZE_HIGH,        DWHIGH(uiDownloadSize)          );
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_SEND_DATA,    VRI_CHECKSUM_LOW,         DWLOW (uiChecksum)              );
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_SEND_DATA,    VRI_CHECKSUM_HIGH,        DWHIGH(uiChecksum)              );
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_SEND_DATA,    VRI_TARGETADDRESS_LOW,    DWLOW (Checker.GetTargetAddr()) );
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_SEND_DATA,    VRI_TARGETADDRESS_HIGH,   DWHIGH(Checker.GetTargetAddr()) );
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_SEND_DATA,    VRI_BSWSTARTADDRESS_LOW,  DWLOW (Checker.GetStartAddr())  );
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_SEND_DATA,    VRI_BSWSTARTADDRESS_HIGH, DWHIGH(Checker.GetStartAddr())  );
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_SEND_DATA,    VRI_SECTION_DESCRIPTOR,   Checker.GetSectionDesc()        );
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_INIT_PROCESS, VRI_START_DOWNLOAD,       0 );

                    uiTotalWrites   = 0;
                    pThis->m_eState = FWUST_DOWNLOAD;
                }
                catch ( ... )
                {
                    char szMsg[256];
                    pThis->m_lStatus = NRP_ERROR_CONFIGURATION_STORE;
                    NrpGetErrorText( pThis->m_lStatus, szMsg, sizeof( szMsg ) );
                    pThis->SetProgressInfo( szMsg );

                    pThis->m_eState = FWUST_DORESET;
                }

                delete cpHeader;


            }   break;


//          #################################################################################
            case FWUST_DOWNLOAD:
            {
#if defined(DEBUG)
                fprintf( stderr, "FWUST_DOWNLOAD\n" );
#endif

                unsigned int uiWriteSize = (uiDownloadSize >= 2048) ? 2048 : uiDownloadSize;

                if ( uiWriteSize )
                {
                    //long lRet;

                    NrpWriteDL( pThis->m_lDevice, cpDownloadData, uiWriteSize, 1000 );

                    uiDownloadSize -= uiWriteSize;
                    cpDownloadData += uiWriteSize;
                    uiTotalWrites  += uiWriteSize;

                    iSensorProgress = (int)(30.0 * uiTotalWrites / pThis->GetNrpDataSize());
                    pThis->SetProgress( iSensorProgress );

                }

                if ( uiDownloadSize )
                    break;

                Sleep( 500 );

                pThis->m_eState = FWUST_READDLSTATUS;
            }   break;


//          #################################################################################
            case FWUST_READDLSTATUS:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_READDLSTATUS\n" );
#endif

                switch ( pThis->GetDownloadStatus() )
                {
                    case  0:                                      break;    // Not yet finished
                    case  1: pThis->m_eState  = FWUST_CHECKDLCS;  break;    // Finished
                    default: pThis->m_eState  = FWUST_DORESET;
                             pThis->m_lStatus = NRP_ERROR_DEVICE_FLASHPROG;
                             pThis->SetProgressInfo( "Downloading data failed" );
                             break;    // Error
                }

                Sleep( 50 );

                break;


//          #################################################################################
            case FWUST_CHECKDLCS:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_CHECKDLCS\n" );
#endif
                switch ( pThis->GetDownloadChecksum() )
                {
                    case  1: pThis->m_eState  = FWUST_INITPROCESS; break;    // Checksum okay
                    default: pThis->m_eState  = FWUST_DORESET;
                             pThis->m_lStatus = NRP_ERROR_DEVICE_CHECKSUM;
                             pThis->SetProgressInfo( "Error in checksum" );
                             break;
                }

                Sleep( 50 );

                break;


//          #################################################################################
            case FWUST_INITPROCESS:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_INITPROCESS\n" );
#endif

                pThis->SetProgressInfo( "Erasing flash (#%d of %d)...",
                                        pThis->m_nFileCurrentInstall + 1,
                                        pThis->m_nFilesToInstall );

                pThis->InitManifestation();

                pThis->m_eState = FWUST_ERASING;
                break;


//          #################################################################################
            case FWUST_ERASING:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_ERASING\n" );
#endif

                iSensorProgress = pThis->GetSensorProgress();
                pThis->SetProgress( iSensorProgress );

                switch ( pThis->GetErasingStatus() )
                {
                    case -1: pThis->m_eState  = FWUST_DORESET;
                             pThis->m_lStatus = NRP_ERROR_DEVICE_FLASHPROG;
                             pThis->SetProgressInfo( "Error while erasing flash" );
                             break;
                    case  1: pThis->m_eState = FWUST_PROGRAMMING;
                             pThis->SetProgressInfo( "Programming flash (#%d of %d)...",
                                                     pThis->m_nFileCurrentInstall + 1,
                                                     pThis->m_nFilesToInstall );
                             break;
                    default: break;
                }

                Sleep( 50 );

                break;


//          #################################################################################
            case FWUST_PROGRAMMING:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_PROGRAMMING\n" );
#endif

                iSensorProgress = pThis->GetSensorProgress();
                pThis->SetProgress( iSensorProgress );

                switch ( pThis->GetProgrammingStatus() )
                {
                    case -1: pThis->m_eState  = FWUST_DORESET;
                             pThis->m_lStatus = NRP_ERROR_DEVICE_FLASHPROG;
                             pThis->SetProgressInfo( "Error while programming flash" );
                             break;
                    case  1: pThis->m_eState = FWUST_DONEPROCESS;
                             pThis->SetProgressInfo( "Programming finished" );
                             break;
                    default: break;
                }

                Sleep( 50 );

                break;


//          #################################################################################
            case FWUST_DONEPROCESS:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_DONEPROCESS\n" );
#endif

                iSensorProgress = pThis->GetSensorProgress();
                pThis->SetProgress( iSensorProgress );

                switch ( pThis->GetManifestationFinished() )
                {
                    case -1: pThis->m_eState = FWUST_DORESET;     break;
                    case  1: pThis->m_eState = FWUST_DORESET;     break;
                    default:                                      break;
                }

                Sleep( 50 );

                break;


//          #################################################################################
            case FWUST_TIMO:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_TIMO\n" );
#endif

                // Don't try to download other files...
                pThis->m_nFileCurrentInstall = pThis->m_nFilesToInstall;

                pThis->m_lStatus = NRP_ERROR_TIMEOUT;
                pThis->SetProgressInfo( "Timeout" );

                pThis->m_eState  = FWUST_DORESET;
                break;


//          #################################################################################
            case FWUST_CANCEL:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_CANCEL\n" );
#endif
                pThis->m_nFileCurrentInstall = pThis->m_nFilesToInstall;
                pThis->m_eState  = FWUST_DORESET;
                break;


//          #################################################################################
            case FWUST_DORESET:
            {
//              char m_szFwUpdDev[81];

#if defined(DEBUG)
                fprintf( stderr, "FWUST_DORESET\n" );
#endif
                // Will be set again when sensor comes back after RESET
                memset( pThis->m_szArrivedSensor, 0x00, sizeof( pThis->m_szArrivedSensor ) );

                DisableFirmwareLoad( CFwUpdater::SensorArrived );   // We want to "see" the sensor
                                                                    // after the VRT_RESET_ALL
                Sleep( 300 );

                if ( ! pThis->m_lDevice )
                {
#if defined(DEBUG)
                    fprintf( stderr, "FWUST_DORESET - No Device !!!\n" );
#endif

                    pThis->m_eState  = FWUST_DONE;
                    break;
                }

                dwTimo = GetTickCount() + 8000;

                try
                {
                    //long lStat;
                    NrpSendVendorOutRequest( pThis->m_lDevice, VRT_RESET_ALL, 1, 0 );
#if defined(DEBUG)
                    fprintf( stderr, "FWUST_DORESET - Sending VRT_RESET_ALL -> lStat = 0x%08lx\n", lStat );
#endif

                    Sleep( 100 );

                    pThis->m_lDevice = 0;
                }
                catch ( ... )
                {
                    char szMsg[256];
                    pThis->m_lStatus = NRP_ERROR_CONFIGURATION_STORE;
                    NrpGetErrorText( pThis->m_lStatus, szMsg, sizeof( szMsg ) );
                    pThis->SetProgressInfo( szMsg );
                }

                // Give Sensor a chance to reset...
#if defined(DEBUG)
                fprintf( stderr, "FWUST_DORESET - Sleeping\n" );
#endif

//              Sleep( 2000 );
                Sleep( 100 );

#if defined(DEBUG)
                fprintf( stderr, "FWUST_DORESET - Awake again\n" );
                fprintf( stderr, "FWUST_DORESET - m_lStatus = 0x%08lx\n", pThis->m_lStatus );
#endif

//              if ( pThis->m_lStatus != static_cast<long>(NRP_ERROR_TIMEOUT) )
//                  pThis->m_lStatus = NRP_SUCCESS;

                pThis->m_eState  = FWUST_RESETRET;
            }   break;


//          #################################################################################
            case FWUST_RESETRET:
            {
#if defined(DEBUG)
                fprintf( stderr, "FWUST_RESETRET\n" );
                long lCnt;
#endif
                long lLen;

                NrpLockDeviceList();
                NrpGetDeviceListLength( &lLen );

#if defined(DEBUG)
                fprintf( stderr, "FWUST_RESETRET: DeviceList Length = %ld\n", lLen );

                for ( lCnt = 0; lCnt < lLen; lCnt++ )
                {
                    char szName[128];

                    NrpGetDeviceInfo( lCnt, szName, 0, 0, 0 );

                    fprintf( stderr, "FWUST_RESETRET: Name[ %ld ] = %s\n", lCnt, szName );
                }
#endif
                NrpCommitDeviceList();

#if defined(DEBUG)
                fprintf( stderr, "FWUST_RESETRET: szArrivedSensor = %s\n", pThis->m_szArrivedSensor );
                fprintf( stderr, "FWUST_RESETRET: szResourceName  = %s\n", pThis->m_szResourceName );
#endif

                // EITHER  the same sensor came back
                //   OR    any sensor came back in case the original sensor was '*'
                //
                //        (This is the case when we try to "repair" a sensor which
                //         only has a running bootloader but no more a functional
                //         application firmware)
                if (   !strcmp( pThis->m_szArrivedSensor, pThis->m_szResourceName )              // EITHER the "ONE"
                  || ( !strcmp( pThis->m_szResourceName, "*" ) && pThis->m_szArrivedSensor[0] )  // OR ANY Sensor
                   )
                {
#if defined(DEBUG)
                    fprintf( stderr, "FWUST_RESETRET: Sensor came back :-)\n" );
#endif
                    pThis->m_eState = FWUST_DONE;
                    break;
                }

                if ( GetTickCount() > dwTimo )
                {
                    pThis->SetProgressInfo( "Timeout while waiting for device" );
                    pThis->m_nFileCurrentInstall = pThis->m_nFilesToInstall;
                    pThis->m_eState  = FWUST_DONE;
                    pThis->m_lStatus = NRP_ERROR_TIMEOUT;
                }

                Sleep( 50 );

            }   break;


//          #################################################################################
            case FWUST_DONE:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_DONE\n" );
#endif

                if ( pThis->m_lDevice )
                {
                    NrpCloseSensor( pThis->m_lDevice );
                    pThis->m_lDevice = 0;
                }

                pThis->m_nFileCurrentInstall++;     // Continue with next file (if any)

#if defined(DEBUG)
                fprintf( stderr, "*** FWUST_DONE ***\n" );
#if defined (__powerpc__)
                fprintf( stderr, "*** ProductID = %04x\n", CNrpFileHeader::Swap( sDevInfo.iProductID ) );
#else
                fprintf( stderr, "*** ProductID = %04x\n", sDevInfo.iProductID );
#endif
                fprintf( stderr, "*** szVersion = '%s'\n", pThis->m_szVersion );
                fprintf( stderr, "*** long(VER) = %ld\n",  GetLongVersion(pThis->m_szVersion) );
                fprintf( stderr, "******************\n" );
#endif

                if ( (pThis->m_nFileCurrentInstall >= pThis->m_nFilesToInstall) //     Last  file done (and only file, because NOT Z81)
#if defined (__powerpc__)
                  && (sDevInfo.iProductID != 0x00230000)                        // AND not a Z81
#else
                  && (sDevInfo.iProductID != 0x0023)                            // AND not a Z81
#endif
                  && (GetLongVersion(pThis->m_szVersion) < 40950)               // AND FW below 4.09.50
                  && (pThis->m_lStatus == static_cast<long>(NRP_SUCCESS))       // AND no error occured
                   )
                {
                    // NRP-Z11/Z21 etc. with Firmware < 4.09.50 may have problems with
                    //             Linux USB Kernel driver. In this case the user
                    //             should disconnect the sensor and connect it to
                    //             a different USB port to regain control over the
                    //             locked-up port...!!!

                    pThis->SetProgressInfo( "Firmware-Update done.  You should unplug the Sensor from the USB and\n"
                                            "connect it temporary to a DIFFERENT USB-port (due to a possible Kernel\n"
                                            "USB-driver flaw!).  If no other port is available, please reboot...\n"
                                          );
                    pThis->SetProgress( 100, true );

                    // Removing all temporary files
                    // ---------------------------------------
                    pThis->RemoveInstallFileList();

                    // READY now
                    // ---------------------------------------
                    pThis->m_eState = FWUST_IDLE;
                    break;
                }

                if ( pThis->m_lStatus == static_cast<long>(NRP_SUCCESS) )
                    pThis->m_eState = FWUST_PREPARE;
                else
                    pThis->m_eState = FWUST_CLEANUP;

                Sleep( 50 );

                break;

//          #################################################################################
            case FWUST_CLEANUP:
#if defined(DEBUG)
                fprintf( stderr, "FWUST_CLEANUP\n" );
#endif

                DisableFirmwareLoad( 0 );

                if ( pThis->m_lStatus == static_cast<long>(NRP_SUCCESS) )
                    pThis->SetProgressInfo( "Done" );
                else
                    pThis->SetProgressInfo( "Failed" );

                pThis->SetProgress( 100, true );

                // Removing all temporary files
                // ---------------------------------------
                pThis->RemoveInstallFileList();

                // READY now
                // ---------------------------------------
                pThis->m_eState = FWUST_IDLE;
                break;

        }

        Sleep( 0 );

    }

    pThis->m_iStopThread++;

#if defined(DEBUG)
    fprintf( stderr, "CFwUpdater::Thread() DONE\n" );
#endif

    return (THRET_T)0;
}

bool CFwUpdater::Update( void )
{
#ifdef DEBUG
    fprintf(stderr,">%s\n",__FUNCTION__);
#endif

    bool boIsArchive;
    char szMsg[256];

    m_lStatus = NRP_SUCCESS;

    if ( ! strlen( m_szResourceName ) )
    {
#ifdef DEBUG
        fprintf(stderr,">%s: No Resource Name\n",__FUNCTION__);
#endif

        m_lStatus = NRP_ERROR_INVALID_RESOURCE;
        NrpGetErrorText( m_lStatus, szMsg, sizeof( szMsg ) );
        SetProgressInfo( szMsg );

        return false;
    }

    if ( ! strlen( m_szNrpFileFromUser ) )
    {
#ifdef DEBUG
        fprintf(stderr,">%s: No NRP File from User\n",__FUNCTION__);
#endif

        m_lStatus = NRP_ERROR_INVALID_FILENAME;
        NrpGetErrorText( m_lStatus, szMsg, sizeof( szMsg ) );
        SetProgressInfo( szMsg );

        return false;
    }

    if ( strchr( m_szNrpFileFromUser, '?' )
      || strchr( m_szNrpFileFromUser, '*' ) )
    {
#ifdef DEBUG
        fprintf(stderr,">%s: Invalid NRP Filename\n",__FUNCTION__);
#endif

        m_lStatus = NRP_ERROR_INVALID_FILENAME;
        NrpGetErrorText( m_lStatus, szMsg, sizeof( szMsg ) );
        SetProgressInfo( szMsg );

        return false;
    }

#ifdef DEBUG
        fprintf(stderr,">%s: Reading File To Memory\n",__FUNCTION__);
#endif

    // Read file given from user into memory. This might
    // be a zip archive with more than 1 files or a
    // single file to install
    boIsArchive = ReadNrpFileToMemory( m_szNrpFileFromUser );

    if ( m_lStatus != NRP_SUCCESS )
    {
#ifdef DEBUG
        fprintf(stderr,">%s: ReadNrpFileToMemory() failed (%ld)\n",__FUNCTION__,m_lStatus);
#endif

        return false;
    }

    char szBinDir[ MAX_PATH ];
    char szBinFile[ MAX_PATH ];

    if ( ! WriteBinFile( szBinDir, szBinFile, boIsArchive ) )
    {
#ifdef DEBUG
        fprintf(stderr,">%s: WriteBinFile() failed\n",__FUNCTION__);
#endif
        return false;
    }

    if ( ! boIsArchive )
    {
        m_nFilesToInstall     = 1;
        m_nFileCurrentInstall = 0;
        strcpy( m_szInstallFile[0], szBinFile );

    }
    else
    {
        if ( ! BuildInstallFileList( szBinDir, szBinFile ) )
            return false;
    }

    // Now we have our members
    //
    //   m_nFilesToInstall, m_nFileCurrentInstall  and  m_szInstallFile[20]
    //
    // set

    if ( m_nFilesToInstall < 1 )
        return false;

    // Starting Thread...
    m_eState      = FWUST_PREPARE;
    m_iStopThread = 0;

    // The rest is done by a THREAD...
    m_hThread = pthread_create( &m_uiThreadID, NULL, Thread, this );

    return true;
}


long CFwUpdater::GetError( void )
{
    return m_lStatus;
}


int CFwUpdater::GetProgress( void )
{
    if ( m_lStatus == NRP_SUCCESS )
        return m_iProgress;
    else
        return 100;
}


const char * CFwUpdater::GetProgressInfo( void )
{
    return m_szProgressInfo;
}


void CFwUpdater::SetProgressInfo( const char *cpFmt, ... )
{
    va_list argList;
    va_start( argList, cpFmt );
    vsprintf( m_szProgressInfo, cpFmt, argList );
    va_end( argList );
}


bool CFwUpdater::ReadNrpFileToMemory( const char *cpFN )
{
#if defined(DEBUG)
    fprintf( stderr, "ReadNrpFileToMemory( " );
    fprintf( stderr, cpFN );
    fprintf( stderr, " )\n" );
#endif

    if ( m_pDataNrpFile )
    {
        delete [] m_pDataNrpFile;
        m_pDataNrpFile = 0;
    }
    m_uiSizeNrpFile = 0;


    FILE         *fp = 0;
    struct  stat sStat;
    int          iResult;
    char         szMsg[256];

    iResult = stat( cpFN, &sStat );

    if( iResult != 0 || sStat.st_size == 0 || sStat.st_size < (off_t)sizeof( FLASH_FILE_HEADER ) )
    {
        m_lStatus = NRP_ERROR_INVALID_FILENAME;
        NrpGetErrorText( m_lStatus, szMsg, sizeof( szMsg ) );
        SetProgressInfo( szMsg );
        return false;
    }

    m_uiSizeNrpFile = sStat.st_size;
    m_pDataNrpFile = new unsigned char[ m_uiSizeNrpFile ];

    fp = fopen( cpFN, "rb" );
    if ( fp )
    {
        if ( fread( m_pDataNrpFile, sizeof(unsigned char), m_uiSizeNrpFile, fp ) )
          /* nothing to do; just keep compiler happy */ ;
        fclose( fp );

#if defined(DEBUG)
        Dump( m_pDataNrpFile, m_uiSizeNrpFile );
#endif

    }
    else
    {
        m_lStatus = NRP_ERROR_INVALID_FILENAME;
        NrpGetErrorText( m_lStatus, szMsg, sizeof( szMsg ) );
        SetProgressInfo( szMsg );
        return false;
    }

//  FU_Header* pFuheader = (FU_Header*) pData;
    FLASH_FILE_HEADER *pFuheader = (FLASH_FILE_HEADER*)m_pDataNrpFile;
    CNrpFileHeader::DisplayHeader( pFuheader );

    if ( strncmp( pFuheader->hMagicHeader, "fuhdr_01" , 8 * sizeof( unsigned char ) ) )
        return false;

    // Added to check in case a valid archive.
    // Check if it is an NRP Archive
    if ( pFuheader->hSectionDescriptor == char(0x0d) ) //0x0D = NRP-Archive
        return true;
    else
        return false;
    // End Add

    return true;
}


bool CFwUpdater::WriteBinFile( char *cpDir, char *cpBinFile, bool boIsArchive )
{
#if defined(DEBUG)
    fprintf( stderr, "WriteBinFile()\n" );
#endif

    if ( ! m_pDataNrpFile )
    {
        char szMsg[256];
        m_lStatus = NRP_ERROR_INVALID_FILENAME;
        NrpGetErrorText( m_lStatus, szMsg, sizeof( szMsg ) );
        SetProgressInfo( szMsg );
        return false;
    }

    const char *cpEnvTemp;

    cpEnvTemp = getenv("TEMP");
    if ( ! cpEnvTemp )
        cpEnvTemp = getenv("TMP");
    if ( ! cpEnvTemp )
        cpEnvTemp = (const char*)"/tmp";

    if ( ! cpEnvTemp )
        return false;

    strcpy( cpDir, cpEnvTemp );

    int iLen = strlen( cpDir );
    for ( int iCh = 0; iCh < iLen; iCh++ )
    {
        if ( *(cpDir + iCh) == '\\' )
            *(cpDir + iCh) = '/';
    }

    char szTemp[ MAX_PATH ];
    strcpy( szTemp, cpDir );
    strcat( szTemp, "/" );
    strcat( szTemp, "temp.bin" );

    strcpy( cpBinFile, szTemp );

#if defined(DEBUG)
    fprintf( stderr, "WriteBinFile() creates '%s'\n", cpBinFile );
#endif

    FILE * fp = fopen( cpBinFile, "wb" );
    if ( fp )
    {
        unsigned char *cpData;
        unsigned int  nSize;
        if ( boIsArchive )
        {
            cpData = m_pDataNrpFile  + sizeof( FLASH_FILE_HEADER );
            nSize  = m_uiSizeNrpFile - sizeof( FLASH_FILE_HEADER );
        }
        else
        {
            cpData = m_pDataNrpFile;
            nSize  = m_uiSizeNrpFile;
        }
        fwrite( cpData, sizeof( unsigned char ), nSize, fp );
        fclose( fp );
    }
    else
        return false;

    return true;
}


bool CFwUpdater::BuildInstallFileList( const char *cpDir, const char *cpBinFile )
{
    memset( m_szInstallFile, 0x00, sizeof( m_szInstallFile ) );
    m_nFilesToInstall     = 0;
    m_nFileCurrentInstall = 0;

    HZIP hz;

    hz = OpenZip( cpBinFile, 0 );

    ZIPENTRY ze;
    SetUnzipBaseDir( hz, cpDir );

    GetZipItem( hz, -1, &ze );

    int iNumItems = ze.index;

    for ( int iItem = 0; iItem < iNumItems; iItem++ )
    {
        GetZipItem( hz, iItem, &ze );
        UnzipItem( hz, iItem, ze.name );

        strcpy( m_szInstallFile[ m_nFilesToInstall ], cpDir );
        strcat( m_szInstallFile[ m_nFilesToInstall ], "/" );
        strcat( m_szInstallFile[ m_nFilesToInstall ], ze.name );
        m_nFilesToInstall++;
    }

    CloseZip( hz );

    return true;
}


void CFwUpdater::RemoveInstallFileList( void )
{
    for ( unsigned int ui = 0; ui < m_nFilesToInstall; ui++ )
        remove( m_szInstallFile[ ui ] );

    m_nFilesToInstall = 0;
}


void CFwUpdater::InitManifestation( void )
{
    try
    {
        NrpSendVendorOutRequest( m_lDevice, VRT_INIT_PROCESS, VRI_MANIFESTATION, 0 );
    }
    catch ( ... )
    {
    }
}


int CFwUpdater::GetSensorProgress( void )
{
    unsigned char ucBuf[8];
    long          lErr = 0;

    try
    {
        lErr = NrpSendVendorInRequest( m_lDevice, (char *)ucBuf, 8, VRT_GET_MANIFESTATION_STATUS, VRI_GET_PROGRESSINFO );
    }
    catch ( ... )
    {
        return 99;
    }

    if ( (lErr == -1) || (lErr == static_cast<long>(NRP_ERROR_USB_DISCONNECTED)) )
        return 99;

    return ucBuf[0];
}


int CFwUpdater::GetDownloadStatus( void )
{
    unsigned char ucBuf[8];
    long          lErr = 0;

    try
    {
        lErr = NrpSendVendorInRequest( m_lDevice, (char *)ucBuf, 8, VRT_GET_DOWNLOAD_STATUS, GET_DLSTAT_FINISHED );
    }
    catch ( ... )
    {
        return -1;  // means error
    }

    if ( (lErr == -1) || (lErr == static_cast<long>(NRP_ERROR_USB_DISCONNECTED)) )
        return -1;

    return ucBuf[0];
}


int CFwUpdater::GetDownloadChecksum( void )
{
    unsigned char ucBuf[8];
    long          lErr = 0;

    try
    {
        lErr = NrpSendVendorInRequest( m_lDevice, (char *)ucBuf, 8, VRT_GET_DOWNLOAD_STATUS, GET_DLSTAT_CSOK );
    }
    catch ( ... )
    {
        return -1;  // means error
    }

    if ( (lErr == -1) || (lErr == static_cast<long>(NRP_ERROR_USB_DISCONNECTED)) )
        return -1;

    return ucBuf[0];
}


int CFwUpdater::GetErasingStatus( void )
{
    unsigned char ucBuf[8];
    long          lErr = 0;

    try
    {
        lErr = NrpSendVendorInRequest( m_lDevice, (char *)ucBuf, 8, VRT_GET_MANIFESTATION_STATUS,VRI_ERASING_FINISHED );
    }
    catch ( ... )
    {
        return -1;  // means error
    }

    if ( (lErr == -1) || (lErr == static_cast<long>(NRP_ERROR_USB_DISCONNECTED)) )
        return -1;

    if ( ucBuf[0] == 0xff )
        return -1;

    return ucBuf[0];

}


int CFwUpdater::GetProgrammingStatus( void )
{
    unsigned char ucBuf[8];
    long          lErr = 0;

    try
    {
        lErr = NrpSendVendorInRequest( m_lDevice, (char *)ucBuf, 8, VRT_GET_MANIFESTATION_STATUS,VRI_PROGRAMMING_FINISHED );
    }
    catch ( ... )
    {
        return -1;  // means error
    }

    if ( (lErr == -1) || (lErr == static_cast<long>(NRP_ERROR_USB_DISCONNECTED)) )
        return -1;

    if ( ucBuf[0] == 0xff )
        return -1;

    return ucBuf[0];

}


int CFwUpdater::GetManifestationFinished( void )
{
    unsigned char ucBuf[8];
    long          lErr = 0;

    try
    {
        lErr = NrpSendVendorInRequest( m_lDevice, (char *)ucBuf, 8, VRT_GET_MANIFESTATION_STATUS,VRI_MANIFEST_FINISHED );
    }
    catch ( ... )
    {
        return -1;  // means error
    }

    if ( (lErr == -1) || (lErr == static_cast<long>(NRP_ERROR_USB_DISCONNECTED)) )
        return -1;

    if ( ucBuf[0] == 0xff )
        return -1;

    return ucBuf[0];

}


void CFwUpdater::SetProgress( int iProgress, bool boAbsolute )
{
    double dProgress;
    double dFactor;
    int    iPrgr;

    dFactor    = 1.0 / m_nFilesToInstall;
    dProgress  = dFactor * m_nFileCurrentInstall;

    dProgress += dFactor * 0.01 * iProgress;

    iPrgr = boAbsolute ? iProgress : (int)(100.0 * dProgress - 1.0);

    if ( iPrgr < 0 )
        iPrgr = 0;

    if ( iPrgr > 100 )
        iPrgr = 100;

    m_iProgress = iPrgr;
}


void CFwUpdater::Cancel( void )
{
    if ( m_iStopThread == 0 )
    {
        // Thread is still running

        if ( m_eState != FWUST_IDLE )
        {
            m_eState = FWUST_CANCEL;

            while ( m_eState != FWUST_IDLE )
                Sleep( 50 );

        }

        m_iStopThread++;
        while ( m_iStopThread < 2 )
            Sleep( 50 );
    }

}


