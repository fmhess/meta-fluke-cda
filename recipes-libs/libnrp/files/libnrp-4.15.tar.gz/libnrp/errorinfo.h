/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl.dll for linux
 *
 * $Workfile: errorinfo.h $
 *
 * Author: R&S dept. 1GS4 (based on Zdenek Rykala)
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#ifndef	__ERRORINFO_H__
#define	__ERRORINFO_H__

namespace nrplib
{

/**
 * \class	CErrorInfo
 * \brief	This class represents an error information
 *
 * \author	1GS4, Zdenek Rykala
 * \version	1.0
 * \date	2006
 */
class ErrorInfo
{
protected:
public:
	/**
	 * Constructor
	 */
	explicit ErrorInfo(long errorCode) : m_errorCode(errorCode) { }
	/**
	 * Gets error code
	 */
	inline long getCode(void) const { return m_errorCode; }
private:
	/**
	 * Error Code
	 */
	long	m_errorCode;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

