/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: nrplib.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#ifndef	__NRPLIB_H__
#define	__NRPLIB_H__

#include "nrpdef.h"

#ifdef __cplusplus
extern "C" {
#endif

extern long DisableFirmwareLoad(void (*func)(const char *resourceDescriptor));
extern long GetRootHubCount(void);
extern long GetHubPortCount(long HubIndex);
extern long GetPortResource(long HubIndex, long PortIndex, char* Resource);

extern long NrpOpenDriver(void);
extern long NrpCloseDriver(void);
extern long NrpLockDeviceList(void);
extern long NrpGetDeviceListLength(long *pLength);
extern long NrpGetDeviceInfo(long index, char name[], char type[], char serial[], long *pIsConnected);
extern long NrpGetResourceName(long index, char resource[], unsigned int maxLen);
extern long NrpOpenSensor(const char *resourceDescriptor, long *pHandle);
extern long NrpCloseSensor(long session);
extern long NrpGetSensorInfo(long session, char name[], char type[], char serial[]);
extern long NrpSendCommand(long session, const char *command, long timeout);
extern long NrpGetData(long session, long *pBlockType, long *pGroupNr, long *paramNr);
extern long NrpGetFloatArray(long session, float *pArray, long arraysize, long *pReadCount);
extern long NrpGetFloatArrayLength(long session, long *size);
extern long NrpGetAuxFloatArray(long session, float *pArray, float *pAux1, float *pAux2, long arraysize, long *pReadCount);
extern long NrpGetAuxFloatArrayLength(long session, long *size);
extern long NrpGetFloatResult(long session, float *pFloatVal1, float *pFloatVal2, float *pFloatVal3);
extern long NrpGetLongResult(long session, long *pLongVal1, long *pLongVal2, long *pLongVal3);
extern long NrpGetBitfieldResult(long session, long *pBitVal1, long *pBitVal2, long *pBitVal3);
extern long NrpGetStringResultLength(long session, long *size);
extern long NrpGetStringResult(long session, char *pBuffer, long size);
extern long NrpGetBinaryResultLength(long session, long *size);
extern long NrpGetBinaryResult(long session, unsigned char *pBuffer, long buflen, long *size);
extern long NrpEmptyAllBuffers(long session);
extern long NrpGetTriggerState(long session, long *state);
extern long NrpGetError(long session, long *pError);
extern long NrpEmptyErrorQueue(long session);
extern long NrpGetErrorText(long errorcode, char pBuffer[], long size);
extern long NrpClearDevice(long session);
extern long NrpDataAvailable(long session, long *pDataCount);
extern long NrpCommitDeviceList(void);
extern long NrpSendBinaryBlock(long session, const char *command, void *pBuffer, long count, long timeout);
extern long NrpGetVendorProductID(long session, char *cpManuf, long lSize, int *piVendorID, int *piProductID);
extern long NrpGetDeviceStatusZ5(void);
extern long NrpGetDeviceInfoZ5(long index, char name[], char type[], char serial[], long *pIsConnected);
extern long NrpOpenSensorOnZ5(char cPort, long *pHandle);
extern long NrpDiscardResult(long session );


/** Registers the callback for command accepted event. */
extern long NrpSetNotifyCallbackCommandAccepted(Nrp_CommandAcceptedFuncPtr callbackPtr, long usrArgument);

/** Registers the callback for data available event. */
extern long NrpSetNotifyCallbackDataAvailable(Nrp_DataAvailableFuncPtr callbackPtr, long usrArgument);

/** Registers the callback for error occured event. */
extern long NrpSetNotifyCallbackErrorOccurred(Nrp_ErrorOccurredFuncPtr callbackPtr, long usrArgument);

/** Registers the callback for state changed event. */
extern long NrpSetNotifyCallbackStateChanged(Nrp_StateChangedFuncPtr callbackPtr, long usrArgument);

/** Registers the callback for device changed event. */
extern long NrpSetNotifyCallbackDeviceChanged(Nrp_DeviceChangedFuncPtr callbackPtr, long usrArgument);

/** Registers the callback for still alive events. */
extern long NrpSetNotifyCallbackStillAlive(Nrp_StillAliveFuncPtr callbackPtr, long usrArgument);

/** translate a given numeric state into a text string. */
extern long NrpGetTriggerStateText(long state, char *pBuffer[], long size);


/** Sets a specified attribute for given object. */
extern long NrpSetAttribute(long session, unsigned long attrName, long attrValue);

/** Queries the specified attribute for a given object. */
extern long NrpGetAttribute(long session, unsigned long attrName, void* pAttrValue);

extern long NrpSendVendorOutRequest( long session, long request, long index, long value );
extern long NrpSendVendorInRequest(long session, char *pBuffer, long count, long request, long index);

extern long NrpWriteDL(long session, const void *command, long count, long timeout);

typedef enum tag_FwuState
{
	FWUST_IDLE = 0, 			// Idle -- Nothing to do
	FWUST_PREPARE, 				// Search for sensor with given resource name
	FWUST_OPENDEV, 				// Opening "normal" NRP sensor 
	FWUST_CHECK, 				// Check for correct sensor type etc.
	FWUST_SETUP, 				// Send FWU vendor requests
	FWUST_SETUPCLOSE, 			// Close "normal" NRP sensor
	FWUST_WAIT4UPDATEDEVICE,	 	// Wait for re-enumeration as "Boot"/FwUpdate device
	FWUST_OPENUPDATEDEVICE,			// Open FwUpdate device
	FWUST_PREPDOWNLOAD, 			// Send required vendor requests
	FWUST_DOWNLOAD, 			// Download data
	FWUST_READDLSTATUS, 			// Checking for Download okay
	FWUST_CHECKDLCS, 			// Checking for correct checksum
	FWUST_INITPROCESS, 			// Start erasing
	FWUST_ERASING, 				// Wait for erasing finished
	FWUST_PROGRAMMING, 			// Wait for programming finished
	FWUST_DONEPROCESS, 			// Wait for process finished
	FWUST_TIMO, 				// Handling timeout
	FWUST_CANCEL, 				// Canceling FwUpdate
	FWUST_DORESET, 				// send a VRT_RESET_ALL
	FWUST_RESETRET, 			// return from VRT_RESET_ALL
	FWUST_DONE, 				// function done (continue with next file { = FWUST_PREPARE} or goto CLEANUP)
	FWUST_CLEANUP				// clean up and goto IDLE
} eFwuState;

// NrpUpdateOpen() sets up a firmware-update thread for a given
//    NRP-Zxx sensor (resource name might be "*") and with a given
//    *.NRP file. The function initializes a session parameter for
//    subsequent status- and progress requests
//    Function returns NRP_SUCCESS or a NRP_ERROR_xxxx code
extern long NrpUpdateOpen(const char *cpResourceName, const char *cpUpdateFileNRP, long *plSession);

// NrpUpdateGetState() returns the internal states of the
//    firmware-update process. This function can be used to
//    trigger updates of GUI elements whenever the update-
//    thread state changes. The states are defined as enums
//    with names as FWUST_xxxx as found above
extern long NrpUpdateGetState(long session, int *piState);

// NrpUpdateGetError() returns NRP_SUCCESS or an error code, i. e.
//    NRP_ERROR_INVALID_SESSION  when session is invalid
//    NRP_SUCCESS                when the firmware-update finished successfully
//    NRP_ERROR_xxxxx            in case of an error
extern long NrpUpdateGetError(long session);

// NrpUpdateGetProgress()  returns a percentage of the update progress
//    in the range of 0...100.  This can be used to visualize the
//    update in a progress-bar
extern int NrpUpdateGetProgress(long session);

// NrpUpdateGetInfoText() return textual information about the current
//    update progress. This can be used to show status
//    information to the user in a text-field
extern const char * NrpUpdateGetInfoText(long session);

// NrpUpdateCancel() can be used to abort an active
//    update-process
extern long NrpUpdateCancel(long session);


// NrpUpdateClose()  This function shall be used to close a
//    firmware-update session which was created by a previous
//    call of NrpUpdateOpen();
extern long NrpUpdateClose(long *pSession);

extern long NrpGetUsageMap(char *cpMap, unsigned long nMapSize, unsigned long *pulRetSize);

#ifdef __cplusplus
}
#endif

#endif

/* vi:set ts=4 sw=4: */

