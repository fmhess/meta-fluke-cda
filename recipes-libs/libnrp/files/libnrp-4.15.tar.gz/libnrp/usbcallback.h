/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: usbcallback.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2007-08-06
 *
 ***************************************************************************/

#ifndef	__USBCALLBACK_H__
#define	__USBCALLBACK_H__

#include "mutex.h"
#include "thread.h"

namespace nrplib
{
/**
 * type for device event callback functions
 */
typedef void (*usbcbfunc)(long usrarg);

class UsbCallBack : private noncopyable
{
public:
	UsbCallBack() : m_callback(0), m_arg(0), m_thread("nrpcallback")
	{
	}
	~UsbCallBack()
	{
		m_thread.cancel();
	}
	void set(usbcbfunc callback, long arg)
	{
		if (m_thread.isrunning() == false)
			m_thread.start(callback_helper, this);

		m_callback = callback;
		m_arg = arg;
	}
	int call()
	{
		if (!m_callback)
			return 1;

		m_condmutex.lock();
		m_cond.set();
		m_condmutex.unlock();

		return 0;
	}
private:
	static void * callback_helper(void *ptr)
	{
		((UsbCallBack *)ptr)->callback_dispatch();

		return 0;
	}
	void callback_dispatch()
	{
		bool	flag;

		while(m_thread.test_cancel() == false) {

			m_condmutex.lock();
			flag = m_cond.wait(m_condmutex);
			m_condmutex.unlock();

			if (flag == true) {
				ThreadCancelDisable	tcd;

				if (m_callback)
					m_callback(m_arg);
			}
		}
	}
	usbcbfunc	m_callback;
	long		m_arg;
	Thread		m_thread;
	Condition	m_cond;
	Mutex		m_condmutex;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

