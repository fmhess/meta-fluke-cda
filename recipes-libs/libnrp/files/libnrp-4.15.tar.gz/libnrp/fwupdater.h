/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpLib
 *
 * $Workfile: fwupdater.h $
 *
 * Author: Juergen D. Geltinger
 *
 * Date of creation: 20-AUG-2008
 *
 ***************************************************************************/

#if !defined(__FWUPDATER_H__)
#define __FWUPDATER_H__ 

#include <pthread.h>

#include "nrplib.h"

class CATOF
{
public:
    CATOF( void );
    ~CATOF( void );
    double ATOF( const char *cpData );
private:
    char m_cComma;
    char m_cDecimalPoint;
};

class CFwUpdater
{
public:
    static void       *Thread( void *pData );
    static void        SensorArrived( const char *cpResName );
    static CFwUpdater *GetInstance( const char *cpResourceName = 0, const char *cpNrpFile = 0 );
    static CFwUpdater *Destroy();

    bool         IsFwUpdateDevice( const char *cpRes );
   	bool         Update( void );
   	void         SetUpdateFile( const char *cpNrpFile );

    long         GetError( void );
    const char * GetProgressInfo( void );
    void         SetProgressInfo( const char *cpFmt, ... );

    int          GetProgress( void );
    void         SetProgress( int iProgress, bool boAbsolute = false );

    long         GetStatus( void ) { return m_lStatus; };
    int          GetThreadState( void ) { return static_cast<int>(m_eState); };

    void         Cancel( void );


    // User-given data:
    // ----------------
    char           m_szResourceName[81];
    char           m_szNrpFileFromUser[512];

    // Internal data:
    // --------------
    char           m_szArrivedSensor[81];
    int            m_iStopThread;
    long           m_lStatus;
    eFwuState      m_eState;
    long           m_lDevice;
    char           m_szVersion[21];

    int            m_hThread;
    pthread_t      m_uiThreadID;

    // List of NRP files to install:
    // -----------------------------
    char           m_szInstallFile[50][256];    // 50 string of 256 bytes each
    unsigned int   m_nFilesToInstall;
    unsigned int   m_nFileCurrentInstall;       // 0...(m_nFilesToInstall-1)

    // Contents of an NRP file in memory:
    // ----------------------------------
    unsigned int   m_uiSizeNrpFile;
    unsigned char *m_pDataNrpFile;

    
private:

    CFwUpdater( const char *cpResourceName, const char *cpNrpFile = 0 );
    virtual ~CFwUpdater();

    bool           ReadNrpFileToMemory(  const char *cpFN  );
    void *         GetNrpHeaderData( void ) { return m_pDataNrpFile; };
    unsigned int   GetNrpDataSize( void ) { return m_uiSizeNrpFile; };

    bool           WriteBinFile( char *cpDir, char *cpBinFile, bool boIsArchive );
    bool           BuildInstallFileList( const char *cpDir, const char *cpBinFile );
    void           RemoveInstallFileList( void );

    void           InitManifestation( void );
    int            GetSensorProgress( void );
    int            GetDownloadStatus( void );
    int            GetDownloadChecksum( void );
    int            GetErasingStatus( void );
    int            GetProgrammingStatus( void );
    int            GetManifestationFinished( void );

    static CFwUpdater *m_pInstance;

    int            m_iProgress;
    char           m_szProgressInfo[ 1024 ];

protected:

}; // CFwUpdater




#endif //__FWUPDATER_H__
