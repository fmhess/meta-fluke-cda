/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: link.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2007-05-04
 *
 ***************************************************************************/

#ifndef __LINK_H__
#define __LINK_H__

namespace nrplib
{

class Link
{
public:
	struct noinit { };

	Link() : m_prev(this),m_next(this)
	{
	}
	virtual ~Link()
	{
	}
	explicit Link(Link *other)
	{
		add(*other);
	}
	explicit Link(noinit)
	{
	}
	// add this before the other
	void add(Link & other)
	{
		m_prev = other.m_prev;
		m_prev->m_next = this;
		m_next = &other;
		other.m_prev = this;
	}
	// erase this from the list
	void remove()
	{
		unlink();

		m_prev = m_next = this;
	}
	bool uniq() const
	{
		return m_prev == this;
	}
	Link * next()
	{
		return m_next;
	}
	Link * prev() 
	{
		return m_prev;
	}
//protected:
	void unlink()
	{
		m_prev->m_next = m_next;
		m_next->m_prev = m_prev;
	}
private:
	Link *	m_prev;
	Link *	m_next;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

