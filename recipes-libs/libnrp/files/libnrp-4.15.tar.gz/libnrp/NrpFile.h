// NrpFile.h: interface for the NrpFile class.
//
//////////////////////////////////////////////////////////////////////

#if ! defined(_NRPFILE_INCLUDED_)
#define _NRPFILE_INCLUDED_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef DEBUG
void Dump( unsigned char *p, unsigned int iSiz );
#endif

typedef struct tag_enable_mask
{
#if defined(__powerpc__)
    short dummy            : 2;
    short BitmaskRefuse    : 1;  // Bit 13
    short BitmaskPermit    : 1;  // Bit 12
    short HWSubVariantTo   : 1;  // Bit 11
    short HWSubVariantFrom : 1;  // Bit 10
    short HWVariantTo      : 1;  // Bit 9
    short HWVariantFrom    : 1;  // Bit 8
    short HWVersionTo      : 1;  // Bit 7
    short HWVersionFrom    : 1;  // Bit 6
    short SerialNrTo       : 1;  // Bit 5
    short SerialNrFrom     : 1;  // Bit 4
    short UsbProdStrg      : 1;  // Bit 3
    short UsbManufStrg     : 1;  // Bit 2
    short UsbProductID     : 1;  // Bit 1
    short UsbVendorID      : 1;  // Bit 0
#else
    short UsbVendorID      : 1;  // Bit 0
    short UsbProductID     : 1;  // Bit 1
    short UsbManufStrg     : 1;  // Bit 2
    short UsbProdStrg      : 1;  // Bit 3
    short SerialNrFrom     : 1;  // Bit 4
    short SerialNrTo       : 1;  // Bit 5
    short HWVersionFrom    : 1;  // Bit 6
    short HWVersionTo      : 1;  // Bit 7
    short HWVariantFrom    : 1;  // Bit 8
    short HWVariantTo      : 1;  // Bit 9
    short HWSubVariantFrom : 1;  // Bit 10
    short HWSubVariantTo   : 1;  // Bit 11
    short BitmaskPermit    : 1;  // Bit 12
    short BitmaskRefuse    : 1;  // Bit 13
    short dummy            : 2;
#endif
} ENABLE_MASK;


typedef union
{
    short       s;
    ENABLE_MASK bm;

} ENABLE_MASK_U;


typedef struct
{
    char           hMagicHeader[8];
    unsigned short hLength;
    ENABLE_MASK_U  hEnableMask;
//  ENABLE_MASK    hEnableMask;
    unsigned int   hTargetAddress;
    unsigned int   hStartAddress;
    unsigned short hVendorID;
    unsigned short hProductID;
    char           hManufactString[60];
    char           hProductString[60];
    char           hSerialNumberFrom[10];
    char           hSerialNumberTo[10];
    char           hHwVersionFrom[10];
    char           hHwVersionTo[10];
    char           hHwVariantFrom[10];
    char           hHwVariantTo[10];
    char           hHwSubVariantFrom[10];
    char           hHwSubVariantTo[10];
    unsigned int   hPermitMask;
    unsigned int   hRefuseMask;             //   232 bytes
    unsigned char  hSectionDescriptor;      // = TargetType
    unsigned char  hAlignmentDummy[3];      //   236 bytes
} FLASH_FILE_HEADER;



typedef struct
{
    unsigned int    BitmaskPermit;
    unsigned int    BitmaskRefuse;
    int             iVendorID;
    int             iProductID;
    char            szManufacturer[60];
    char            szProduct[60];
    char            szSerialNumber[10];
    char            szHwVersion[10];
    char            szHwVariant[10];
    char            szHwSubVariant[10];
} CHECK_DEVICE_INFO;




class CNrpFileHeader
{
public:
    CNrpFileHeader( const char *cpFlashFile, CHECK_DEVICE_INFO *pDevInfo );
    CNrpFileHeader( CHECK_DEVICE_INFO *pDevInfo, void *pFileData );
    virtual ~CNrpFileHeader();

public:
    bool              TestInRamOnly();
    bool              ReadHeader();
    bool              PerformCheck();

    int               Error( const char *cpError );
    char *            GetErrorText( void );

    unsigned short    GetHeaderSize( void )
    {
      short sRet = m_sFileHeader.hLength;
#if defined (__powerpc__)
      Swap( &sRet );
#endif

#if defined (DEBUG)
    fprintf( stderr, "CNrpFileHeader::GetHeaderSize() returns 0x%04x\n", sRet );
#endif

      return sRet;
    };

    unsigned int      GetTargetAddr( void )
    {
      unsigned int uiRet = m_sFileHeader.hTargetAddress;
#if defined (__powerpc__)
      Swap( &uiRet );
#endif

#if defined (DEBUG)
    fprintf( stderr, "CNrpFileHeader::GetTargetAddr() returns 0x%08x\n", uiRet );
#endif

      return uiRet;
    };

    unsigned int      GetStartAddr( void )
    {
      unsigned int uiRet = m_sFileHeader.hStartAddress;
#if defined (__powerpc__)
      Swap( &uiRet );
#endif

#if defined (DEBUG)
    fprintf( stderr, "CNrpFileHeader::GetStartAddr() returns 0x%08x\n", uiRet );
#endif

      return uiRet;
    };

    unsigned char         GetSectionDesc( void ) { return m_sFileHeader.hSectionDescriptor; };
    static   void         DisplayHeader( FLASH_FILE_HEADER *pHd );
    static   void         DisplayDevInfo( CHECK_DEVICE_INFO *pInfo );
    static   unsigned int Hex( const char *cpIn, unsigned short usLen );

#if defined(__powerpc__)
    static void           Swap( unsigned short *pUShort );
    static void           Swap( short *pShort );
    static void           Swap( unsigned int *pUInt );
    static void           Swap( int *pInt );
    static unsigned short Swap( unsigned short usIn );
    static short          Swap( short sIn );
    static unsigned int   Swap( unsigned int uiIn );
    static int            Swap( int iIn );
#endif

private:
    void              StoreDeviceInfo( CHECK_DEVICE_INFO *pDevInfo );

    FLASH_FILE_HEADER m_sFileHeader;            // This has ALWAYS i386 format
    unsigned int      m_dwSensorHwSubvariant;
    unsigned int      m_dwSensorHwVersion;
    unsigned int      m_dwSensorHwVariant;
    unsigned int      m_dwSensorBitmask;
    int               m_iFh;
    char              *m_cpErrorMsg;
    char              *m_cpFlashFile;
    bool              m_bInRamOnly;
    CHECK_DEVICE_INFO m_sDevInfo;

};



class CChecksum  
{
public:
    CChecksum();
    virtual ~CChecksum();

public:
    unsigned int    GetFileChecksum( int iFh, unsigned int uiOffset = 0 );
    unsigned int    MemChecksum( unsigned char *pData, unsigned long ulSize, unsigned long ulOffset );
    unsigned int    GetValue();
    void            ResetAccumulation();
    void            Accumulate( unsigned char ucDelta );

private:
    unsigned int    m_dwChecksum;
};





#endif // !defined(_NRPFILE_INCLUDED_)
