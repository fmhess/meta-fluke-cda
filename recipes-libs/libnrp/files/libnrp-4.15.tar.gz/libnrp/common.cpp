/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: common.cpp $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#include "common.h"

#ifdef UNICODE
#define TEXT(q) L##q
#else
#define TEXT(q) q
#endif
#ifndef _T
#define _T TEXT
#endif

void printmsg(const char *file, const char *func, int line, const char *fmt, ...)
{
	va_list		args;
	char		buf[4096];
	int		n;

	va_start(args, fmt);
	n = vsnprintf(buf, DIM(buf), fmt, args);
	va_end(args);

	fprintf(stderr, "Aborted in %s (%s:%d):\n %.*s\n", file, func, line, n, buf);
}

/* vi:set ts=4 sw=4: */

