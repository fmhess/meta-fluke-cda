/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: nrplib.cpp $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#include "nrpdevlist.h"
#include "nrplib.h"

//#define	DEBUG

using namespace nrplib;

static NrpDevList * nrp;

#pragma GCC visibility push(default)

long	DisableFirmwareLoad(void (*func)(const char *resourceDescriptor))
{
#ifdef DEBUG
	fprintf(stderr, ">%s (0x%08lx)\n", __FUNCTION__, (unsigned long)func);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->disableFirmwareLoad(func);
}

/*
 * returns the max number of root hubs for attached devices
 */
long GetRootHubCount(void)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getRootHubCount();
}

/*
 * returns the max number of ports for attached devices
 */
long GetHubPortCount(long)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getHubPortCount();
}

/*
 * returns the resource strings of a given hub and port number
 *
 * USB::0x0aad::0x000c::900001
 */
long GetPortResource(long HubIndex, long PortIndex, char* Resource)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getPortResource(HubIndex, PortIndex, Resource);
}

/*
 * returns the number of entries in the current device list
 */
long NrpGetDeviceListLength(long *pLength)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getDeviceListLength(pLength);
}

/*
 * return the device info of the given index
 */
long NrpGetDeviceInfo(long index, char name[], char type[], char serial[], long *pIsConnected)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getDeviceInfo(index, name, type, serial, pIsConnected);
}

/*
 * return the nrp resource name of a sensor
 */
long NrpGetResourceName(long index, char resource[], unsigned int maxLen)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getResourceName(index, resource, maxLen);
}

/*
 * scan the usb sub-system for rohde&schwarz devices and store them into a
 * list
 */
long NrpLockDeviceList(void)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif

	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->lockDeviceList();
}

/*
 * release the device list
 *
 * This function still exists for compatibility reasons
 */
long NrpCommitDeviceList(void)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return NRP_SUCCESS;
}

long NrpGetData(long session, long *pBlockType, long *pGroupNr, long *pParamNr)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getData(session, pBlockType, pGroupNr, pParamNr);
}

long NrpGetFloatArrayLength(long session, long * pSize)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getFloatArrayLength(session, pSize);
}

long NrpGetFloatArray(long session, float *pArray, long arraySize, long *pReadCount)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getFloatArray(session, pArray, arraySize, pReadCount);
}

long NrpGetFloatResult(long session, float *pFloatVal1, float *pFloatVal2, float *pFloatVal3)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getFloatResult(session, pFloatVal1, pFloatVal2, pFloatVal3);
}

long NrpGetLongResult(long session, long *pLongVal1, long *pLongVal2, long *pLongVal3)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getLongResult(session, pLongVal1, pLongVal2, pLongVal3);
}

long NrpGetBitfieldResult(long session, long *pBitVal1, long *pBitVal2, long *pBitVal3)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getBitfieldResult(session, pBitVal1, pBitVal2, pBitVal3);
}

long NrpGetStringResultLength(long session, long * pSize)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getStringResultLength(session, pSize);
}

long NrpGetStringResult(long session, char *pBuffer, long size)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getStringResult(session, pBuffer, size);
}

long NrpGetBinaryResultLength(long session, long * pSize)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getBinaryResultLength(session, pSize);
}

long NrpGetBinaryResult(long session, unsigned char *pBuffer, long buflen, long *size)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getBinaryResult(session, pBuffer, buflen, size);
}

long NrpGetAuxFloatArrayLength(long session, long * pSize)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getAuxFloatArrayLength(session, pSize);
}

long NrpGetAuxFloatArray(long session, float * pResult, float * pAux1, float * pAux2, long arrayLength, long * pReadCount)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getAuxFloatArray(session, pResult, pAux1, pAux2, arrayLength, pReadCount);
}

long NrpEmptyAllBuffers(long session)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->emptyAllBuffers(session);
}

long NrpGetTriggerState(long session, long *state)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getTriggerState(session, state);
}

long NrpGetError(long session, long *pError)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getError(session, pError);
}

long NrpEmptyErrorQueue(long session)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->emptyErrorQueue(session);
}

long NrpGetErrorText(long errorcode, char pBuffer[], long size)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
/*
 * Error messages.
 * Every error code should have associated error message.
 * If the error code does not have associated error message, function
 * NrpGetErrorText() returns "Unknown Error Code (<error code in hex> )"
 * NrpControl knows three kinds of errors:
 * 1) USB error codes           0xE0000000 - 0xEFFFFFFF
 * 2) Sensor specific errors    0xD0000000 - 0xDFFFFFFF
 * 3) NrpControl errors         0xC0000000 - 0xCFFFFFFF
 */
    static struct {
        long                code;
        const char * const  text;
    } errorMessages[] = {
        { (long)NRP_SUCCESS,                            "No Error." },
// NrpControl error codes
        { (long)NRP_ERROR_USB_DISCONNECTED,             "Driver has not been initialized." },
        { (long)NRP_ERROR_INVALID_RESOURCE,             "Invalid resource. Incorrect format or device is not available." },
        { (long)NRP_ERROR_NOT_SUPPORTED_CALLBACK,       "Callback does not supported." },
        { (long)NRP_ERROR_TIMEOUT,                      "Timeout before operation complete." },
        { (long)NRP_ERROR_DEVICE_DISCONNECTED,          "Device has been disconnected." },
        { (long)NRP_ERROR_INVALID_SESSION,              "Invalid session." },
        { (long)NRP_ERROR_CONFIGURATION_STORE,          "Configuration store error." },
        { (long)NRP_ERROR_DESCRIPTOR_INDEX,             "Invalid index for USB resource descriptor." },
        { (long)NRP_ERROR_LOGICAL_NAME_EXIST,           "Different device is using specified logical name." },
        { (long)NRP_ERROR_DATA_QUEUE_EMPTY,             "Data queue is empty." },
        { (long)NRP_ERROR_STRING_QUEUE_EMPTY,           "String data queue is empty." },
        { (long)NRP_ERROR_FLOAT_QUEUE_EMPTY,            "Float data queue is empty." },
        { (long)NRP_ERROR_LONG_QUEUE_EMPTY,             "Long data queue is empty." },
        { (long)NRP_ERROR_BITFIELD_QUEUE_EMPTY,         "Bitfield data queue is empty." },
        { (long)NRP_ERROR_BINARY_QUEUE_EMPTY,           "Binary data queue is empty." },
        { (long)NRP_ERROR_FLOAT_ARRAY_QUEUE_EMPTY,      "Float array data queue is empty." },
        { (long)NRP_ERROR_PARAMETER1,                   "Parameter 1 is not valid or NULL pointer." },
        { (long)NRP_ERROR_PARAMETER2,                   "Parameter 2 is not valid or NULL pointer." },
        { (long)NRP_ERROR_PARAMETER3,                   "Parameter 3 is not valid or NULL pointer." },
        { (long)NRP_ERROR_PARAMETER4,                   "Parameter 4 is not valid or NULL pointer." },
        { (long)NRP_ERROR_PARAMETER5,                   "Parameter 5 is not valid or NULL pointer." },
        { (long)NRP_ERROR_PARAMETER6,                   "Parameter 6 is not valid or NULL pointer." },
        { (long)NRP_ERROR_SMALL_BUFFER_SIZE,            "All data has not been readed successfully" },
        { (long)NRP_ERROR_UNKNOWN_TRIGGER_STATE,        "Unknown trigger state." },
        { (long)NRP_ERROR_INVALID_SERIAL_NUMBER,        "Invalid serial number." },
        { (long)NRP_ERROR_INVALID_SENSOR_TYPE,          "Invalid sensor type." },
        { (long)NRP_ERROR_INCORRECT_DATA_ORDER,         "Incorrect data order. Use first NrpGetData(), before you query data." },
        { (long)NRP_ERROR_UNKNOWN_ATTRIBUTE,            "Unknown attribute ID." },
        { (long)NRP_ERROR_DEVICE_COMMUNICATION_ERROR,   "New device pluged, but does not communicate." },
    // USB device error codes
        { (long)NRP_ERROR_DEVICE_CALDATA_FORMAT,        "Format of the calibration data set." },
        { (long)NRP_ERROR_DEVICE_OVERRANGE,             "Input overdriven." },
        { (long)NRP_ERROR_DEVICE_NOTINSERVICEMODE,      "Command allowed only in service mode." },
        { (long)NRP_ERROR_DEVICE_CALZERO,               "Error in zero calibration." },
        { (long)NRP_ERROR_DEVICE_TRIGGERQUEUEFULL,      "Trigger queue full; measurement terminated." },
        { (long)NRP_ERROR_DEVICE_EVENTQUEUEFULL,        "Event queue full." },
        { (long)NRP_ERROR_DEVICE_SAMPLEERROR,           "Erroneous sampling value." },
        { (long)NRP_ERROR_DEVICE_OVERLOAD,              "Permissible input power exceeded." },
        { (long)NRP_ERROR_DEVICE_HARDWARE,              "Hardware error, result possibly incorrect." },
        { (long)NRP_ERROR_DEVICE_CHECKSUM,              "Erroneous checksum." },
        { (long)NRP_ERROR_DEVICE_ILLEGALSERIAL,         "Serial number of calibration data <> serial number of sensor." },
        { (long)NRP_ERROR_DEVICE_FILTERTRUNCATED,       "The automatic averaging filter was truncated due to MTIME criterion." },
        { (long)NRP_ERROR_DEVICE_BURST_TOO_SHORT,       "Burst mode: The detected burst is too short for a measurement; the measurement result does not contain any samples." },
        { (long)NRP_ERROR_DEVICE_GENERIC,               "Generic error." },
        { (long)NRP_ERROR_DEVICE_OVERMAX,               "Parameter value too large." },
        { (long)NRP_ERROR_DEVICE_UNDERMIN,              "Parameter value too small." },
        { (long)NRP_ERROR_DEVICE_VOLTAGE,               "Voltage supply missing or too low." },
        { (long)NRP_ERROR_DEVICE_SYNTAX,                "Syntax error." },
        { (long)NRP_ERROR_DEVICE_MEMORY,                "Insufficient memory." },
        { (long)NRP_ERROR_DEVICE_PARAMETER,             "Incorrect parameter." },
        { (long)NRP_ERROR_DEVICE_TIMING,                "Realtime condition violated. Result invalid." },
        { (long)NRP_ERROR_DEVICE_NOTIDLE,               "Command not allowed while measurement in progress." },
        { (long)NRP_ERROR_DEVICE_UNKNOWNCOMMAND,        "Unknown command." },
        { (long)NRP_ERROR_DEVICE_OUTBUFFERFULL,         "Output buffer full." },
        { (long)NRP_ERROR_DEVICE_FLASHPROG,             "Error during programming of flash memory." },
        { (long)NRP_ERROR_DEVICE_CALDATANOTPRESENT,     "No calibration data available." },
        { (long)NRP_ERROR_RESTRICTED_FOR_ONE_SENSOR,    "Function restricted only for one sensor" },
        { (long)NRP_ERROR_BOOTLOADER_FAIL,              "Firmware update has not been initialized in 5 seconds." },
        { (long)NRP_ERROR_SESSION_DESTROY,              "Session for open sensor has been destroyed. Open new session again." },
        { (long)NRP_ERROR_NOT_CONNECTED_SENSOR,         "Sensor is not connected." },
        { (long)NRP_ERROR_INVALID_FILENAME,             "Invalid filename or File not found." },
        { (long)NRP_ERROR_SENSOR_IN_USE,                "Sensor is in use" },
        { 0, NULL },
    };

    unsigned i;

    for (i = 0; errorMessages[i].code != errorcode; i++) {
        if (! errorMessages[i].text)
            return snprintf(pBuffer, size, "Unknown Error Code (0x%08lx)", (unsigned long)errorcode)+1;
    }

    return snprintf(pBuffer, size, "%s", errorMessages[i].text)+1;
}

long NrpGetTriggerStateText(long errorcode, char pBuffer[], long size)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	/*
	 * States of the sensor trigger system into readable text
	 * Used in NrpGetTriggerStateText() function.
	 */
	static struct {
		long				code;
		const char * const	text;
	} triggerMessages[] = {
		{ NRP_TRIGGER_UNKNOWN,			"Unknown" },
		{ NRP_TRIGGER_IDLE,				"Idle" },
		{ NRP_TRIGGER_RESERVED,			"Reserved" },
		{ NRP_TRIGGER_WAIT_FOR_TRIGGER,	"Wait For Trigger" },
		{ NRP_TRIGGER_MEASURING,		"Measuring" },
		{ 0,							NULL }
	};

	unsigned	i;

	for (i = 0; triggerMessages[i].code != errorcode; i++) {
		if (!triggerMessages[i].text)
			return NRP_ERROR_UNKNOWN_TRIGGER_STATE;
	}

	return snprintf(pBuffer, size, "%s", triggerMessages[i].text)+1;
};

long NrpSendCommand(long session, const char *command, long timeout)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->sendCommand(session, command, timeout);
}

long NrpWriteDL(long session, const void *command, long count, long timeout)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->writeDL(session, command, count, timeout);
}

long NrpSendBinaryBlock(long session, const char *command, void *pBuffer, long count, long timeout)
{
#ifdef DEBUG
	fprintf(stderr, " > %s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->sendBinaryBlock(session, command, pBuffer, count, timeout);
}

long NrpGetDescriptor(long session, struct nrpz_sensor_info * descr)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getDescriptor(session, descr);
}

long NrpGetVendorProductID(long session, char *cpManuf, long lSize, int *piVendorID, int *piProductID)
{
	struct nrpz_sensor_info descr;
	long ret;

#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	ret = NrpGetDescriptor(session, &descr);

	if (ret == NRP_SUCCESS) {
		if (cpManuf && lSize)
			strncpy(cpManuf, descr.manufacturer, lSize-1);

		if (piVendorID)
			*piVendorID = descr.vendorId;

		if (piProductID)
			*piProductID = descr.productId;
	}
	return ret;
}

long NrpDataAvailable(long session, long *pDataCount)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->dataAvailable(session, pDataCount);
}

long NrpOpenSensor(const char *resourceDescriptor, long *pHandle)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->openSensor(resourceDescriptor, pHandle);
}

long NrpCloseSensor(long session)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->closeSensor(session);
}

long NrpClearDevice(long session)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->clearDevice(session);
}

/*
 * Registers the callback for device changed event.
 */
long NrpSetNotifyCallbackDeviceChanged(Nrp_DeviceChangedFuncPtr callbackPtr, long usrArgument)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->setNotifyCallbackDeviceChanged(callbackPtr, usrArgument);
}

/*
 * Registers the callback for still alive event.
 */
long NrpSetNotifyCallbackStillAlive(Nrp_StillAliveFuncPtr callbackPtr, long usrArgument)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->setNotifyCallbackStillAlive(callbackPtr, usrArgument);
}

long NrpSetNotifyCallbackDataAvailable(Nrp_DataAvailableFuncPtr callbackPtr, long usrArgument)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->setNotifyCallbackDataAvailable(callbackPtr, usrArgument);
}

/*
 * Registers the callback for command accepted event.
 */
long NrpSetNotifyCallbackCommandAccepted(Nrp_CommandAcceptedFuncPtr callbackPtr, long usrArgument)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->setNotifyCallbackCommandAccepted(callbackPtr, usrArgument);
}

/*
 * Registers the callback for error occured event.
 */
long NrpSetNotifyCallbackErrorOccurred(Nrp_ErrorOccurredFuncPtr callbackPtr, long usrArgument)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->setNotifyCallbackErrorOccurred(callbackPtr, usrArgument);
}

/*
 * Registers the callback for state changed event.
 */
long NrpSetNotifyCallbackStateChanged(Nrp_StateChangedFuncPtr callbackPtr, long usrArgument)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->setNotifyCallbackStateChanged(callbackPtr, usrArgument);
}

long NrpOpenDriver(void)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	int ret = NRP_SUCCESS;

	if (nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	try {
		nrp = new NrpDevList;
	}
	catch(const char *s)
	{
		fprintf(stderr, "nrp object:%s\n", s);

		ret = NRP_ERROR_INVALID_RESOURCE;
	}

	return ret;
}

long NrpCloseDriver(void)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	delete nrp;

	nrp = 0;

	return NRP_SUCCESS;
}

/*
 * Sets a specified attribute for given object.
 */
long NrpSetAttribute(long session, unsigned long attrName, long attrValue)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->setAttribute(session, attrName, attrValue);
}

/*
 * Queries the specified attribute for a given object.
 */
long NrpGetAttribute(long session, unsigned long attrName, void* pAttrValue)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getAttribute(session, attrName, pAttrValue);
}

long NrpGetSensorInfo(long session, char name[], char type[], char serial[])
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getSensorInfo(session, name, type, serial);
}

long NrpSendVendorInRequest(long session, char *pBuffer, long count, long request, long index)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif

	return nrp->sendVendorInRequest(session, pBuffer, count, request, index);

}

long NrpSendVendorOutRequest(long session, long request, long index, long value)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->sendVendorOutRequest(session, request, index, value);
}


long NrpGetDeviceStatusZ5(void)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif

	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;
    
	if (nrp->getDeviceStatusZ5())
		return NRP_SUCCESS;
    
	return NRP_ERROR_DEVICE_DISCONNECTED;
}

long NrpGetDeviceInfoZ5(long index, char name[], char type[], char serial[], long *pIsConnected)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->getDeviceInfoZ5(index, name, type, serial, pIsConnected);
}

long NrpOpenSensorOnZ5(char port, long *pHandle)
{
	char szResource[128];
	long ret;

#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif

	port = toupper(port);

	if ((port < 'A') || (port > 'D'))
		return NRP_ERROR_INVALID_RESOURCE;

	ret = NrpGetDeviceInfoZ5(port - 'A', szResource, 0, 0, NULL);

	if (ret != NRP_SUCCESS)
		return ret;

	return NrpOpenSensor(szResource, pHandle);
}

long NrpDiscardResult(long session)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif

	if (!nrp)
		return NRP_ERROR_INVALID_RESOURCE;

	return nrp->discardResult(session);

}

long NrpGetUsageMap(char *cpMap, unsigned long nMapSize, unsigned long *pulRetSize)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif

    if (!nrp)
        return NRP_ERROR_INVALID_RESOURCE;

    return nrp->getUsageMap(cpMap, nMapSize, pulRetSize);
}

/*
 * the following functions are yet not functionality implemented
 */
long NrpSetDeviceInfo(long index, char *pname, char *ptype, char *pserial)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	return 0;
}

long NrpAddDeviceInfo(const char *pname, const char *ptype, const char *pserial)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	return -1;
}

long NrpDeleteDeviceInfo(long index)
{
#ifdef DEBUG
	fprintf(stderr, ">%s\n", __FUNCTION__);
#endif
	return -1;
}

#include "fwupdater.h"

long NrpUpdateOpen(const char *cpResourceName, const char *cpUpdateFileNRP, long *pSession)
{
#ifdef USE_FWUPDATE
	CFwUpdater*		pUpdater = NULL;
	long			lError = NRP_SUCCESS;

	if (!pSession)
		return NRP_ERROR_PARAMETER3;

	pUpdater = CFwUpdater::GetInstance(cpResourceName, cpUpdateFileNRP);

	if (pUpdater) {
		if (!pUpdater->Update()) // starts Update-Thread
			lError = pUpdater->GetStatus();
	}

	*pSession = reinterpret_cast<long>(pUpdater);

	return lError;
#else
	return NRP_ERROR_INVALID_RESOURCE;
#endif
}

long NrpUpdateGetError(long session)
{
#ifdef USE_FWUPDATE
	if (!session)
		return NRP_ERROR_INVALID_SESSION;

	CFwUpdater * pUpdater = reinterpret_cast<CFwUpdater *>(session);

	return pUpdater->GetError();
#else
	return NRP_ERROR_INVALID_RESOURCE;
#endif
}

int NrpUpdateGetProgress(long session)
{
#ifdef USE_FWUPDATE
	if (!session)
		return 0;

	CFwUpdater * pUpdater = reinterpret_cast<CFwUpdater *>(session);

	return pUpdater->GetProgress();
#else
	return NRP_ERROR_INVALID_RESOURCE;
#endif
}

const char * NrpUpdateGetInfoText(long session)
{
#ifdef USE_FWUPDATE
	if (!session)
		return "";

	CFwUpdater * pUpdater = reinterpret_cast<CFwUpdater *>(session);

	return pUpdater->GetProgressInfo();
#else
	return "";
#endif
}

long NrpUpdateCancel(long session)
{
#ifdef USE_FWUPDATE
	if (!session)
		return NRP_ERROR_INVALID_SESSION;

	CFwUpdater * pUpdater = reinterpret_cast<CFwUpdater *>(session);

	pUpdater->Cancel();	// Cancels any current I/O, RESETs sensor
						// and stops the internal thread
	return NRP_SUCCESS;
#else
	return NRP_ERROR_INVALID_RESOURCE;
#endif
}

long NrpUpdateClose(long *pSession)
{
#ifdef USE_FWUPDATE
	if (!pSession)
		return NRP_ERROR_PARAMETER1;

	if (!*pSession)
		return NRP_ERROR_INVALID_SESSION;

	CFwUpdater * pUpdater = reinterpret_cast<CFwUpdater *>(*pSession);

	*pSession = 0;

	pUpdater->Destroy();

	return NRP_SUCCESS;
#else
	return NRP_ERROR_INVALID_RESOURCE;
#endif
}

long NrpUpdateGetState(long session, int *piState)
{
#ifdef USE_FWUPDATE
	if (!session)
		return NRP_ERROR_INVALID_SESSION;

	CFwUpdater * pUpdater = reinterpret_cast<CFwUpdater *>(session);

	if (piState) {
		*piState = pUpdater->GetThreadState();
		return NRP_SUCCESS;
	}
#else
	return NRP_ERROR_INVALID_RESOURCE;
#endif
	return NRP_ERROR_PARAMETER1;
}

#pragma GCC visibility pop

#if 0
int main(void)
{
	printf("%ld\n", NrpOpenDriver());
	for(;;)
		pause();
	return 0;
}
#endif

/* vi:set ts=4 sw=4: */

