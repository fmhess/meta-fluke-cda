/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: nrpdevice.cpp $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#include <assert.h>
#include <sstream>
#include <errno.h>

#include "common.h"
#include "exception.h"
#include "nrpdevice.h"
#include "nrpdevlist.h"

/* packet signature */
#define	NRPTYPE_SINGLE_VALUE			'E'	// Measurement Value (Single)
#define	NRPTYPE_INTERIM_VALUE			'e'	// Measurement Value (Intermediate)
#define	NRPTYPE_ARRAY					'A'	// Measurement Value (Array)
#define	NRPTYPE_ARRAY_AUX_PEAK			'P'	// Measurement Value (Array w/ Aux or Peak)
#define	NRPTYPE_ARRAY_INTERIM			'a'	// Measurement Value (Array intermediate)
#define	NRPTYPE_ARRAY_INTERIM_AUX_PEAK	'p'	// Measurement Value (Array intermediate w/ Aux or Peak)
#define	NRPTYPE_FEATURE					'F'	// Features
#define	NRPTYPE_LIMIT_FLOAT				'U'	// Float limit
#define	NRPTYPE_LIMIT_BITFIELD			'V'	// Bitfield limit
#define	NRPTYPE_LIMIT_INTEGER			'W'	// Integer limit
#define	NRPTYPE_STRING_DATA				'T'	// String/Text
#define	NRPTYPE_RECEIPT					'R'	// Acknowledgement
#define	NRPTYPE_INTERNAL_ERROR			'X'	// Internal error
#define	NRPTYPE_STATE					'Z'	// (Measurement) State
#define	NRPTYPE_ALIVE					'z'	// Still alive message
#define	NRPTYPE_PARAM_FLOAT				'L'	// Float Parameter 
#define	NRPTYPE_PARAM_BITFIELD			'M'	// Bitfield Parameter
#define	NRPTYPE_PARAM_INTEGER			'N'	// Integer Parameter
#define	NRPTYPE_BINARY_DATA				'B'	// Binary Data

using namespace nrplib;

long NrpDevice::peek(long *pBlockType, long *pGroupNr, long *pParamNr)
{
	if (m_sequence.empty())
		return NRP_ERROR_DATA_QUEUE_EMPTY; // check

	NrpObj * c = dynamic_cast < NrpObj * > (m_sequence.first());

	if (pBlockType)
		*pBlockType = c->getDataType();

	if (pGroupNr)
		*pGroupNr = c->getGroupNo();

	if (pParamNr)
		*pParamNr = c->getParamNo();

	return NRP_SUCCESS;
}

void NrpDevice::dispatch()
{
	u32			errCode;
	u8			signature;
	Packet		p;

	Synchronize	nprdev_sync(m_mutex);

	while(getUsbDevice().read(p) == sizeof(packet_t)) {

		signature = p.getSignature();
		errCode = p.getErrCode();

		if ((errCode != NRP_SUCCESS) && (signature != NRPTYPE_ALIVE))
			nrp_error(errCode+NRP_ERROR_DEVICE_OFFSET);

        if ((signature != NRPTYPE_ARRAY)
          && (signature != NRPTYPE_ARRAY_AUX_PEAK)
          && (p.getGroupNo() == 0x10)
		 ) {
            // The PARAMETER part of an automatic pulse analysis measurement
            // starts now. Therefore we first push the (already received)
            // result array
            if ((DATA_FLOATARRAY    == m_tCollecting)
              || (DATA_AUXFLOATARRAY == m_tCollecting)
			 ) {
                Packet dummy;

                if (DATA_FLOATARRAY == m_tCollecting)
                    m_array.push(m_nrplist->dataAvailableCallback(), m_session, NrpArray(DATA_FLOATARRAY, dummy, m_realData.yank()));
                if (DATA_AUXFLOATARRAY == m_tCollecting)
					m_auxArray.push(m_nrplist->dataAvailableCallback(), m_session, NrpAuxArray(DATA_AUXFLOATARRAY, dummy, m_realData.yank()));

                m_tCollecting = DATA_NROF;
            }
        }

		switch(signature) {
		case NRPTYPE_SINGLE_VALUE:
			nrptype_single_value(p);
			break;
		case NRPTYPE_INTERIM_VALUE:
			nrptype_interim_value();
			break;
		case NRPTYPE_ARRAY:
			nrptype_array(p);
			break;
		case NRPTYPE_ARRAY_AUX_PEAK:
			nrptype_array_aux_peak(p);
			break;
		case NRPTYPE_ARRAY_INTERIM:
			nrptype_array_interim();
			break;
		case NRPTYPE_ARRAY_INTERIM_AUX_PEAK:
			nrptype_array_interim_aux_peak();
			break;
		case NRPTYPE_FEATURE:
			nrptype_feature(p);
			break;
		case NRPTYPE_LIMIT_FLOAT:
			nrptype_limit_float(p);
			break;
		case NRPTYPE_LIMIT_BITFIELD:
			nrptype_limit_bitfield(p);
			break;
		case NRPTYPE_LIMIT_INTEGER:
			nrptype_limit_integer(p);
			break;
		case NRPTYPE_STRING_DATA:
			nrptype_string_data(p);
			break;
		case NRPTYPE_RECEIPT:
			nrptype_receipt(p);
			break;
		case NRPTYPE_INTERNAL_ERROR:
			nrptype_internal_error();
			break;
		case NRPTYPE_STATE:
			nrptype_state(p);
			break;
		case NRPTYPE_ALIVE:
			nrptype_alive(p);
			break;
		case NRPTYPE_PARAM_FLOAT:
			nrptype_param_float(p);
			break;
		case NRPTYPE_PARAM_BITFIELD:
			nrptype_param_bitfield(p);
			break;
		case NRPTYPE_PARAM_INTEGER:
			nrptype_param_integer(p);
			break;
		case NRPTYPE_BINARY_DATA:
			nrptype_binary_data(p);
			break;
		default:
			break;
		}
	}
}

/**
 * update trigger state.
 * The device can be in one from following trigger states:
 *	NRP_TRIGGER_IDLE				(0)
 *	NRP_TRIGGER_RESERVED			(1) (was: WAIT_FOR_ARM)
 *	NRP_TRIGGER_WAIT_FOR_TRIGGER	(2)
 *	NRP_TRIGGER_MEASURING			(3)
 *
 * \param newTriggerState 
 * \return true if the trigger has been changed, otherwise false.
 */
bool NrpDevice::updateTriggerState(u8 newTriggerState)
{
	if (newTriggerState == m_triggerState)
		return false;

	m_triggerState = newTriggerState;

	m_nrplist->stateChangedCallback().call(m_session, newTriggerState);

	return true;
}

void NrpDevice::nrptype_array(Packet &p)
{
	u16		index;
	u32		count;

	assert(m_tCollecting == DATA_FLOATARRAY || m_tCollecting == DATA_NROF);

	index = p.getIndex();

	m_tCollecting = DATA_FLOATARRAY;

	count = m_realData->size();

	if (index < count) {
		// float block complete
		m_array.push(m_nrplist->dataAvailableCallback(), m_session, NrpArray(DATA_FLOATARRAY, p, m_realData.yank()));

		count = 0;
	}

	if (index == count) {
		m_realData->push_back(p.getFloat1());

		if (p.getULong2() != 0xFFFFFFFF) {
			m_realData->push_back(p.getFloat2());

			if (p.getULong3() != 0xFFFFFFFF)
				m_realData->push_back(p.getFloat3());
		}
		else {
			/*
			 * TODO: Ask is possible
			 */
			assert(p.getULong2() == 0xFFFFFFFF);
			assert(p.getULong3() == 0xFFFFFFFF);
		}
	}
}

void NrpDevice::nrptype_array_aux_peak(Packet &p)
{
	u16		index;
	u32		count;

	assert(m_tCollecting == DATA_AUXFLOATARRAY || m_tCollecting == DATA_NROF);

	index = 3 * p.getIndex();

	m_tCollecting = DATA_AUXFLOATARRAY;

	count = m_realData->size();

	if ((index < count) && count) {
		// float block complete
		m_auxArray.push(m_nrplist->dataAvailableCallback(), m_session, NrpAuxArray(DATA_AUXFLOATARRAY, p, m_realData.yank()));

		count = 0;
	}

	if (index == count) {
		m_realData->push_back(p.getFloat1());
		m_realData->push_back(p.getFloat2());
		m_realData->push_back(p.getFloat3());
	}
}

void NrpDevice::nrptype_array_interim()
{
}

void NrpDevice::nrptype_array_interim_aux_peak()
{
}

void NrpDevice::nrptype_single_value(Packet &p)
{
	if (DATA_FLOATARRAY == m_tCollecting) {
		m_tCollecting = DATA_NROF;

		// float block complete
		m_array.push(m_nrplist->dataAvailableCallback(), m_session, NrpArray(DATA_FLOATARRAY, p, m_realData.yank()));
	}
	m_float.push(m_nrplist->dataAvailableCallback(), m_session, NrpFloat(DATA_FLOATRESULT, p));

	updateTriggerState(p.getState());
}

void NrpDevice::nrptype_interim_value()
{
}

//
// Binary block
//
void NrpDevice::nrptype_binary_data(Packet &p)
{
	u32			index;
	u8			count;
	const u8 *	data;

	// value1:
	//   bytes 0, 1: two lowest bytes of index (index modulo 65536)
	//   byte 2: number of valid bytes
	//   byte 3: first useful information byte
	// value2: 4 bytes of useful information
	// value3: 4 bytes of useful information

	index = p.getU16(4);	// This index is NOT usable for the
							//   resulting data because it wraps
							//   at 64k !!!
	count = p.getU8(6);
	data  = p.getAddr(7);

	assert(count <= 9);

	m_tCollecting = DATA_BINARYBLOCK;

	index = m_binaryData->size();
  
	m_binaryData->resize(index + count);

	std::copy(data, data + count, m_binaryData->end() - count);
}

//
// Features: Sent only during initialization
//
void NrpDevice::nrptype_feature(Packet &p)
{
	m_bitfield.push(m_nrplist->dataAvailableCallback(), m_session, NrpBitfield(DATA_BITFIELDFEATURE, p));
}

//
// Float 32 parameter received
//
void NrpDevice::nrptype_param_float(Packet &p)
{
	m_float.push(m_nrplist->dataAvailableCallback(), m_session, NrpFloat(DATA_FLOATPARAM, p));
}

//
// Integer 32 parameter recieved
//
void NrpDevice::nrptype_param_integer(Packet &p)
{
	m_long.push(m_nrplist->dataAvailableCallback(), m_session, NrpLong(DATA_LONGPARAM, p));
}

//
// Bit field parameter received
//
void NrpDevice::nrptype_param_bitfield(Packet &p)
{
	m_bitfield.push(m_nrplist->dataAvailableCallback(), m_session, NrpBitfield(DATA_BITFIELDPARAM, p));
}

void NrpDevice::nrptype_receipt(Packet &p)
{
	switch(m_tCollecting) {
	case DATA_STRING:
		m_tCollecting = DATA_NROF;

		m_string.push(m_nrplist->dataAvailableCallback(), m_session, NrpString(DATA_STRING, p, m_stringData.yank()));

		break;
	case DATA_BINARYBLOCK:
		m_tCollecting = DATA_NROF;

		m_binary.push(m_nrplist->dataAvailableCallback(), m_session, NrpBinary(DATA_BINARYBLOCK, p, m_binaryData.yank()));

		break;
	default:
		break;
	} // switch

	// An acknowledgement is sent in response to setting commands and
	// completes their execution. If limit values have changed as result
	// of a setting command, corresponding limit value blocks are sent
	// prior of the acknowledgement block.
	m_isAcknowledge.set(); 

	// Callback for accpeted event required information
	// about accepted group and parameter.
	//	  bits 0...7:  group number
	//	  bits 8...16: parameter number
	//	  bits 16..31: null/reserved

	m_nrplist->commandAcceptedCallback().call(m_session, p.getGroupNo()|((p.getParamNo()) << 8));
}

//
// Strings are sent in response to specific commands. 
//
// A maximum length is defined for each command. A substring with
// a length of 10 is sent with each block. The last subblock
// is filled with zeroes, and one of these is included
// in the maximum length count.
//
void NrpDevice::nrptype_string_data(Packet &p)
{
	u32			index;
	const u8 *	text;

	index = p.getU16(4);
	text = p.getAddr(6);

	m_tCollecting = DATA_STRING;

	// Sensor with revision less as 3.0 returns
	// test:sensor? in couple strings. we needs
	// fix this problem

	if ((p.getGroupNo() == 0x0C) && (p.getParamNo() == 0x01)) {
		if (!index) {
			// test:sensor? returns other packet
			// and we will collect next result
			if (!m_stringData->empty()) {
				if ((*m_stringData)[m_stringData->length()-1] != _T('\n'))
					*m_stringData += _T('\n');
			}
		}
	}
	else {
		if (!index) {
			if (!m_stringData->empty()) {
				m_string.push(m_nrplist->dataAvailableCallback(), m_session, NrpString(DATA_STRING, p, m_stringData.yank()));
			}
		}
	}

	while(m_stringData->size() < index)
		*m_stringData += _T('?');

	for(unsigned n = 0; n != 10; n++)
		*m_stringData += _T(text[n]);
}

//
// Limit Value: FLOAT 32 parameter
//
void NrpDevice::nrptype_limit_float(Packet &p)
{
	m_float.push(m_nrplist->dataAvailableCallback(), m_session, NrpFloat(DATA_FLOATLIMIT, p));
}

//
// Limit Value: Bit-field parameter 
//
void NrpDevice::nrptype_limit_bitfield(Packet &p)
{
	m_bitfield.push(m_nrplist->dataAvailableCallback(), m_session, NrpBitfield(DATA_BITFIELDLIMIT, p));
}

//
// Limit Value: INTEGER 32 parameter
//
void NrpDevice::nrptype_limit_integer(Packet &p)
{
	m_long.push(m_nrplist->dataAvailableCallback(), m_session, NrpLong(DATA_LONGLIMIT, p));
}

// State blocks are always sent when the trigger system changes
// the state. Since state transitions are not automatically
// synchronized with the reception of commands, the base unit must
// always be able to accept ant evaluate state blocks.
void NrpDevice::nrptype_state(Packet &p)
{
	u8 state = p.getState();

	// If date are collecting and sensor change state to idle
	// or wait for trigger state all data has been received.
	if ((DATA_FLOATARRAY == m_tCollecting) &&
		 ((NRP_TRIGGER_IDLE             == state) ||
		  (NRP_TRIGGER_WAIT_FOR_TRIGGER == state))
	) {
		m_tCollecting = DATA_NROF;

		m_array.push(m_nrplist->dataAvailableCallback(), m_session, NrpArray(DATA_FLOATARRAY, p, m_realData.yank()));
		// float block complete
	}
	else
	// If date are collecting and sensor change state to idle
	// or wait for trigger state all data has been received.
	if ((DATA_AUXFLOATARRAY == m_tCollecting) &&
		 ((NRP_TRIGGER_IDLE             == state) ||
		  (NRP_TRIGGER_WAIT_FOR_TRIGGER == state))
	 ) {
		m_tCollecting = DATA_NROF;

		// float block complete
		m_auxArray.push(m_nrplist->dataAvailableCallback(), m_session, NrpAuxArray(DATA_AUXFLOATARRAY, p, m_realData.yank()));
	}

	updateTriggerState(state);
}

//
// Still-Alive is always sent if a data block is not sent
// to the base unit within 200ms after a measurement was started
//
void NrpDevice::nrptype_alive(Packet &p)
{
	u8 state = p.getState();

	m_nrplist->stillAliveCallback().call(m_session, state);
}

void NrpDevice::nrptype_internal_error()
{
}

void NrpDevice::nrp_error(long errCode)
{
	if (m_nrplist->errorOccurredCallback().call(m_session, errCode))
		m_errorQueue.push(ErrorInfo(errCode));
}

long NrpDevice::getFloatArrayResultSize()
{
	if (m_array.empty())
		throw NrpException(NRP_ERROR_FLOAT_ARRAY_QUEUE_EMPTY);

	return m_array.front().getData().size();
}

long NrpDevice::getFloatArrayResult(float *pArray, long arraySize, long *pReadCount)
{
	if (m_array.empty())
		throw NrpException(NRP_ERROR_FLOAT_ARRAY_QUEUE_EMPTY);

	const Real & v = m_array.front().getData();

	if (arraySize > long(v.size()))
		arraySize = long(v.size());

	if (pArray) {
		long	i;

		for(i = 0; i != arraySize; i++)
			*pArray++ = v[i];

		if (pReadCount)
			*pReadCount = i;

		arraySize = v.size();
	}

	m_array.pop();

	return arraySize;
}

long NrpDevice::getAuxFloatArrayResultSize()
{
	if (m_auxArray.empty())
		throw NrpException(NRP_ERROR_FLOAT_ARRAY_QUEUE_EMPTY);

	return m_auxArray.front().getData().size()/3;
}

long NrpDevice::getAuxFloatArrayResult(float * pResult, float * pAux1, float * pAux2, long arraySize, long *pReadCount)
{
	if (m_auxArray.empty())
		throw NrpException(NRP_ERROR_FLOAT_ARRAY_QUEUE_EMPTY);

	const Real &		v = m_auxArray.front().getData();

	if (arraySize > long(v.size()/3))
		arraySize = long(v.size()/3);

	long	i;

	for (i = 0;i < arraySize;i++) {
		if (pResult)
			*pResult++ = v[i*3];

		if (pAux1)
			*pAux1++ = v[i*3+1];
		if (pAux2)
			*pAux2++ = v[i*3+2];
	}

	if (pReadCount)
		*pReadCount = i;

	arraySize = v.size()/3;

	m_auxArray.pop();

	return arraySize;
}

long NrpDevice::getFloatResult(float *pValue1, float *pValue2, float *pValue3)
{
	if (m_float.empty())
		throw NrpException(NRP_ERROR_FLOAT_QUEUE_EMPTY);

	const Floats &	f = m_float.front().getData();

	if (pValue1)
		*pValue1 = f.m_val1;
	if (pValue2)
		*pValue2 = f.m_val2;
	if (pValue3)
		*pValue3 = f.m_val3;

	m_float.pop();

	return NRP_SUCCESS;
}

long NrpDevice::getLongResult(long *pValue1, long *pValue2, long *pValue3)
{
	if (m_long.empty())
		throw NrpException(NRP_ERROR_LONG_QUEUE_EMPTY);

	const ULongs &	u = m_long.front().getData();

	if (pValue1)
		*pValue1 = u.m_val1;
	if (pValue2)
		*pValue2 = u.m_val2;
	if (pValue3)
		*pValue3 = u.m_val3;

	m_long.pop();

	return NRP_SUCCESS;
}

long NrpDevice::getBitfieldResult(long *pValue1, long *pValue2, long *pValue3)
{
	if (m_bitfield.empty())
		throw NrpException(NRP_ERROR_BITFIELD_QUEUE_EMPTY);

	const ULongs &	u = m_bitfield.front().getData();

	if (pValue1)
		*pValue1 = u.m_val1;
	if (pValue2)
		*pValue2 = u.m_val2;
	if (pValue3)
		*pValue3 = u.m_val3;

	m_bitfield.pop();

	return NRP_SUCCESS;
}

long NrpDevice::getStringResultSize()
{
	if (m_string.empty())
		throw NrpException(NRP_ERROR_STRING_QUEUE_EMPTY);

	return m_string.front().getData().size();
}

long NrpDevice::getStringResult(char *pBuffer, long size)
{
	if (m_string.empty())
		throw NrpException(NRP_ERROR_STRING_QUEUE_EMPTY);

	const String &	s = m_string.front().getData();

	if (size > long(s.size()))
		size = s.size();

	if (pBuffer) {
		s.copy(pBuffer, size);

		size = s.size();
	}

	m_string.pop();

	return size;
}

long NrpDevice::getBinaryResultSize()
{
	if (m_binary.empty())
		throw NrpException(NRP_ERROR_BINARY_QUEUE_EMPTY);

	return m_binary.front().getData().size();
}

long NrpDevice::getBinaryResult(unsigned char *pBuffer, long size)
{
	if (m_binary.empty())
		throw NrpException(NRP_ERROR_BINARY_QUEUE_EMPTY);

	const Binary &	b = m_binary.front().getData();

	if (size > long(b.size()))
		size = long(b.size());

	if (pBuffer) {
		std::copy(b.begin(), b.end(), pBuffer);

		size = b.size();
	}

	m_binary.pop();

	return size;
}

long NrpDevice::queueSize()
{
	return m_sequence.size();
}

void NrpDevice::clearErrorQueue()
{
	while(!m_errorQueue.empty())
		m_errorQueue.pop();
}

void NrpDevice::clearAllQueues()
{
	m_array.clear();
	m_auxArray.clear();
	m_float.clear();
	m_long.clear();
	m_bitfield.clear();
	m_string.clear();
	m_binary.clear();

	clearErrorQueue();
}

ErrorInfo NrpDevice::getError()
{
	if (m_errorQueue.empty())
		return ErrorInfo(NRP_SUCCESS);

	ErrorInfo error = m_errorQueue.front();

	m_errorQueue.pop();

	return error;
}

int NrpDevice::getTriggerState()
{
	return m_triggerState;
}

long NrpDevice::open()
{
	if (getUsbDevice().isOpen() == true)
		return NRP_ERROR_INVALID_RESOURCE;

	int ret = getUsbDevice().open();
	switch (ret)
	{
		case 0:
			return NRP_SUCCESS;
		case -EBUSY:
			return NRP_ERROR_SENSOR_IN_USE;
		case -ENODEV:
			return NRP_ERROR_DEVICE_DISCONNECTED;
		default:
			return NRP_ERROR_DEVICE_DISCONNECTED; // TODO
	}
}

long NrpDevice::close()
{
	if (getUsbDevice().close())
		return NRP_ERROR_INVALID_SESSION;	// check

	m_isAcknowledge.broadcast();

	return NRP_SUCCESS;
}

static unsigned long nrpsend(NrpDevice *dev, const char * pBuf, unsigned long bufLen)
{
	unsigned long	bufCnt;
	int				ret;

	for(bufCnt = 0; bufCnt != bufLen;) {
		ret = dev->getUsbDevice().write(pBuf+bufCnt, bufLen-bufCnt);

		if (ret < 0) {
			if ((errno != ERESTART) && (errno != EAGAIN)) {
				fprintf(stderr, "write error %d\n", errno);

				break;
			}

			ret = dev->getUsbDevice().writeDone(0);

			if (ret < 0) {
				fprintf(stderr, "writeDone failed\n");

				break;
			}
		}
		else {
			bufCnt += ret;
        }
	}
	return bufCnt;
}

long NrpDevice::sendCommand(const char *command, long timeout)
{
#if defined(__ASYNC_WRITE__)
	// Previous write must be done, before new command
	// will be send to the sensor
	if (getUsbDevice().writeDone(0))
		throw NrpException(NRP_ERROR_DEVICE_COMMUNICATION_ERROR);
#endif

	std::string str_command(command);

	// Prepare command
	unsigned long length = str_command.size();

	if ((str_command[length-1] != '\r') &&
		(str_command[length-2] != '\n')) {
		str_command += _T("\n\r");

		length = str_command.size();
	}

	m_isAcknowledge.reset();

	if (nrpsend(this, str_command.c_str(), length) != length)
		throw NrpException(NRP_ERROR_DEVICE_COMMUNICATION_ERROR);

	if (timeout) {
		bool	flag;

		lock();
		flag = m_isAcknowledge.wait(m_mutex, timeout);
		unlock();

		if (flag == false)
			throw NrpException(NRP_ERROR_TIMEOUT);
	}

	return NRP_SUCCESS;
}

long NrpDevice::writeDL(const void *data, long count, long timeout)
{
	int					ret;
	unsigned long		bufCnt;

	if (count < 0)
		throw NrpException(NRP_ERROR_PARAMETER2);

#if defined(__ASYNC_WRITE__)
	// Previous write must be done, before new command
	// will be send to the sensor
	if (getUsbDevice().writeDone(0))
		throw NrpException(NRP_ERROR_DEVICE_COMMUNICATION_ERROR);
#endif

	bufCnt = 0;

	bufCnt = nrpsend(this, (const char *)data, count);
	if (bufCnt != (unsigned long)(count)) {
		fprintf(stderr, "communication error at %lu\n", bufCnt);

		throw NrpException(NRP_ERROR_DEVICE_COMMUNICATION_ERROR);
	}

	ret = getUsbDevice().writeDone(0);

	if (ret < 0) {
		fprintf(stderr, "finishing writeDone failed\n");

		throw NrpException(NRP_ERROR_DEVICE_COMMUNICATION_ERROR);
	}

	return NRP_SUCCESS;
}

long NrpDevice::sendBinaryBlock(const char *command, void *pBuffer, long count, long timeout)
{
	int					ret;
	unsigned long		bufCnt;

	if (count < 0)
		throw NrpException(NRP_ERROR_PARAMETER4);

#if defined(__ASYNC_WRITE__)
	// Previous write must be done, before new command
	// will be send to the sensor
	if (getUsbDevice().writeDone(0))
		throw NrpException(NRP_ERROR_DEVICE_COMMUNICATION_ERROR);
#endif

	std::stringstream sstrCount("");
	sstrCount << count;

	std::string str_count = sstrCount.str();

	std::stringstream sstrCmdLen("");
	sstrCmdLen << command;
	sstrCmdLen << " #";
	sstrCmdLen << str_count.size();
	sstrCmdLen << count;

	std::string str_command = sstrCmdLen.str();

	bufCnt = 0;

	m_isAcknowledge.reset();
  
	if (
		(nrpsend(this, str_command.c_str(), str_command.size()) != str_command.size())||
		((bufCnt = nrpsend(this, (const char *)pBuffer, count)) != (unsigned long)(count))
	) {
		fprintf(stderr, "communication error at %lu\n", bufCnt);

		throw NrpException(NRP_ERROR_DEVICE_COMMUNICATION_ERROR);
	}

	ret = getUsbDevice().writeDone(0);

	if (ret < 0) {
		fprintf(stderr, "finishing writeDone failed\n");

		throw NrpException(NRP_ERROR_DEVICE_COMMUNICATION_ERROR);
	}

	if (timeout) {
		bool          flag;

		lock();
		flag = m_isAcknowledge.wait(m_mutex, timeout);
		unlock();

		if (flag == false)
			throw NrpException(NRP_ERROR_TIMEOUT);
	}

	return NRP_SUCCESS;
}

long NrpDevice::sendVendorInRequest(char *pBuffer, long count, long request, long index, long value)
{
	struct nrpz_control_req	nrpz_request;

	nrpz_request.type = 0xc0; // RequestTypeVendor;
	nrpz_request.request = (unsigned char)request;
	nrpz_request.index = (unsigned short)index;
	nrpz_request.value = (unsigned short)value;
	nrpz_request.data = (unsigned char *)pBuffer;
	nrpz_request.size = count;

	return getUsbDevice().vendor_control_msg_in(&nrpz_request);
}

long NrpDevice::sendVendorOutRequest(long request, long index, long value)
{
	struct nrpz_control_req	nrpz_request;

	nrpz_request.type = 0x40; // RequestTypeVendor;
	nrpz_request.request = (unsigned char)request;
	nrpz_request.index = (unsigned short)index;
	nrpz_request.value = (unsigned short)value;
	nrpz_request.data  = 0;
	nrpz_request.size = 0;

	return getUsbDevice().vendor_control_msg_out(&nrpz_request);
}

void NrpDevice::setAttribute(unsigned long attrName, long attrValue)
{
	switch(attrName) {
	case NRP_ATTR_USER_DATA:
		m_userData = (unsigned long)attrValue;
		break;
	default:
		throw NrpException(NRP_ERROR_UNKNOWN_ATTRIBUTE);
		break;
	} 
}

void NrpDevice::getAttribute(unsigned long attrName, void* pAttrValue)
{
	switch(attrName) {
	case NRP_ATTR_USER_DATA:
	case NRP_ATTR_FORCE_USER_DATA:
		*((unsigned long *)pAttrValue) = m_userData;
		break;
	default:
		throw NrpException(NRP_ERROR_UNKNOWN_ATTRIBUTE);
		break;
	}
}

void NrpDevice::getSensorInfo(char name[], char type[], char serial[])
{
	UsbDescriptorPtr descr = getUsbDescr();

	if (name)
		strcpy(name, descr->getResource());

	if (type)
		strcpy(type, descr->getType());

	if (serial)
		strcpy(serial, descr->getSerial());
}

/* vi:set ts=4 sw=4: */

