/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl.dll
 *
 * $Workfile: exception.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#ifndef	__EXCEPTION_H__
#define	__EXCEPTION_H__

#include <exception>

namespace nrplib
{

/**
 * \class CNrpException
 * \brief This class extends the MFC CException class and serves
 *		 as the bease class for NRP device exceptions.
 *
 * \author		R&S dept. 1GS4
 * \version	1.0
 * \date		26.05.2006
 */

class NrpException : public std::exception
{
public:
	// Constructs a CNrpException
	explicit NrpException(long errorCode) : m_errorCode(errorCode) { }

	// Gets the error code associated with the exception.
	unsigned long	getErrorCode() const { return m_errorCode; }
private:
	long	m_errorCode;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

