/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: usbdevice.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#ifndef	__USBDEVICE_H__
#define	__USBDEVICE_H__

#include <stdio.h>
#include <unistd.h>   // Needed for Fedora FC18

#include "usbdescriptor.h"

#if __GNUC__ == 4 && __GNUC_MINOR__ == 1
#warning "compiling for native (SIGMA_GUI on RH5), not setting O_CLOEXEC"
#define O_CLOEXEC 0
#define pipe2(a,b) pipe(a)
#endif


namespace nrplib
{

class UsbDevice : private noncopyable {
public:
 	/**
	 * Constructor
	 */
	explicit UsbDevice(UsbDescriptorPtr usbdescr) : m_usbdescr(usbdescr), m_file(-1) { }
 	/**
	 * Destructor
	 */
	~UsbDevice()
	{
		if (m_file >= 0)
			::close(m_file);
	}
 	/**
	 * open the sensor device
	 */
	int open()
	{
		if (m_file != -1)
			return false;

		m_file = ::open(m_usbdescr->getDeviceName(), O_RDWR|O_NONBLOCK|O_CLOEXEC);
		
		if (m_file != -1)
			::ioctl(m_file, NRPZ_LEGACYOPEN, 0);

		return (m_file != -1) ? 0 : errno;
	}
 	/**
	 * check if sensor device is openend
	 */
	bool isOpen() const
	{
		return m_file != -1;
	}
 	/**
	 * close the sensor device
	 */
	int close()
	{
		int ret;
		
		if (!isOpen())
			return -1;
			
		::ioctl(m_file, NRPZ_LEGACYCLOSE, 0);
		
		ret = ::close(m_file);
		
		m_file = -1;
		return ret;
	}
 	/**
	 * read datagram from sensor device
	 */
	int read(packet_t & packet) const
	{
		return ::read(m_file, &packet, sizeof(packet));
	}
 	/**
	 * write date to sensor device
	 */
	int write(const char *data, size_t len) const
	{
		return ::write(m_file, data, len);
	}
 	/**
	 * check if all data are written into the sensor device
	 */
	int writeDone(unsigned msec) const
	{
		if (!isOpen())
			return -1;

		return ::ioctl(m_file, NRPZ_WRITE_DONE, msec);
	}
 	/**
	 * write date to sensor device and wait write done with timeout
	 */
	int write(const char *data, size_t len, long timeout) const
	{
		int	ret;

		ret = ::write(m_file, data, len);
		
		if (ret < int(len))
			return ret;

		return ::ioctl(m_file, NRPZ_WRITE_DONE, timeout);
	}
	int vendor_control_msg_out(struct nrpz_control_req * usb_request)
	{
		return ::ioctl(m_file, NRPZ_VENDOR_CONTROL_MSG_OUT, usb_request);
	}
	int vendor_control_msg_in(struct nrpz_control_req * usb_request)
	{
		return ::ioctl(m_file, NRPZ_VENDOR_CONTROL_MSG_IN, usb_request);
	}
	int vendor_control_msg(struct nrpz_control_req * usb_request)
	{
		return vendor_control_msg_out(usb_request);
	}
	/**
	 * get nrp sensor usb descriptor
	 */
	int getDescriptor(struct nrpz_sensor_info * descr)
	{
		return ::ioctl(m_file, NRPZ_GETSENSORINFO, descr);
	}
	/**
	 * get the usb descriptor of the usb device
	 */
	UsbDescriptorPtr 	getUsbDescr() { return m_usbdescr; }
	/**
	 * get the file descriptor of the usb device
	 */
	int					getFile() const { return m_file; }
private:
	UsbDescriptorPtr	m_usbdescr;
	int					m_file;
	bool				m_firmware;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */
