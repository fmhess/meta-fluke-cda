/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: packet.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2007-05-04
 *
 ***************************************************************************/

#ifndef	__PACKET_H__
#define	__PACKET_H__

#include "common.h"

#define	PEEK8(type, addr, off)	(((type)(((u8 *)addr)[off])) << ((off) << 3))

namespace nrplib
{

/**
 * nestet class for packet evaluation
 */
class Packet : private noncopyable
{
public:
	/**
	 * Constructor
	 */
	Packet() { memset(m_packet, 0, sizeof(m_packet)); }
	/**
	 * Destructor
	 */
	~Packet() { }

	const u8 *	getAddr(int off = 0) const	{ return &((m_packet)[off]); }
	/**
	 * byte order independent conversation of char array to u32 integer
	 */
	const u32	getU32(unsigned off) const
	{
	 	const u8 * ptr = getAddr(off);

		return (PEEK8(u32, ptr, 0) | PEEK8(u32, ptr, 1) | PEEK8(u32, ptr, 2) | PEEK8(u32, ptr, 3));
	}
	/**
	 * byte order independent conversation of char array to u16 integer
	 */
	const u16	getU16(unsigned off) const
	{
		const u8 * ptr = getAddr(off);

		return (PEEK8(u16, ptr, 0) | PEEK8(u16, ptr, 1));
	}
	/**
	 * byte u8 integer
	 */
	const u8	getU8(unsigned off) const
	{
		return *getAddr(off);
	}
	/**
	 * byte order independent conversation of char array to float
	 */
	const float	getFloat(unsigned off) const
	{
	 	const u8 * ptr = getAddr(off);

		union {
			u32			u;
			float		f;
		} uf;

		uf.u = (PEEK8(u32, ptr, 0) | PEEK8(u32, ptr, 1) | PEEK8(u32, ptr, 2) | PEEK8(u32, ptr, 3));

		return uf.f;
	}
	const u8 *		getAddr() const			{ return &((m_packet)[0]); }
	const u16 		getIndex() const		{ return getU16(2); }
	const u32		getULong1() const		{ return getU32(4); }
	const u32		getULong2() const		{ return getU32(8); }
	const u32		getULong3() const		{ return getU32(12); }
	const u8		getSignature() const	{ return getU8(0); }
	const u8		getErrCode() const		{ return getU8(1); }
	const u8		getProgress() const		{ return getU8(1); }
	const u8		getState() const		{ return getU8(2); }
	const u8		getGroupNo() const		{ return getU8(2); }
	const u8		getParamNo() const		{ return getU8(3); }
	const float		getFloat1() const		{ return getFloat(4); }
	const float		getFloat2() const		{ return getFloat(8); }
	const float		getFloat3() const		{ return getFloat(12); }

	const Floats	getFloats() const		{ return Floats(getFloat1(), getFloat2(), getFloat3()); }
	const ULongs	getULongs() const		{ return ULongs(getULong1(), getULong2(), getULong3()); }

	operator packet_t &() { return m_packet; }
private:
	packet_t 	m_packet;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

