/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: container.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2007-05-04
 *
 ***************************************************************************/

#ifndef	__CONTAINER_H__
#define	__CONTAINER_H__

#include "common.h"
#include "errorinfo.h"
#include "nrpdef.h"
#include "link.h"
#include "packet.h"
#include "sensorcallback.h"

namespace nrplib
{

/**
 * class for nrp container order
 */
class Sequence {
public:
	 Sequence() : m_count(0), m_link()
	 {
	 }
	~Sequence() { }

	void push(Link &obj)
	{
		obj.add(m_link);

		++m_count;
	}
	void unlink(Link &obj)
	{
		obj.remove();

		--m_count;
	}
	long size() const
	{
		return m_count;
	}
	bool empty() const
	{
		return !m_count;
	}
	Link * first()
	{
		return m_link.next();
	}
private:
	long	m_count;
	Link	m_link;
};

/**
 * class for nrp queue managment
 */
template <typename T>
class NrpQueue {
public:
	explicit NrpQueue(Sequence *sequence) : m_sequence(*sequence)
	{
	}
	~NrpQueue()
	{
		clear();
	}
	void push(SensorCallBack &callback, session_t session, const T & t)
	{
		m_queue.push(t);
		m_queue.back().push(m_sequence);

		callback.call(session, t.getDataType());
	}
	void pop()
	{
		if (m_queue.empty())
			throw NrpException(NRP_ERROR_INCORRECT_DATA_ORDER);

		m_queue.front().unlink(m_sequence);
		m_queue.pop();
	}
	const T & front() const
	{
		return m_queue.front();
	}
	void clear()
	{
		while(!m_queue.empty()) {
			m_queue.front().unlink(m_sequence);
			m_queue.pop();
		}
	}
	bool empty() const
	{
		return m_queue.empty();
	}
private:
	std::queue<T>		m_queue;
	Sequence &			m_sequence;
};

/**
 * class for basic generic nrp container object
 */
class NrpObj : public Link {
public:
	/**
	 * Constructor
	 */
	explicit NrpObj(EDataType dataType, Packet &p) :
		m_dataType(dataType),
		m_signature(p.getSignature()),
		m_groupNo(p.getGroupNo()),
		m_paramNo(p.getParamNo())
	{ }
	~NrpObj() { }

	EDataType	getDataType() const { return m_dataType; };
	u8			getSignature() const { return m_signature; };
	u8			getGroupNo() const { return m_groupNo; };
	u8			getParamNo() const { return m_paramNo; };

	void push(Sequence &sequence) { sequence.push(*this); }
	void unlink(Sequence &sequence) { sequence.unlink(*this); }
private:
	EDataType	m_dataType;
	u8			m_signature;
	u8			m_groupNo;
	u8			m_paramNo;
};

/**
 * container for nrp array data
 */
class NrpArray : public NrpObj
{
public:
	explicit NrpArray(EDataType dataType, Packet &p, Real *realData) : NrpObj(dataType, p), m_real(realData) { }
	const Real & getData() const { return *m_real; }
private:
	RefCntPtr<Real>	m_real;
};

/**
 * container for nrp float data
 */
class NrpFloat : public NrpObj
{
public:
	explicit NrpFloat(EDataType dataType, Packet &p) : NrpObj(dataType, p), m_floats(p.getFloats()) { }
	const Floats & getData() const { return m_floats; }
private:
	Floats 	m_floats;
};

/**
 * container for nrp long data
 */
class NrpLong : public NrpObj
{
public:
	explicit NrpLong(EDataType dataType, Packet &p) : NrpObj(dataType, p), m_longs(p.getULongs()) { }
	const ULongs & getData() const { return m_longs; }
private:
	ULongs 	m_longs;
};

/**
 * container for nrp bitfield data
 */
class NrpBitfield : public NrpObj
{
public:
	explicit NrpBitfield(EDataType dataType, Packet &p) : NrpObj(dataType, p), m_longs(p.getULongs()) { }
	const ULongs & getData() const { return m_longs; }
private:
	ULongs 	m_longs;
};

/**
 * container for nrp auxiliary array data
 */
class NrpAuxArray : public NrpObj
{
public:
	explicit NrpAuxArray(EDataType dataType, Packet &p, Real *realData) : NrpObj(dataType, p), m_real(realData) { }
	const Real & getData() const { return *m_real; }
private:
	RefCntPtr<Real>	m_real;
};

/**
 * container for nrp string data
 */
class NrpString : public NrpObj
{
public:
	explicit NrpString(EDataType dataType, Packet &p, String *stringData) : NrpObj(dataType, p), m_string(stringData) { }
	const String & getData() const { return *m_string; }
private:
	RefCntPtr<String>	m_string;
};

/**
 * container for nrp binary data
 */
class NrpBinary : public NrpObj
{
public:
	explicit NrpBinary(EDataType dataType, Packet &p, Binary *binaryData) : NrpObj(dataType, p), m_binary(binaryData) { }
	const Binary & getData() const { return *m_binary; }
private:
	RefCntPtr<Binary>	m_binary;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

