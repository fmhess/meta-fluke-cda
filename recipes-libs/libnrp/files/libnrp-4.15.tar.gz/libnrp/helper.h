/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl.dll
 *
 * $Workfile: helper.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-29
 *
 ***************************************************************************/

#ifndef	__HELPER_H__
#define	__HELPER_H__

/**
 * Macro to convert a constant number value into a string constant
 */
#define XSTR(x)	#x
#define STR(x)	XSTR(x)

/**
 * macro for calculation the dimension of an array at compile time
 */
#define DIM(x)	(sizeof(x) / sizeof(*x))

/**
 * macro for calculation the the index of an element inside an array
 */
#define IDX(arr, elm)	((elm) - (arr))

/**
 * marco for EINTR save system calls
 */
#define IGN_INTR(call)			\
({								\
	int	__ret;					\
	do {						\
		__ret = (call);			\
		if (__ret != -1)		\
			break;				\
	}  while(errno == EINTR);	\
	__ret;						\
})

/**
 * Macro to calculate the offeset of a member inside a structre
 * TYPE:     type of the structure
 * MEMBER:   the name of the member
 */
#define	OFFSETOF(TYPE, MEMBER) ((size_t) &((TYPE *) 0)->MEMBER)

/**
 * Macro to cast a member of a structure to the containing structure
 * P:        pointer to the member
 * TYPE:     type of the container structure
 * MEMBER:   the name of the member in the structure
 */
#define CONTAINER_OF(P, TYPE, MEMBER)	 (TYPE *)(((char *)P) - OFFSETOF(TYPE, MEMBER))

/**
 * Macro to calculate a byte offset from an given pointer
 */
#define OFFSET_PTR(x, y)	((void *)((char *)x+(y)))

/**
 * Macro to compute the difference in bytes of two pointers
 */
#define DIFF_PTR(x, y)	(((char *)x)-((char *)y))

#ifdef __cplusplus

/**
 * helper for pointer object deletion
 */
struct DeleteObject {
	template<typename T>
	void operator()(const T* ptr) const
	{
		delete ptr;
	}
};

/*
 * copy if algorithm
 */
template <typename InputIterator, typename OutputIterator, typename Predicate>
OutputIterator copy_if(InputIterator begin, InputIterator end, OutputIterator destBegin, Predicate p)
{
	while(begin != end) {
		if (p(*begin))
			*destBegin++ = *begin;
		++begin;
	}
	return destBegin;
}

/**
 * inplace constructor caller
 */
template<typename T1, typename T2>
inline void construct(T1* p, const T2& value)
{
	new(p) T1(value);
}

/**
 * inplace constructor caller
 */
template<typename T1>
inline void construct(T1* p)
{
	new(p) T1();
}

/**
 * inplace destructor caller
 */
template<typename T>
inline void destroy(T* p)
{
	p->~T();
}

/**
 * inplace range destructor caller
 */
template<typename ForwardIterator>
void destroy(ForwardIterator first, ForwardIterator last)
{
	while(first != last) {
		destroy(&*first);
		++first;
	}
}

/**
 * helper class for non copyable class definitions
 */
class noncopyable
{
protected:
	 noncopyable() {}
	~noncopyable() {}
private:  // emphasize the following members are private
	noncopyable( const noncopyable& );
	const noncopyable& operator = ( const noncopyable& );
};

/**
 * c++ version of DIM macro by dr. dobbs
 */
// public interface
#define COUNTOF(x)  (                                               \
  0 * sizeof( reinterpret_cast<const ::Bad_arg_to_COUNTOF*>(x) ) +  \
  0 * sizeof( ::Bad_arg_to_COUNTOF::check_type((x), &(x))      ) +  \
  sizeof(x) / sizeof((x)[0])  )                                     
// implementation details
class Bad_arg_to_COUNTOF
{
public:
   class Is_pointer;  // intentionally incomplete type
   class Is_array {};  
   template<typename T>
   static Is_pointer check_type(const T*, const T* const*);
   static Is_array check_type(const void*, const void*);
};

/**
 * helper class for check derive from a given class
 */
template <class D, class B>
class IsDerivedFrom
{
	class No { };
	class Yes { No no[2]; };

	static Yes Test(B *);
	static No Test(...);
	static void Constraints(D *p) { B* pb = p; pb = p; }
public:
	enum { Is = sizeof(Test(static_cast<D *>(0))) == sizeof(Yes) };

	IsDerivedFrom() { void(*p)(D *) = Constraints; }
};

#endif

#endif

/* vi:set ts=4 sw=4: */

