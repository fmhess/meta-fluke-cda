/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: condition.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2007-05-09
 *
 ***************************************************************************/

#ifndef __CONDITION_H__
#define __CONDITION_H__

// lokale #include sektion

#include <errno.h>
#include <pthread.h>
#include <semaphore.h>

#include "mutex.h"

// Internal condition definition

namespace nrplib
{

class Condition : private noncopyable {
public:
	/**
	 * Constructor class Condition
	 */
	explicit Condition(bool flag = false)
	{
		m_flag = flag;

		if (pthread_cond_init(&m_cond, NULL))
			throw("pthread_cond_init");
	}
	/**
	 * Destructor class Condition
	 */
	~Condition()
	{
		if (pthread_cond_destroy(&m_cond))
			fatal("pthread_cond_destroy");
	}
	/**
	 * set the condition
	 */
	void set()
	{
		if (m_flag != true) {
			m_flag = true;

			pthread_cond_signal(&m_cond);
		}
	}
	/**
	 * wait for a condition
	 */
	bool wait(Mutex &mutex)
	{
		int				ret;
		bool			flag;

		if (m_flag == false) {
			ret = pthread_cond_wait(&m_cond, mutex);

			if (ret)
				fatal("pthread_cond_wait");
		}

		flag = m_flag;

		m_flag = false;

		return flag;
	}
	/**
	 * timed wait for a condition
	 */
	bool wait(Mutex &mutex, unsigned msec)
	{
		int				ret;
		struct timespec	ts;
		ldiv_t			div;
		const long		MSEC = 1000;
		const long		NSEC = 1000000000;
		bool			flag;

		if (clock_gettime(CLOCK_REALTIME, &ts))
			fatal("clock_gettime");

		div = ldiv(msec, MSEC);

		ts.tv_sec += div.quot;
		ts.tv_nsec += div.rem*(NSEC/MSEC);

		if (ts.tv_nsec >= NSEC) {
			ts.tv_sec++;
			ts.tv_nsec -= NSEC;
		}

		for(;;) {
			if (m_flag == true)
				break;

			ret = pthread_cond_timedwait(&m_cond, mutex, &ts);

			if (!ret)
				break;

			if (ret != EINTR) {
				if (ret != ETIMEDOUT)
					fatal("pthread_cond_timedwait");
				break;
			}
		}

		flag = m_flag;

		m_flag = false;

		return flag;
	}
	/**
	 * reset a condition
	 */
	void reset()
	{
		m_flag = false;
	}
	/**
	 * send a broadcast to all waiters
	 */
	void broadcast()
	{
	 	if (pthread_cond_broadcast(&m_cond))
			fatal("pthread_cond_broadcast");
	}
private:
	/**
	 * condition condition
	 */
	pthread_cond_t	m_cond;
	/**
	 * condition flag
	 */
	bool			m_flag;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

