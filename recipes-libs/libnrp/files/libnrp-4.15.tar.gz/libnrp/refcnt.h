/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl.dll
 *
 * $Workfile: refcnt.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2007-07-01
 *
 ***************************************************************************/

#ifndef	__REFCNT_H__
#define	__REFCNT_H__

#include "helper.h"

#include <functional>

#include <stdio.h>

namespace nrplib
{

class RefObj
{
public:
	void addRef() { ++refcnt_; }
	void removeRef() { if (!--refcnt_) delete this; }
	bool isShared() const { return refcnt_>1; }
protected:
	RefObj() : refcnt_(0) { }
	RefObj(const RefObj &other) : refcnt_(0) { }
	RefObj & operator = (const RefObj &other) { return *this; }
	virtual ~RefObj() = 0;
private:
	unsigned	refcnt_;
};

class RefObjShare : public RefObj
{
public:
	bool isShareable() const { return shareable_; }
	void markUnshareable() { shareable_ = false; }
protected:
	RefObjShare() : RefObj(), shareable_(true) { }
	RefObjShare(const RefObj &other) : RefObj(other), shareable_(true) { }
private:
	bool		shareable_;
};

template <class T>
class RefCntPtr
{
	template <typename C, int>
	struct RefInit : private noncopyable
	{
		static void init(T *&ptr)
		{
			if (ptr == 0)
				return;

			RefObj * refptr = ptr;

			refptr->addRef();
		}
	};

	template <typename C>
	struct RefInit<C, 1> : private noncopyable
	{
		static void init(T *&ptr)
		{
			if (ptr == 0)
				return;

			RefObjShare * refptr = ptr;

			if (refptr->isShareable() == false)
				ptr = new T(*ptr);

			refptr->addRef();
		}
	};

	typedef RefInit<T, IsDerivedFrom<T, RefObjShare>::Is> RefObjInit;
public:
	explicit RefCntPtr(T* realPtr = 0) : ptr_(realPtr)
	{
		RefObjInit::init(ptr_);
	}
	RefCntPtr(const RefCntPtr &other) : ptr_(other.ptr_)
	{
		RefObjInit::init(ptr_);
	}
	~RefCntPtr()
	{
		removeRef(ptr_);
	}
	RefCntPtr & operator = (T *ptr)
	{
		if (ptr_ != ptr) {
			T *old = ptr_;

			ptr_ = ptr;

			RefObjInit::init(ptr_);

			removeRef(old);
		}
		return *this;
	}
	RefCntPtr & operator = (const RefCntPtr &other)
	{
		return operator = (other.ptr_);
	}
	bool operator!() const
	{
		return !ptr_;
	}
	bool operator != (void *ptr) const
	{
		return ptr_ != ptr;
	}
	bool operator == (void *ptr) const
	{
		return ptr_ == ptr;
	}
	T* operator->() const
	{
		return ptr_;
	}
	T& operator*() const
	{
		return *ptr_;
	}
	T* get() const
	{
		return ptr_;
	}
private:
	void removeRef(T *ptr)
	{
		if (ptr) {
			RefObj * refptr = ptr;

			refptr->removeRef();
		}
	}
	T *	ptr_;
};

template <class T>
bool operator != (void *ptr, RefCntPtr<T> &rhs)
{
	return rhs != ptr;
}

template <class T>
bool operator == (void *ptr, RefCntPtr<T> &rhs)
{
	return rhs == ptr;
}

} // namespace nrplib

namespace std {

template <typename T>
struct less <nrplib::RefCntPtr<T> > :
public binary_function<nrplib::RefCntPtr<T>, nrplib::RefCntPtr<T>, bool>
{
	bool operator()(const nrplib::RefCntPtr<T> &a, const nrplib::RefCntPtr<T> &b) const
	{
		return less<T *>()(a.get(), b.get());
	}
};

} // namespace std

#endif

/* vi:set ts=4 sw=4: */

