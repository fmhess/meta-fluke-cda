#include "refcnt.h"

using namespace nrplib;

RefObj::~RefObj()
{
}

/* vi:set ts=4 sw=4: */

