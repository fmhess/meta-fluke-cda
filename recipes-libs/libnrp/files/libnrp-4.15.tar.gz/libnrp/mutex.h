/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: mutex.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2007-05-09
 *
 ***************************************************************************/

#ifndef __MUTEX_H__
#define __MUTEX_H__

// lokale #include sektion

#include <pthread.h>

#include "common.h"

// Internal mutex definition

namespace nrplib
{

class Mutex : private noncopyable {
public:
	/**
	 * Constructor class Mutex
	 */
	Mutex()
	{
		pthread_mutexattr_t attr;

		if (pthread_mutexattr_init(&attr))
			throw("pthread_mutexattr_init");

		if (pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP))
			throw("pthread_mutexattr_settype");

		if (pthread_mutex_init(&m_mutex, &attr))
			throw("pthread_mutex_init");

		if (pthread_mutexattr_destroy(&attr))
			throw("pthread_mutexattr_destroy");
	}
	/**
	 * Destructor class Mutex
	 */
	~Mutex() { pthread_mutex_destroy(&m_mutex); }
	/**
	 * wait for the mutex
	 */
	void lock() { if (pthread_mutex_lock(&m_mutex)) fatal("Cannot lock mutex"); }
	/**
	 * release the lock of a mutex
	 */
	void unlock() { if (pthread_mutex_unlock(&m_mutex)) fatal("Cannot unlock mutex"); }
	/**
	 * return a pthred_mutex_pointer
	 */
	operator pthread_mutex_t *() { return &m_mutex; }
private:
	/**
	 * mutex mutex
	 */
	pthread_mutex_t m_mutex;
};

class Synchronize {
public:
	explicit Synchronize() : m_mutex(0)
	{
	}
	explicit Synchronize(Mutex &mutex) : m_mutex(&mutex)
	{
		m_mutex->lock();
	}
	~Synchronize()
	{
		if (m_mutex)
			m_mutex->unlock();
	}
	Synchronize & operator = (Mutex &mutex)
	{
		if (m_mutex)
			m_mutex->unlock();

		m_mutex = &mutex;

		if (m_mutex)
			m_mutex->lock();

		return *this;
	}
private:
	Mutex *m_mutex;
};

//
// this is a little hack for an automatic critical section lock/unlock
//
#define	synchronize(sem)	try { throw Synchronize(sem); } catch(Synchronize &)

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

