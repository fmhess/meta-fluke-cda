/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: thread.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2007-05-09
 *
 ***************************************************************************/

#ifndef __THREAD_H__
#define __THREAD_H__

// lokale #include sektion

#include <pthread.h>
#include <errno.h>
#include <signal.h>
#include <sys/prctl.h>

#include "condition.h"

namespace nrplib
{

class Thread : private noncopyable {
	typedef void * (*threadentry)(void *);
public:
	/**
	 * Constructor class Thread
	 */
	explicit Thread(const char *name = 0, int policy = SCHED_OTHER, int priority = 0) : m_running(false), m_cancel(false), m_name(0)
	{
		int	ret;
		struct sched_param	param;

		ret = pthread_attr_init(&m_attr);
		if (ret)
			throw("pthread_attr_init failed");

		ret = pthread_attr_setdetachstate(&m_attr, PTHREAD_CREATE_JOINABLE); // PTHREAD_CREATE_DETACHED);
		if (ret)
			throw("pthread_attr_setdetachstate failed:");

		ret = pthread_attr_setschedpolicy(&m_attr, policy);
		if (ret)
			throw("pthread_attr_setschedpolicy failed");

		param.sched_priority = priority;

		ret = pthread_attr_setschedparam(&m_attr, &param);
		if (ret)
			throw("pthread_attr_setschedparam failed");

		if (name)
			m_name = strdup(name);
	}
	/**
	 * Destructor class Thread
	 */
	~Thread()
	{
		cancel();

		pthread_attr_destroy(&m_attr);

		free(m_name);
	}
	/**
	 * 
	 */
	int start(threadentry start_routine, void *arg = NULL)
	{
		int	ret;

		m_threadentry = start_routine;
		m_arg = arg;

		m_cancel = false;

		ret = pthread_create(&m_thread, &m_attr, thread_wrapper, this);

		if (!ret)
			m_running = true;

		return ret;
	}
	/**
	 * cancel a running thread
	 */
	void cancel()
	{
		if (m_running == true) {
			m_cancel = true;

			pthread_cancel(m_thread);
			pthread_testcancel();
			pthread_join(m_thread, 0);
		}
		m_running = false;
	}
	/**
	 * test for a thread cancel request
	 */
	bool test_cancel()
	{
		return m_cancel;
	}
	/**
	 * return true if thread is running
	 */
	bool isrunning()
	{
		return m_running;
	}
	/**
	 * wait for thread ready condition
	 */
	void wait()
	{
		m_mutex.lock();
		m_ready.wait(m_mutex);
		m_mutex.unlock();
	}
	/**
	 * set thread ready condition
	 */
	void ready()
	{
		m_mutex.lock();
		m_ready.set();
		m_mutex.unlock();
	}
private:
	static void *thread_wrapper(void *instance)
	{
		Thread *obj;
		void *	ret;

		pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
		pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

		obj = (Thread *)instance;

		if (obj->m_name)
			prctl(PR_SET_NAME, obj->m_name, 0l, 0l, 0l);

		ret = obj->m_threadentry(obj->m_arg);

		pthread_exit(ret);

		return ret;
	}
	/**
	 * mutex mutex
	 */
	pthread_t m_thread;
	/**
	 * Thread attributes
	 */
	pthread_attr_t	m_attr;
	/**
	 * Thread argument
	 */
	void	*	m_arg;
	/**
	 * Thread entrypoint
	 */
	threadentry	m_threadentry;
	/**
	 * Thread ready status
	 */
	Condition	m_ready;
	/**
	 * Thread status mutex
	 */
	Mutex		m_mutex;
	/**
	 * Thread running status
	 */
	bool		m_running;
	/**
	 * Thread running status
	 */
	bool		m_cancel;
	/**
	 * Thread name
	 */
	char *		m_name;
};

} // namespace nrplib

class ThreadCancelDisable : private noncopyable {
	typedef void * (*threadentry)(void *);
public:
	/**
	 * Constructor class ThreadCancelDisable
	 */
	explicit ThreadCancelDisable()
	{
		pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &m_cancelstate);
	}
	/**
	 * Destructor class Thread
	 */
	~ThreadCancelDisable()
	{
		pthread_setcancelstate(m_cancelstate, NULL);
	}
private:
	/**
	 * Thread running status
	 */
	int		m_cancelstate;
};

#endif

/* vi:set ts=4 sw=4: */

