/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: sensorcallback.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2007-08-06
 *
 ***************************************************************************/

#ifndef	__SENSORCALLBACK_H__
#define	__SENSORCALLBACK_H__

#include "common.h"

namespace nrplib
{
/**
 * type for sensor event callback functions
 */
typedef void (*sensorcbfunc)(long session, long arg1, long usrarg);

class SensorCallBack : private noncopyable
{
public:
	SensorCallBack() : m_callback(0), m_arg(0) { }

	void		set(sensorcbfunc callback, long arg) { m_callback = callback; m_arg = arg; }
	int			call(long session, long arg) const { if (m_callback) m_callback(SESSION2HANDLE(session), arg, m_arg); return !m_callback; }
private:
	sensorcbfunc	m_callback;
	long			m_arg;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

