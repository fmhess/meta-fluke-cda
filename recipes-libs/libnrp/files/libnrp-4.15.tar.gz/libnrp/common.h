/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: common.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#ifndef	__COMMON_H__
#define	__COMMON_H__

#include <stdlib.h>
#include <string.h>

#include "helper.h"
#include "refcnt.h"

#define	DRIVER_NAME			"nrpz"

#define	SYS_USB_DRIVER_NODE	"/sys/bus/usb/drivers"
#define	PROC_DIR			"/proc"

#ifdef UNICODE
#define TEXT(q) L##q
#else
#define TEXT(q) q
#endif
#ifndef _T
#define _T TEXT
#endif

//
// Makro to call the fatal error handler
//
#define	fatal(fmt, args...)	printmsg(__FILE__, __PRETTY_FUNCTION__, __LINE__ , fmt , ##args ), abort()

#define SESSION2HANDLE(s)	((s)+1)
#define HANDLE2SESSION(s)	((s)-1)

//
// Makro to call the error handler
//
#define	error(fmt, args...)	printmsg(__FILE__, __PRETTY_FUNCTION__, __LINE__ , fmt , ##args )

typedef unsigned char	u8;
typedef unsigned short	u16;
typedef unsigned long	u32;

typedef	u8	packet_t[16];

extern void printmsg(const char *file, const char *func, int line, const char *fmt, ...);

#include <vector>
#include <string>

namespace nrplib
{

/**
 * helper class for 3 float value storage
 */
class Floats {
public:
	Floats(float float1, float float2, float float3) : m_val1(float1), m_val2(float2), m_val3(float3) { }
	float	m_val1;
	float	m_val2;
	float	m_val3;
};

/**
 * helper class for 3 unsigned long value storage
 */
class ULongs {
public:
	ULongs(u32 long1, u32 long2, u32 long3) : m_val1(long1), m_val2(long2), m_val3(long3) { }
	u32		m_val1;
	u32		m_val2;
	u32		m_val3;
};

/**
 * type for float array container
 */
class Real : public std::vector<float>, public RefObj { };

/**
 * type for string data
 */
#ifdef UNICODE
class String : public std::wstring, public RefObj { };
#else
class String : public std::string, public RefObj { };
#endif

/**
 * type for binary data
 */
class Binary : public std::vector<u8>, public RefObj { };

/**
 * data type for usb device handles
 */
typedef unsigned short	session_t;

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

