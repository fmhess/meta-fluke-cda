/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: autoalloc.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2007-06-02
 *
 ***************************************************************************/

#ifndef __AUTOALLOC_H__
#define __AUTOALLOC_H__

// lokale #include sektion

#include <memory>

#include "helper.h"

// Internal auto alloc definition

namespace nrplib
{

template <typename T>
class AutoAlloc : private noncopyable
{
public:
	AutoAlloc() : data(new T)
	{
	}
	T & operator *() const
	{
		return *data.get();
	}
	T * operator ->() const
	{
		return data.get();
	}
	T * yank()
	{
		T * old;

		std::auto_ptr<T> temp(new T);

		old = data.release();

		data = temp;

		return old;
	}
private:
	std::auto_ptr<T>	data;
};

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

