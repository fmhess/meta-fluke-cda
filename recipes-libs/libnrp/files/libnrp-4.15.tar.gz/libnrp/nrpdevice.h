/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: nrpdevice.h $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#ifndef	__NRPDEVICE_H__
#define	__NRPDEVICE_H__

#include <queue>

#include "autoalloc.h"
#include "container.h"
#include "usbdevice.h"
#include "condition.h"
#include "refcnt.h"

namespace nrplib
{

// forward declaration
class NrpDevList;

class NrpDevice : public RefObj, private noncopyable {
	friend class NrpDevList;
public:
 	/**
	 * Constructor
	 */
	explicit NrpDevice(NrpDevList * nrplist, session_t session, UsbDescriptorPtr usbdescr) :
		m_triggerState(NRP_TRIGGER_UNKNOWN),
		m_tCollecting(DATA_NROF),
		m_array(&m_sequence),
		m_float(&m_sequence),
		m_long(&m_sequence),
		m_bitfield(&m_sequence),
		m_auxArray(&m_sequence),
		m_string(&m_sequence),
		m_binary(&m_sequence),
	 	m_usbdevice(usbdescr),
	 	m_nrplist(nrplist),
		m_isAcknowledge(true),
		m_session(session)
	 {
	 }
 	/**
	 * Destructor
	 */
	~NrpDevice()
	{
	}

	long		getFloatArrayResultSize();
	long		getFloatArrayResult(float *pArray, long arraySize, long *pReadCount);

	long		getAuxFloatArrayResult(float * pResult, float * pAux1, float * pAux2, long arraySize, long *pReadCount);
	long		getAuxFloatArrayResultSize();

	long		getFloatResult(float *pValue1, float *pValue2, float *pValue3);
	long		getLongResult(long *pValue1, long *pValue2, long *pValue3);
	long		getBitfieldResult(long *pValue1, long *pValue2, long *pValue3);

	long		getStringResultSize();
	long		getStringResult(char *pBuffer, long size);

	long		getBinaryResultSize();
	long		getBinaryResult(unsigned char *pBuffer, long size);

	int			getTriggerState();
	ErrorInfo	getError();

	void		clearErrorQueue();
	void		clearAllQueues();
	long		queueSize();
	long		peek(long *pBlockType, long *pGroupNr, long *pParamNr);

	long		open();
	long		close();

	long		sendVendorInRequest(char *pBuffer, long count, long request, long index, long value);
	long		sendVendorOutRequest(long request, long index, long value);

	long		sendCommand(const char *command, long timeout);
	long		writeDL(const void *data, long count, long timeout);
	long		sendBinaryBlock(const char *command, void *pBuffer, long count, long timeout);

	void		setAttribute(unsigned long attrName, long attrValue);
	void		getAttribute(unsigned long attrName, void* pAttrValue);

	void		getSensorInfo(char name[], char type[], char serial[]);
	/**
	 * internal dispatcher
	 */
	void	dispatch();
	/**
	 * return the usb device
	 */
	UsbDevice & getUsbDevice() { return m_usbdevice; }
	/**
	 * return the usb desciptor
	 */
	UsbDescriptorPtr getUsbDescr() { return m_usbdevice.getUsbDescr(); }
	/**
	 * get the session id for of the usb device
	 */
	unsigned	getSession() const { return m_session; }
	/**
	 * lock access to nrp device object
	 */
	void lock() { m_mutex.lock(); }
	/**
	 * unlock access to nrp device object
	 */
	void unlock() { m_mutex.unlock(); }
	/**
	 * return the mutex for the object
	 */
	Mutex &	mutex() { return m_mutex; }
private:
	/**
	 * update the trigger state
	 */
	bool	updateTriggerState(u8 newTriggerState);
	/**
	 * internal handler for 
	 */
	void	nrptype_array(Packet &p);
	void	nrptype_array_aux_peak(Packet &p);
	void	nrptype_single_value(Packet &p);
	void	nrptype_binary_data(Packet &p);
	void	nrptype_feature(Packet &p);
	void	nrptype_param_float(Packet &p);
	void	nrptype_param_integer(Packet &p);
	void	nrptype_param_bitfield(Packet &p);
	void	nrptype_receipt(Packet &p);
	void	nrptype_string_data(Packet &p);
	void	nrptype_limit_float(Packet &p);
	void	nrptype_limit_bitfield(Packet &p);
	void	nrptype_limit_integer(Packet &p);
	void	nrptype_state(Packet &p);
	void	nrptype_alive(Packet &p);
	void	nrptype_internal_error();
	void	nrptype_interim_value();
	void	nrptype_array_interim();
	void	nrptype_array_interim_aux_peak();

	void	nrp_error(long errCode);

	/**
	 * current trigger state
	 */
	int					m_triggerState;
	/**
	 * current multi message data type
	 */
	EDataType			m_tCollecting;
	/**
	 * order queue
	 */
	Sequence			m_sequence;
	/**
	 * data queues
	 */
	NrpQueue<NrpArray>		m_array;
	NrpQueue<NrpFloat>		m_float;
	NrpQueue<NrpLong>		m_long;
	NrpQueue<NrpBitfield>	m_bitfield;
	NrpQueue<NrpAuxArray>	m_auxArray;
	NrpQueue<NrpString>		m_string;
	NrpQueue<NrpBinary>		m_binary;
	/**
	 * error queue
	 */
	std::queue<ErrorInfo>	m_errorQueue;
	/**
	 * container for float data collection 
	 */
	AutoAlloc<Real>		m_realData;
	/**
	 * container for string data collection 
	 */
	AutoAlloc<String>	m_stringData;
	/**
	 * container for binary data collection 
	 */
	AutoAlloc<Binary>	m_binaryData;
	/**
	 * usb device
	 */
	UsbDevice 			m_usbdevice;
	/**
	 * backward pointer to the nrp device list
	 */
	NrpDevList *		m_nrplist;
	/**
	 * mutex for sychronized access
	 */
	Mutex				m_mutex;
	/**
	 * condition for send command acknowledged
	 */
	Condition			m_isAcknowledge;
	/**
	 * user data attribute
	 */
	unsigned long		m_userData;
	/**
	 * session id attribute
	 */
	session_t			m_session;
};

typedef RefCntPtr<NrpDevice>	NrpDevicePtr; 

} // namespace nrplib

#endif

/* vi:set ts=4 sw=4: */

