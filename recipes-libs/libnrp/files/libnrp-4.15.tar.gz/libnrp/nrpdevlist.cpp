/***************************************************************************
 *
 * Company: Rohde & Schwarz
 *
 * Project: NrpControl2.dll port for linux
 *
 * $Workfile: nrpdevlist.cpp $
 *
 * Author: R&S dept. 1GS4
 *
 * Date of creation: 2006-05-26
 *
 ***************************************************************************/

#include <algorithm>
#include <functional>

#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/user.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <linux/types.h>
#include <linux/limits.h>
#include <sys/user.h>
#include <sys/mman.h>
#ifdef __cplusplus
extern "C" {
#endif
#include <libudev.h>
#ifdef __cplusplus
}
#endif


#include "nrplib.h"
#include "nrpdevlist.h"

#define	NRPZ5	0x0aad0087

using namespace nrplib;

typedef std::vector <NrpDevicePtr>::iterator	iterator;

static const char	c_event = 'e';

//
// set handle in select event mask
//
static inline int fdSet(fd_set &fds, int handle, int fdmax)
{
    if (handle != -1) {
        if (fdmax < handle)
            fdmax = handle;

        FD_SET(handle, &fds);
    }
    return fdmax;
}

//
// test if handle is set in select event mask
//
static inline int fdIsSet(fd_set &fds, int handle)
{
    return (handle != -1) ? FD_ISSET(handle, &fds) : 0;
}


static bool isNrpZ5PseudoResource(const char *resourceDescriptor, char *cpSensorResource)
{
    char         szPseudoRsc[256];
    char        *cpColon;
    unsigned int uiVendorID;
    unsigned int uiProductID;
    long         lConnected = 0;
    int          iPortIdx   = -1;

    if (!resourceDescriptor || !cpSensorResource)
        return false;

    // if we do not have an NRP-Z5, we don't need
    // to check for NRP-Z5 pseudo-resources anyway...
    if (NrpGetDeviceStatusZ5() != NRP_SUCCESS)
        return false;


    memset(szPseudoRsc, 0x00, sizeof(szPseudoRsc));

    strncpy(szPseudoRsc, resourceDescriptor, sizeof(szPseudoRsc)-1);

    for(size_t n = 0; n < strlen(szPseudoRsc); n++)		// make uppercase
        szPseudoRsc[n] = toupper(szPseudoRsc[n]);

    if (strncmp(szPseudoRsc, "USB::", 5))
        return false;

    strcpy(szPseudoRsc, szPseudoRsc + 5);			// removing 'USB::'

    if (sscanf(szPseudoRsc, "%x", &uiVendorID) != 1)
        return false;

    if (uiVendorID != 0x0aad)
        return false;

    cpColon = strstr(szPseudoRsc, "::");
    if (!cpColon)
        return false;

    strcpy(szPseudoRsc, cpColon + 2);			// removing '0x0aad::'

    if (sscanf(szPseudoRsc, "%x", &uiProductID) != 1)
        return false;

    if (uiProductID != 0x0087)
        return false;

    cpColon = strstr(szPseudoRsc, "::");
    if (!cpColon)
        return false;

    strcpy(szPseudoRsc, cpColon + 2);			// removing '0x0087::'

    // Now the only contents shall be the S/N
    if (strlen(szPseudoRsc) != 1)
        return false;

    // S/N *is* exactly 1 character
    if (('1' <= szPseudoRsc[0]) && (szPseudoRsc[0] <= '4'))
        iPortIdx = szPseudoRsc[0] - '1';

    if (('A' <= szPseudoRsc[0]) && (szPseudoRsc[0] <= 'D'))
        iPortIdx = szPseudoRsc[0] - 'A';

    if (iPortIdx < 0)
        return false;

    NrpGetDeviceInfoZ5(iPortIdx, cpSensorResource, 0, 0, &lConnected);
    if (!lConnected)
        return false;

    return true;
}


//
// wait for an event
//
void NrpDevList::handleUsbEvent()
{
    int				ret;
    fd_set			fds;
    int				fdmax = 0;
    struct timeval  timeout;

    FD_ZERO(&fds);
    {
        Synchronize nrplist_sync(m_mutex);

        for(NrpDevListIter p = m_devList.begin(); p != m_devList.end(); ++p)
            fdmax = fdSet(fds, (*p)->getUsbDevice().getFile(), fdmax);
    }

    fdmax = fdSet(fds, m_pipe[0], fdmax);
    fdmax = fdSet(fds, m_udevfd, fdmax);

    // as long as we're waiting for a device to get ready, wake up every second
    if (!m_waitDevices.empty()) {
        timeout.tv_sec  = 1;
        timeout.tv_usec = 0;
        ret = select(fdmax + 1, &fds, NULL, NULL, &timeout);
    }
    else {
        ret = select(fdmax + 1, &fds, NULL, NULL, NULL);
    }

    {
        // disable cancelation to avoid memory leaks and blocked resources
        ThreadCancelDisable	tcd;

        Synchronize nrplist_sync(m_mutex);

        m_cond.set();

        if (ret < 0)
            return;

        if (!m_waitDevices.empty()) {
            std::vector<struct udev_device *> waitList = m_waitDevices;
            m_waitDevices.clear();
            for(WaitDeviceListIter p = waitList.begin(); p != waitList.end(); ++p) {
                addDevice(*p);
                udev_device_unref(*p);
            }
        }

        // if wakeUpSelect was invoked
        if (FD_ISSET(m_pipe[0], &fds)) {
            char	c;

            if (read(m_pipe[0], &c, 1) == -1)
                return;
        }

        // does a udevd event has occured
        if (FD_ISSET(m_udevfd, &fds)) {
            struct udev_device *dev;

            dev = udev_monitor_receive_device(m_udevmon);
            if (dev) {
                const char *action = udev_device_get_action(dev);

                if (action) {
                    if (!strcmp(action, "add")) {
                        addDevice(dev);
                    }
                    else
                        if (!strcmp(action, "remove"))
                            delDevice(dev);
                }
                udev_device_unref(dev);
            }
        }

        // get datas from sensors
        for(NrpDevListIter p = m_devList.begin(); p != m_devList.end(); ++p) {
            if (fdIsSet(fds, (*p)->getUsbDevice().getFile())) {
                (*p)->dispatch();
            }
        }
    }
}

int NrpDevList::wakeUpSelect()
{
    // wakeup the event loop
    if (write(m_pipe[1], &c_event, 1) == -1)
        return -1;

    return 0;
}

/*
 * helper class for using find_if a given usbdescr in a list
 */
class CmpDescr : std::unary_function < NrpDevicePtr, bool>
{
    public:
        CmpDescr(struct udev_device *dev)
        {
            m_devpath = udev_device_get_devpath(dev);
        }

        bool operator()(NrpDevicePtr nrpdev) const
        {
            return !strcmp(m_devpath, nrpdev->getUsbDescr()->getDevPath());
        }
    private:
        const char *	m_devpath;
};

/*
 * add pluged NRP Devices
 */
void NrpDevList::addDevice(struct udev_device *dev)
{
    UsbDescriptorPtr	usbdescr;
    session_t		session;

    usbdescr = new UsbDescriptor(dev);

    if(!usbdescr->isNrpz())
        return;

    // check if the device is already handled
    if (find_if(m_devList.begin(), m_devList.end(), CmpDescr(dev)) != m_devList.end())
        return;

    if (!m_disableFirmwareLoad) {
        if (usbdescr->isFirmwareLoaded() == false)
            return;
    }

    // trigger deferred device addition
    if (usbdescr->isDeviceReady() == false) {
        m_waitDevices.push_back(udev_device_ref(dev));
        return;
    }

    // lookup for the next available session number
    if (m_idFreeSet.empty())
        session = m_sessionCnt++;
    else {
        SessionIdIter first;

        first = m_idFreeSet.begin();
        session = *first;
        m_idFreeSet.erase(first);
    }

    if (session >= m_devices.size())
        m_devices.resize(session + 1);

    // allocater a new nrp devices and link it in
    m_devList.push_back(m_devices[session] = new NrpDevice(this, session, usbdescr));

    if (m_disableFirmwareLoad)
        m_disableFirmwareLoad(usbdescr->getResource());

    if (usbdescr->getHub() > m_maxRootHub)
        m_maxRootHub = usbdescr->getHub();

    if (usbdescr->getPort() > m_maxPort)
        m_maxPort = usbdescr->getPort();

    if (usbdescr->getHubType() == NRPZ5)
        ++m_nrpz5;

    // send a notification for device change
    m_deviceChangedCallback.call();
}

/*
 * add pluged NRP Devices
 */
void NrpDevList::delDevice(struct udev_device *dev)
{
    NrpDevListIter p;

    WaitDeviceListIter wp = m_waitDevices.begin();
    while(wp != m_waitDevices.end()) {
        if(!strcmp(udev_device_get_devpath(*wp), udev_device_get_devpath(dev))) {
            udev_device_unref(*wp);
            wp = m_waitDevices.erase(wp);
            continue;
        }
        ++wp;
    }

    p = find_if(m_devList.begin(), m_devList.end(), CmpDescr(dev));
    if (p == m_devList.end())
        return;

    NrpDevicePtr    nrpdev(*p);

    if (nrpdev->getUsbDescr()->getHubType() == NRPZ5)
        --m_nrpz5;

    nrpdev->lock();

    session_t       session = nrpdev->getSession();

    // mark devices as free
    m_devices[session] = 0;

    // release session number only if device is not in use
    if (nrpdev->getUsbDevice().isOpen() == false)
        m_idFreeSet.insert(session);
    else
        nrpdev->close();

    nrpdev->unlock();

    m_devList.erase(p);

    m_deviceChangedCallback.call();
}

/*
 * helper for calling thread main loop
 */
void * NrpDevList::dispatchHelper(void *ptr)
{
    ((NrpDevList *)ptr)->dispatch();

    return 0;
}

/*
 * thread main loop
 */
void NrpDevList::dispatch()
{
    m_thread.ready();

    while(m_thread.test_cancel() == false)
        handleUsbEvent();
}

long NrpDevList::getData(long session, long *pBlockType, long *pGroupNr, long *pParamNr)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        status = pnrp_device->peek(pBlockType, pGroupNr, pParamNr);
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getFloatArrayLength(long session, long * pSize)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        if (pSize)
            *pSize = pnrp_device->getFloatArrayResultSize();
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();

        if (pSize)
            *pSize = 0;
    }

    return status;
}

long NrpDevList::getFloatArray(long session, float *pArray, long arraySize, long *pReadCount)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        if (!arraySize || !pArray)
            return pnrp_device->getFloatArrayResultSize();

        if (pnrp_device->getFloatArrayResult(pArray, arraySize, pReadCount) > arraySize)
            status = NRP_ERROR_SMALL_BUFFER_SIZE;
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getFloatResult(long session, float *pFloatVal1, float *pFloatVal2, float *pFloatVal3)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        status = pnrp_device->getFloatResult(pFloatVal1, pFloatVal2, pFloatVal3);
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getLongResult(long session, long *pLongVal1, long *pLongVal2, long *pLongVal3)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        status = pnrp_device->getLongResult(pLongVal1, pLongVal2, pLongVal3);
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getBitfieldResult(long session, long *pBitVal1, long *pBitVal2, long *pBitVal3)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        status = pnrp_device->getBitfieldResult(pBitVal1, pBitVal2, pBitVal3);
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getStringResultLength(long session, long * pSize)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        if (pSize)
            *pSize = pnrp_device->getStringResultSize();
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();

        if (pSize)
            *pSize = 0;
    }

    return status;
}

long NrpDevList::getStringResult(long session, char *pBuffer, long size)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        if (!size || !pBuffer)
            return pnrp_device->getStringResultSize();

        if (pnrp_device->getStringResult(pBuffer, size) > size)
            status = NRP_ERROR_SMALL_BUFFER_SIZE;
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getBinaryResultLength(long session, long * pSize)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        if (pSize)
            *pSize = pnrp_device->getBinaryResultSize();
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();

        if (pSize)
            *pSize = 0;
    }

    return status;
}

long NrpDevList::getBinaryResult(long session, unsigned char *pBuffer, long buflen, long *size)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        if (!size || !pBuffer)
            return pnrp_device->getBinaryResultSize();

        *size = pnrp_device->getBinaryResult(pBuffer, buflen);

        if (*size > buflen)
            status = NRP_ERROR_SMALL_BUFFER_SIZE;
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getAuxFloatArrayLength(long session, long * pSize)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        if (pSize)
            *pSize = pnrp_device->getAuxFloatArrayResultSize();
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();

        if (pSize)
            *pSize = 0;
    }

    return status;
}

long NrpDevList::getAuxFloatArray(long session, float * pResult, float * pAux1, float * pAux2, long arrayLength, long * pReadCount)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        if (!arrayLength)
            return pnrp_device->getAuxFloatArrayResultSize();

        if (pnrp_device->getAuxFloatArrayResult(pResult, pAux1, pAux2, arrayLength, pReadCount) > arrayLength)
            status = NRP_ERROR_SMALL_BUFFER_SIZE;
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::emptyAllBuffers(long session)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        pnrp_device->clearAllQueues();
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getTriggerState(long session, long *state)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        if (state)
            *state = pnrp_device->getTriggerState();
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getError(long session, long *pError)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        *pError = pnrp_device->getError().getCode();
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::emptyErrorQueue(long session)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        pnrp_device->clearErrorQueue();
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::sendCommand(long session, const char *command, long timeout)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        {
            Synchronize	nrpdev_sync;

            pnrp_device = getNrpDevice(nrpdev_sync, session);
        }
        status = pnrp_device->sendCommand(command, timeout);
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}


long NrpDevList::writeDL(long session, const void *data, long count, long timeout)
{
    long		status;
    NrpDevicePtr pnrp_device;

    status = NRP_SUCCESS;

    try {
        {
            Synchronize nrpdev_sync;

            pnrp_device = getNrpDevice(nrpdev_sync, session);
        }
        status = pnrp_device->writeDL(data, count, timeout);
    }
    catch(NrpException & pexception)
    {
        status = pexception.getErrorCode();
    }

    return status;
}


long NrpDevList::sendBinaryBlock(long session, const char *command, void *pBuffer, long count, long timeout)
{
    long		status;
    NrpDevicePtr pnrp_device;

    status = NRP_SUCCESS;

    try {
        {
            Synchronize nrpdev_sync;

            pnrp_device = getNrpDevice(nrpdev_sync, session);
        }
        status = pnrp_device->sendBinaryBlock(command, pBuffer, count, timeout);
    }
    catch(NrpException & pexception)
    {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::sendVendorInRequest(long session, char *pBuffer, long count, long request, long index)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        {
            Synchronize	nrpdev_sync;

            pnrp_device = getNrpDevice(nrpdev_sync, session);
        }
        status = pnrp_device->sendVendorInRequest(pBuffer, count, request, index, 0);
    }
    catch(NrpException & pexception)
    {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::sendVendorOutRequest(long session, long request, long index, long value)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        {
            Synchronize nrpdev_sync;

            pnrp_device = getNrpDevice(nrpdev_sync, session);
        }
        status = pnrp_device->sendVendorOutRequest(request, index, value);
    }
    catch(NrpException & pexception)
    {
        status = pexception.getErrorCode();
    }

    return status;
}



long NrpDevList::dataAvailable(long session, long *pDataCount)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        if (pDataCount)
            *pDataCount = pnrp_device->queueSize();
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::openSensor(const char *resourceDescriptor, long *pHandle)
{
    long		status;
    session_t	session;

    if (!pHandle)
        return NRP_ERROR_INVALID_RESOURCE;

    status = NRP_SUCCESS;

    try {
        Synchronize sem(m_mutex);

        char szSensorResource[256];

        if (!isNrpZ5PseudoResource(resourceDescriptor, szSensorResource))
            strcpy(szSensorResource, resourceDescriptor);

        if (findResource(szSensorResource, session) == false)
            return NRP_ERROR_INVALID_RESOURCE;		// check

        Synchronize nrpdev_sync(m_devices[session]->m_mutex);

        status = m_devices[session]->open();

        if (status != NRP_SUCCESS) {
            *pHandle = 0;
            return status;
        }

        wakeUpSelect();

        *pHandle = SESSION2HANDLE(session);

        struct timespec ts;
        if (! clock_gettime(CLOCK_REALTIME, &ts)) {
            ts.tv_sec += 1;
            if (! sem_timedwait(&m_shmData->sem, &ts)) {
                for (size_t i = 0; i < (sizeof(m_shmData->sensors) / sizeof(m_shmData->sensors[0])); ++i) {
                    if (! m_shmData->sensors[i].in_use) {
                        UsbDescriptorPtr usbDescr = m_devices[session]->getUsbDescr();
                        NrpOpenSensorInfo& sensorInfo = m_shmData->sensors[i];

                        sensorInfo.vendor = usbDescr->getVendor();
                        sensorInfo.product = usbDescr->getProduct();
                        strncpy(sensorInfo.serial, usbDescr->getSerial(), sizeof(sensorInfo.serial)); 
                        sensorInfo.in_use = true;
                        sensorInfo.pid = getpid();
                        break;
                    }
                }
                sem_post(&m_shmData->sem);
            } else {
                // semaphore could not be locked
                // do nothing here
            }
        }
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::closeSensor(long session)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	sem(m_mutex);
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        status = pnrp_device->close();

        struct timespec ts;
        if (! clock_gettime(CLOCK_REALTIME, &ts)) {
            ts.tv_sec += 1;
            if (! sem_timedwait(&m_shmData->sem, &ts)) {
                UsbDescriptorPtr usbDescr = pnrp_device->getUsbDescr();

                for (size_t i = 0; i < (sizeof(m_shmData->sensors) / sizeof(m_shmData->sensors[0])); ++i) {
                    NrpOpenSensorInfo& sensorInfo = m_shmData->sensors[i];
                    if (sensorInfo.vendor == (unsigned long)usbDescr->getVendor() &&
                            sensorInfo.product == (unsigned long)usbDescr->getProduct() &&
                            m_shmData->sensors[i].in_use)
                    {
                        sensorInfo.in_use = false;
                        break;
                    }
                }
                sem_post(&m_shmData->sem);
            } else {
                // semaphore could not be locked
                // do nothing here
            }
        }

        m_cond.reset();
        wakeUpSelect();
        m_cond.wait(m_mutex);

        if (status != NRP_SUCCESS)
            return status;
    }
    catch(NrpException & pexception) {
        if (pexception.getErrorCode() == NRP_ERROR_USB_DISCONNECTED) {
            m_idFreeSet.insert(HANDLE2SESSION(session));
        }
        else
            status = pexception.getErrorCode();
    }


    return status;
}

long NrpDevList::clearDevice(long session)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        status = pnrp_device->sendVendorOutRequest(VRT_SET_DEVICE_CLEAR, 1, 1);
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

/*
 * Registers the callback for device changed event.
 */
long NrpDevList::setNotifyCallbackDeviceChanged(Nrp_DeviceChangedFuncPtr callbackPtr, long usrArgument)
{
    deviceChangedCallback().set(callbackPtr, usrArgument);

    return NRP_SUCCESS;
}

/*
 * Registers the callback for still alive event.
 */
long NrpDevList::setNotifyCallbackStillAlive(Nrp_StillAliveFuncPtr callbackPtr, long usrArgument)
{
    stillAliveCallback().set(callbackPtr, usrArgument);

    return NRP_SUCCESS;
}

long NrpDevList::setNotifyCallbackDataAvailable(Nrp_DataAvailableFuncPtr callbackPtr, long usrArgument)
{
    dataAvailableCallback().set(callbackPtr, usrArgument);

    return NRP_SUCCESS;
}

/** Registers the callback for command accepted event. */
long NrpDevList::setNotifyCallbackCommandAccepted(Nrp_CommandAcceptedFuncPtr callbackPtr, long usrArgument)
{
    commandAcceptedCallback().set(callbackPtr, usrArgument);

    return NRP_SUCCESS;
}

/** Registers the callback for error occured event. */
long NrpDevList::setNotifyCallbackErrorOccurred(Nrp_ErrorOccurredFuncPtr callbackPtr, long usrArgument)
{
    errorOccurredCallback().set(callbackPtr, usrArgument);

    return NRP_SUCCESS;
}

/** Registers the callback for state changed event. */
long NrpDevList::setNotifyCallbackStateChanged(Nrp_StateChangedFuncPtr callbackPtr, long usrArgument)
{
    stateChangedCallback().set(callbackPtr, usrArgument);

    return NRP_SUCCESS;
}

/** Sets a specified attribute for given object. */
long NrpDevList::setAttribute(long session, unsigned long attrName, long attrValue)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        pnrp_device->setAttribute(attrName, attrValue);
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

/** Queries the specified attribute for a given object. */
long NrpDevList::getAttribute(long session, unsigned long attrName, void* pAttrValue)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        if (session == 0 && attrName >= NRP_ATTR_DEVPATH_BASE && attrName < (NRP_ATTR_DEVPATH_BASE + 32)) {
            long index = attrName - NRP_ATTR_DEVPATH_BASE;
            if (index >= long(m_devInfo.size()))
                return NRP_ERROR_DESCRIPTOR_INDEX;

            char * dest = (char*)pAttrValue;
            const char * devpath = m_devInfo[index]->getDevPath();

            memset(dest, 0x00, PATH_MAX);
            strncpy(dest, devpath, PATH_MAX - 1);
        } else {
            pnrp_device = getNrpDevice(nrpdev_sync, session);
            pnrp_device->getAttribute(attrName, pAttrValue);
        }
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getDescriptor(long session, struct nrpz_sensor_info * descr)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        status = pnrp_device->getUsbDevice().getDescriptor(descr);
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getSensorInfo(long session, char *name, char *type, char *serial)
{
    long			status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;

        pnrp_device = getNrpDevice(nrpdev_sync, session);

        pnrp_device->getSensorInfo(name, type, serial);
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getDeviceListLength(long *pLength)
{
    Synchronize nrplist_sync(m_mutex);

    if (pLength)
        *pLength = m_devInfo.size();

    return NRP_SUCCESS;
}

long NrpDevList::lockDeviceList()
{
    Synchronize nrplist_sync(m_mutex);

    m_devInfo.clear();
    m_devInfo.reserve(m_devCnt);

    for(NrpDevListIter p = m_devList.begin(); p != m_devList.end(); ++p)
        m_devInfo.push_back((*p)->getUsbDescr());

    return NRP_SUCCESS;
}

long NrpDevList::getDeviceInfo(long index, char *name, char *type, char *serial, long *pIsConnected)
{
    Synchronize nrplist_sync(m_mutex);

    if (index >= long(m_devInfo.size()))
        return NRP_ERROR_DESCRIPTOR_INDEX;

    if (name)
        strcpy(name, m_devInfo[index]->getResource());

    if (type)
        strcpy(type, m_devInfo[index]->getType());

    if (serial)
        strcpy(serial, m_devInfo[index]->getSerial());

    if (pIsConnected)
        *pIsConnected = true;

    return NRP_SUCCESS;
}

long NrpDevList::getDeviceInfoZ5(long index, char *name, char *type, char *serial, long *pIsConnected)
{
    Synchronize nrplist_sync(m_mutex);

    if (index > 3)
        return NRP_ERROR_DESCRIPTOR_INDEX;

    if (index < 0)
        return NRP_ERROR_DESCRIPTOR_INDEX;

    index += 1;

    for(NrpDevListIter p = m_devList.begin(); p != m_devList.end(); ++p) {
        UsbDescriptorPtr descr = (*p)->getUsbDescr();

        if ((descr->getHubType() == NRPZ5) && (descr->getPort() == index)) {
            if (name)
                strcpy(name, descr->getResource());

            if (type)
                strcpy(type, descr->getType());

            if (serial)
                strcpy(serial, descr->getSerial());

            if (pIsConnected)
                *pIsConnected = true;

            return NRP_SUCCESS;
        }
    }
    return NRP_ERROR_DESCRIPTOR_INDEX;
}

long NrpDevList::discardResult(long  lSession)
{
    long		status;
    NrpDevicePtr	pnrp_device;

    status = NRP_SUCCESS;

    try {
        Synchronize	nrpdev_sync;
        long		l1, l2, l3;
        float		f1, f2, f3;
        long		lCount;
        long		lDummy;
        long		lDataType = -1L;
        long		lGroupNo = -1L;
        long		lParamNo = -1L;
        float		*pfArray = 0;
        char		*pcBuf = 0;
        unsigned char	*pBinBuf = 0;


        pnrp_device = getNrpDevice(nrpdev_sync, lSession);

        status = getData(lSession, &lDataType, &lGroupNo, &lParamNo);

        switch(lDataType) {
            case DATA_FLOATARRAY:
                getFloatArrayLength(lSession, &lCount);
                pfArray = new float[ lCount ];
                getFloatArray(lSession, pfArray, lCount, &lDummy);
                delete [] pfArray;
                break;
            case DATA_BINARYBLOCK:
                lCount  = getBinaryResult(lSession, NULL, 0, &lDummy);
                pBinBuf = new unsigned char[ lCount ];
                getBinaryResult(lSession, pBinBuf, lCount, &lDummy);
                delete [] pBinBuf;
                break;
            case DATA_STRING:
                lCount = getStringResult(lSession, NULL, 0);
                pcBuf  = new char[ lCount + 1 ];
                getStringResult(lSession, pcBuf, lCount);
                delete[] pcBuf;
                break;
            case DATA_FLOATPARAM:
                getFloatResult(lSession, &f1, &f2, &f3);
                break;
            case DATA_FLOATRESULT:
                getFloatResult(lSession, &f1, &f2, &f3);
                break;
            case DATA_FLOATLIMIT:
                getFloatResult(lSession, &f1, &f2, &f3);
                break;
            case DATA_LONGPARAM:
                getLongResult(lSession, &l1, &l2, &l3);
                break;
            case DATA_LONGLIMIT:
                getLongResult(lSession, &l1, &l2, &l3);
                break;
            case DATA_BITFIELDPARAM:
                getBitfieldResult(lSession, &l1, &l2, &l3);
                break;
            case DATA_BITFIELDFEATURE:
                getBitfieldResult(lSession, &l1, &l2, &l3);
                break;
            default:
                break;
        }
    }
    catch(NrpException & pexception) {
        status = pexception.getErrorCode();
    }

    return status;
}

long NrpDevList::getResourceName(long index, char *resource, unsigned int maxLen)
{
    Synchronize nrplist_sync(m_mutex);

    if (!maxLen)
        return NRP_ERROR_PARAMETER3;

    if (index >= long(m_devInfo.size()))
        return NRP_ERROR_DESCRIPTOR_INDEX;

    strncpy(resource, m_devInfo[index]->getResource(), maxLen-1);

    resource[maxLen] = 0;

    return NRP_SUCCESS;
}

//
// helper class for using find_if a given usbdescr in a list
//
class CmpHubPort
{
    public:
        CmpHubPort(long hub, long port) : m_hub(hub), m_port(port) { }

        bool operator()(NrpDevicePtr nrpdev) const
        {
            return (m_hub == nrpdev->getUsbDescr()->getHub()) && (m_port == nrpdev->getUsbDescr()->getPort());
        }
    private:
        long	m_hub;
        long	m_port;
};

bool NrpDevList::findResource(const char * Resource, session_t &session)
{
    const char * segments[4] = {NULL, NULL, NULL, NULL};
    segments[0] = Resource;
    segments[1] = segments[0] ? strstr(segments[0], "::") : NULL;
    segments[2] = segments[1] ? strstr(segments[1] + 2, "::") : NULL;
    segments[3] = segments[2] ? strstr(segments[2] + 2, "::") : NULL;

    if(segments[1]) segments[1] += 2;
    if(segments[2]) segments[2] += 2;
    if(segments[3]) segments[3] += 2;

    long  lVendor  = (segments[1] && segments[1][0] != '*') ? strtol(segments[1], NULL, 0) : -1;
    long  lProduct = (segments[2] && segments[2][0] != '*') ? strtol(segments[2], NULL, 0) : -1;
    const char *cpSerial = segments[3];

    for(NrpDevListIter p = m_devList.begin(); p != m_devList.end(); ++p) {
        if(lVendor != -1 && (*p)->getUsbDescr()->getVendor() != lVendor)
            continue;
        if(lProduct != -1 && (*p)->getUsbDescr()->getProduct() != lProduct)
            continue;
        if(cpSerial) {
            const char *cpEnd = strrchr(cpSerial, '*');
            long lCmp   = cpEnd ? (cpEnd - cpSerial) : strlen(cpSerial);
            if(strncasecmp(cpSerial, (*p)->getUsbDescr()->getSerial(), lCmp)) {
                continue;
            }
        }

        session = (*p)->getSession();

#ifdef DEBUG
        fprintf(stderr, ">%s: Resource %s matched to resource %s\n", __FUNCTION__, Resource, (*p)->getUsbDescr()->getResource());
#endif
        return true;
    }

#ifdef DEBUG
    fprintf(stderr, ">%s: Resource %s NOT FOUND\n", __FUNCTION__, Resource);
#endif
    return false;
}

/*
 * returns the resource strings of a given hub and port number
 *
 * format: USB::0x0aad::0x000c::900001
 */
long NrpDevList::getPortResource(long HubIndex, long PortIndex, char* Resource)
{
    Synchronize nrplist_sync(m_mutex);

    NrpDevListIter p = find_if(m_devList.begin(), m_devList.end(), CmpHubPort(HubIndex, PortIndex));

    if (p != m_devList.end())
        strcpy(Resource, (*p)->getUsbDescr()->getResource());
    else
        *Resource = 0;

    return NRP_SUCCESS;
}

/**
 * return the nrp device handled by session number
 */
NrpDevicePtr NrpDevList::getNrpDevice(Synchronize &nrpdev_sync, long handle)
{
    session_t	session;

    // synchronize access to device list
    Synchronize nrplist_sync(m_mutex);

    session = HANDLE2SESSION(handle);

    if (session >= long(m_devices.size())) {
#ifdef DEBUG
        fprintf(stderr, "getNrpDevice [%d]: session exceeds max.\n", session);
#endif
        throw NrpException(NRP_ERROR_INVALID_SESSION);
    }

    NrpDevicePtr nrpdev;

    nrpdev = m_devices[session];

    if (!nrpdev) {

        // currently unused session IDs
        if (m_idFreeSet.find(session) == m_idFreeSet.end()) {
#ifdef DEBUG
            fprintf(stderr, "getNrpDevice [%d]: disconnected\n", session);
#endif
            throw NrpException(NRP_ERROR_USB_DISCONNECTED);
        }
#ifdef DEBUG
        fprintf(stderr, "getNrpDevice [%d]: not in used\n", session);
#endif
        throw NrpException(NRP_ERROR_INVALID_SESSION);
    }

    if (!nrpdev->getUsbDevice().isOpen()) {
#ifdef DEBUG
        fprintf(stderr, "getNrpDevice [%d]: not open\n", session);
#endif
        throw NrpException(NRP_ERROR_INVALID_SESSION);
    }
    // lock access to device
    nrpdev_sync = nrpdev->m_mutex;

    return nrpdev;
}

long NrpDevList::getUsageMap(char *cpMap, unsigned long nMapSize, unsigned long *pulRetSize)
{
    struct timespec ts;
    char *ptr = cpMap;

    if (! clock_gettime(CLOCK_REALTIME, &ts)) {
        ts.tv_sec += 1;

        if (! sem_timedwait(&m_shmData->sem, &ts)) {
            // semaphore got locked

            for (size_t i = 0; i < (sizeof(m_shmData->sensors) / sizeof(m_shmData->sensors[0])); ++i) {
                if (m_shmData->sensors[i].in_use) {
                    NrpOpenSensorInfo& sensorInfo = m_shmData->sensors[i];

                    if (! kill(sensorInfo.pid, 0)) {
                        char szProcPath[PATH_MAX];
                        snprintf(szProcPath, sizeof(szProcPath), "/proc/%d/cmdline", sensorInfo.pid);

                        int fd = open(szProcPath, O_RDONLY);
                        if (fd < 0)
                            continue;

                        char szCmdLine[PATH_MAX];
                        if (read(fd, szCmdLine, sizeof(szCmdLine)) < 0) {
                            close(fd);
                            continue;
                        }
                        close(fd);

                        char szEntry[1024];
                        snprintf(szEntry, 
                                sizeof(szEntry), 
                                "USB::0x%04lx::0x%04lx::%s <-- %s (PID: %d)\n",
                                sensorInfo.vendor,
                                sensorInfo.product,
                                sensorInfo.serial,
                                szCmdLine,
                                sensorInfo.pid);

                        if (strlen(szEntry) < (nMapSize - (ptr - cpMap))) {
                            strcat(ptr, szEntry);
                            ptr += strlen(szEntry);
                        }
                    }
                }
            }
            sem_post(&m_shmData->sem);

            if (pulRetSize)
                *pulRetSize = (unsigned long)(ptr - cpMap);

            return NRP_SUCCESS;
        }
    }
    // clock_gettime or sem_timedwait failed
    return NRP_ERROR_TIMEOUT;
}

//
// Initialize the nrp device list manager
//
NrpDevList::NrpDevList() : m_thread("nrpdev"), m_devCnt(0), m_sessionCnt(0), m_maxRootHub(0), m_maxPort(0), m_shmData(NULL), m_disableFirmwareLoad(0), m_nrpz5(0)
{
    int	ret;
    struct udev_list_entry *devices, *dev_list_entry;
    struct udev_enumerate *enumerate;

    int shm_fd = -1;

    if ((shm_fd = shm_open("/nrpusagemap", O_RDWR | O_CREAT, S_IRWXU | S_IRWXG | S_IRWXO)) < 0)
        throw("cannot open shared memory");

    fchmod(shm_fd, S_IRWXU | S_IRWXG | S_IRWXO);

    if (ftruncate(shm_fd, sizeof(NrpShmData)))
        throw("allocation of shm failed");
    m_shmData = (NrpShmData*)mmap(0, sizeof(NrpShmData), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    close(shm_fd);

    if (! m_shmData->init) {
        if (! sem_init(&m_shmData->sem, 1, 1)) {
            m_shmData->init = true;
        } else {
            throw("cannot initialize semaphore");
        }
    }

#if 0
    //
    // test if driver is loaded and accessable
    //
    if (access(SYS_USB_DRIVER_NODE "/" DRIVER_NAME, R_OK|X_OK))
        throw("cannot access " SYS_USB_DRIVER_NODE "/" DRIVER_NAME " - possible reason: driver not loaded");
#endif

    if (pipe2(m_pipe, O_NONBLOCK|O_CLOEXEC))
        throw("cannot connect to pipe");

    m_udev = udev_new();
    if (!m_udev)
        throw("Can't create udev\n");

    m_udevmon = udev_monitor_new_from_netlink(m_udev, "udev");
    if (!m_udevmon)
        throw("Can't monitor udev\n");

    m_devices.reserve(1);

    enumerate = udev_enumerate_new(m_udev);

    udev_enumerate_add_match_subsystem(enumerate, "usb");
    udev_enumerate_add_match_subsystem(enumerate, "usbmisc");

    udev_enumerate_scan_devices(enumerate);
    devices = udev_enumerate_get_list_entry(enumerate);

    udev_list_entry_foreach(dev_list_entry, devices) {
        const char *path;
        struct udev_device *dev;

        path = udev_list_entry_get_name(dev_list_entry);
        dev = udev_device_new_from_syspath(m_udev, path);

        addDevice(dev);

        udev_device_unref(dev);
    }
    udev_enumerate_unref(enumerate);

    m_udevfd = udev_monitor_get_fd(m_udevmon);
    udev_monitor_filter_add_match_subsystem_devtype(m_udevmon, "usb", NULL);
    udev_monitor_filter_add_match_subsystem_devtype(m_udevmon, "usbmisc", NULL);
    udev_monitor_enable_receiving(m_udevmon);

    ret = m_thread.start(dispatchHelper, this);

    if (ret) {
        udev_monitor_filter_remove(m_udevmon);
        udev_unref(m_udev);

        close(m_pipe[0]);
        close(m_pipe[1]);

        throw("thread creation failed");
    }

    m_thread.wait();
}

//
// cleanup the nrp device list manager
//
NrpDevList::~NrpDevList()
{
    Synchronize nrplist_sync(m_mutex);

    m_thread.cancel();

    udev_monitor_filter_remove(m_udevmon);
    udev_monitor_unref(m_udevmon);
    udev_unref(m_udev);

    for(WaitDeviceListIter p = m_waitDevices.begin(); p != m_waitDevices.end(); ++p)
        udev_device_unref(*p);
    m_waitDevices.clear();

    close(m_pipe[0]);
    close(m_pipe[1]);

    // clear the device list
    m_devList.clear();

    //    shm_unlink("/nrpusagemap");
}

/* vi:set ts=4 sw=4: */

