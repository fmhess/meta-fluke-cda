# nrpzmodule
This is the Linux kernel module required to operate Rohde & Schwarz NRP series power meters on a Linux machine. The counterpart of this module in userspace is the libnrp library which should be bundled with this module.

## Building

To build the kernel module for the **currently running kernel**, you only need to run:

```
make
```

In order to cross-compile the module for a **different kernel**, you'll need to supply the kernel build directory:

```
make KDIR=<path to kernel root>/build
```

Make sure to set the CC environment variable to match the kernel's target architecture.

## Installing

Run the make command from the Building section using the install target:

```
make install
# or
make KDIR=<path to kernel root>/build install
```
