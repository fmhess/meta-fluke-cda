/*****************************************************************************/
/**
@file           
                \b $Source: \NRP-Software\Linux\NrpRemCtrlDrv\WinEvent.cpp $
@copyright      (c) Rohde & Schwarz GmbH & Co. KG, Munich
@version        \$Revision:  $
*
@author         Richard Dengler
@responsible    \$Author: geltinge $
*
@language       C++
*
@brief          Windows events emulation 
*
@description    Emulates odd windows events. Essential classes used for this
*               purpose are CBaseHandle, CWinEventHandle and CWinEventHandleSet
*               (defined in this file)
*
@see            
*
@history
*  \$Log: WinEvent.cpp $
*
*
*******************************************************************************
******************************************************************************/

#if !defined(WIN32)

#include <sys/time.h>
#include <set>
#include <string>
#include <assert.h>
#include <unistd.h>
#include "winEmul.h"
#include "CWinEventHandle.h"

using std::string;

static CCriticalSection s_CritSect;

#if defined(__APPLE__)

#include <mach/mach_time.h>

// return time stamp in milliseconds
uint64_t GetTickCount( void )
{
	const  int64_t                   kOneMillion = 1000 * 1000;
	static mach_timebase_info_data_t s_timebase_info;

	if( s_timebase_info.denom == 0 )
		(void) mach_timebase_info( &s_timebase_info );

	// mach_absolute_time() returns billionth of seconds,
	// so divide by one million to get milliseconds
	return (uint64_t)((mach_absolute_time() * s_timebase_info.numer) / (kOneMillion * s_timebase_info.denom));
}

#else

unsigned long GetTickCount( void )
{
    static long long llLastCall = 0;
    unsigned long dwRet = 0;
    struct timeval  sTime;

    gettimeofday( &sTime, 0 );

    /* Computing Milliseconds since EPOCH... */
    long long llMilli;
    llMilli  = sTime.tv_sec;
    llMilli *= 1000;
    llMilli += sTime.tv_usec / 1000;

    if ( 0 == llLastCall )
    {
        llLastCall = llMilli;
        dwRet      = 0;
    }
    else
    {
        dwRet = (unsigned long)(llMilli - llLastCall);
    }

    return dwRet;
}

#endif



class CEventLock
{
public:
  CEventLock() { s_CritSect.enter(); }
  ~CEventLock() { s_CritSect.leave(); }
};

/* CLASS DECLARATION **********************************************************/
/**
  Administrates a std::set of CWinEventHandle objects.
  Must be possible to find a CWinEventHandle by name.
  (std::map not very helpful: There are CWinEventHandles without a name, and
  name is stored in CWinEventHandle).
*******************************************************************************/
class CWinEventHandleSet
{
public:
  typedef std::set<CWinEventHandle*> TWinEventHandleSet;
  static CBaseHandle* createEvent(bool manualReset, bool signaled, const WCHAR* name)
  {
    CWinEventHandle* handle = new CWinEventHandle(manualReset, signaled, name);
    CEventLock lock;//
    s_Set.insert(handle);
    return handle;
  }
  static void closeHandle(CWinEventHandle* eventHandle)
  {
    CEventLock lock;//
    if (eventHandle->decRefCount() <= 0)
    {
      // ToDo: Inform/wakeup waiting threads ? !
      s_Set.erase(eventHandle);
      delete eventHandle;
    }
  }
  static HANDLE openEvent(const WCHAR* name)
  {
    CEventLock lock;//
    for (TWinEventHandleSet::iterator iter(s_Set.begin()); iter != s_Set.end(); iter++)
    {
      if ((*iter)->name() == name)
      {
        (*iter)->incRefCount();
        return *iter;
      }
    }
    return NULL;
  }
private:
  static TWinEventHandleSet s_Set; // Set of CWinEventHandle's
};
CWinEventHandleSet::TWinEventHandleSet CWinEventHandleSet::s_Set;

/* METHOD *********************************************************************/
/**
 Called from CloseHandle(HANDLE) when the HANDLE refers to an event.
 Decrements the reference count. If the becomes zero: Removes the handle from
 CWinEventHandleSet, deletes the event.
*
@return true
*******************************************************************************/
bool CWinEventHandle::close()
{
  CWinEventHandleSet::closeHandle(this);
  // Note: "this" may be deleted now!
  return true;
}

/* FUNCTION *******************************************************************/
/**
  See MSDN
*******************************************************************************/
HANDLE CreateEvent(LPSECURITY_ATTRIBUTES, BOOL bManualReset, BOOL bInitialState, LPCWSTR lpName)
{
    // if _UNICODE is defined W becomes T
    return CWinEventHandleSet::createEvent(bManualReset, bInitialState, lpName);
}

HANDLE CreateEventA(LPSECURITY_ATTRIBUTES, BOOL bManualReset, BOOL bInitialState, const char *pszName)
{
  return CWinEventHandleSet::createEvent(bManualReset, bInitialState, pszName);
}

HANDLE WINAPI OpenEvent(DWORD dwDesiredAccess, BOOL bInheritHandle, LPCWSTR lpName)
{
	dwDesiredAccess=dwDesiredAccess;
	bInheritHandle=bInheritHandle;
  return CWinEventHandleSet::openEvent(lpName);
}

BOOL CloseHandle(HANDLE handle)
{
  bool ret(false);
  if (handle != NULL)
  {
    CBaseHandle* baseHandle(static_cast<CBaseHandle*>(handle));
    if (!baseHandle->close())
    {
      //printf("Closing unknown HANDLE type\n");
    }
    ret = true;
  }
  return ret;
}

BOOL WINAPI SetEvent(HANDLE hEvent)
{
  CEventLock lock; //The lock avoids a race condition with subscribe() in WaitForMultipleObjects()//
  dynamic_cast<CWinEventHandle*>(hEvent)->signal();
  return true;
}

BOOL ResetEvent(HANDLE hEvent)
{
  dynamic_cast<CWinEventHandle*>(hEvent)->reset();
  return true;
}

BOOL PulseEvent(HANDLE hEvent)
{
  return dynamic_cast<CWinEventHandle*>(hEvent)->pulse();
}

/* FUNCTION *******************************************************************/
/**
  See MSDN
*******************************************************************************/
DWORD WINAPI WaitForSingleObject(HANDLE obj, DWORD timeMs)
{
  CBaseHandle* handle(static_cast<CBaseHandle*>(obj));
  if (handle->wait(timeMs))
  {
    return WAIT_OBJECT_0;
  }
  // Might be handle of wrong type?
  return WAIT_TIMEOUT;
}


/* FUNCTION *******************************************************************/
/**
  See MSDN.
*******************************************************************************/
DWORD WINAPI WaitForMultipleObjects( DWORD numObj, const HANDLE* objs, BOOL waitAll, DWORD timeMs )
{
  static const DWORD MAXIMUM_WAIT_OBJECTS(32);
  CWinEventHandle* eventHandle[ MAXIMUM_WAIT_OBJECTS ];
  assert( numObj <= MAXIMUM_WAIT_OBJECTS );

  if ( waitAll )
  {
    unsigned long ulNow;
    unsigned long ulEnd;
    
    ulNow = GetTickCount();
    if ( (timeMs != 0) && (timeMs != INFINITE) )
      ulEnd = ulNow + timeMs;
    else
      ulEnd = ulNow + (1000 * 60 * 60 * 24);  // 24h is INFINITE for us here ;-)
      
    bool boAllDone = false;
    while ( ! boAllDone && (GetTickCount() < ulEnd) )
    {
      boAllDone = true;
      
      s_CritSect.enter();

      // Check whether an event is already signaled
      for ( unsigned ix(0); ix < numObj; ix++ )
      {
        CWinEventHandle* event( dynamic_cast<CWinEventHandle*>( objs[ ix ] ) );
        assert( event );
        if ( ! event->signaled() )
        {
          boAllDone = false;
          break;
        }
      } // for all events
      s_CritSect.leave();
      
      if ( ! boAllDone )
        usleep( 1000 );
        
    } // while
    
    if ( ! boAllDone )
      return WAIT_TIMEOUT;

    return 0;

  } // waitAll


  
  s_CritSect.enter();
  // Check whether an event is already signaled
  for (unsigned ix(0); ix < numObj; ix++)
  {
    CWinEventHandle* event(dynamic_cast<CWinEventHandle*>(objs[ix]));
    assert(event);
    if (event->signaled())
    {
      s_CritSect.leave();
      return ix;
    }
    eventHandle[ix] = event;
  }
  if (timeMs == 0)
  {
    // Only check, do not wait. Has already failed, see above.
    s_CritSect.leave();
    return WAIT_TIMEOUT;
  }

  /***************************************************************************
  Main use case: No event signaled yet, create a subscriber event.
  ***************************************************************************/
  CWinEventHandle subscriberEvent(false, 0);
  // Subscribe at the original objects
  for (unsigned ix(0); ix < numObj; ix++)
  {
    eventHandle[ix]->subscribe(&subscriberEvent);
  }
  s_CritSect.leave();// This re-enables SetEvent(). OK since the subscription is done $

  bool success(subscriberEvent.wait(timeMs));

  // Unsubscribe and determine return value
  DWORD ret(WAIT_TIMEOUT);
  s_CritSect.enter();
  for (unsigned ix(0); ix < numObj; ix++)
  {
    if (success && eventHandle[ix]->signaled())
    {
      success = false;
      ret = ix;
    }
    eventHandle[ix]->unSubscribe(&subscriberEvent);
  }
  s_CritSect.leave();
  return ret;
}

#endif // !defined(__APPLE__)

