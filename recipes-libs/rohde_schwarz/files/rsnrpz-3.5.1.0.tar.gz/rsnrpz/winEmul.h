/*****************************************************************************/
/**
@file           
                \b $Source: \NRP-Software\Linux\NrpRemCtrlDrv\winEmul.h $
@copyright      (c) Rohde & Schwarz GmbH & Co. KG, Munich
@version        \$Revision:  $
*
@author         Richard Dengler
@responsible    \$Author: geltinge $
*
@language       C++
*
@brief           
*
@description    Defines/types/declarations, mainly from windows header files 
@see            
*
@history
*  \$Log: winEmul.h $
*
*
*******************************************************************************
******************************************************************************/
#ifndef WINEMUL_H
#define WINEMUL_H

//#if defined (__APPLE__)
//#include "windowsdef.h"
//#else

#include <pthread.h>

#if defined(_DEBUG) || defined(DEBUG)
#include <errno.h>
#include <stdio.h>
#include <string.h>
#endif

#define WINAPI
#define WINBASEAPI
#define CONST const
#define TRUE  (1)
#define FALSE (0)

#define STATUS_WAIT_0   ((DWORD)0x00000000L)
#define STATUS_TIMEOUT  ((DWORD)0x00000102L)

#define WAIT_TIMEOUT    STATUS_TIMEOUT
#define WAIT_OBJECT_0   ((STATUS_WAIT_0 ) + 0 )
#define INFINITE        0xFFFFFFFF    // Infinite timeout

typedef unsigned long DWORD;
typedef unsigned int  UINT;
typedef int BOOL;
typedef struct  tag_SECURITY_ATTRIBUTES
{
    BOOL bInheritHandle;
} SECURITY_ATTRIBUTES;
typedef SECURITY_ATTRIBUTES* LPSECURITY_ATTRIBUTES;

//typedef wchar_t WCHAR; // Note: sizeof(wchar_t) == 4!
//typedef char WCHAR;
#define WCHAR char
typedef CONST WCHAR* LPCWSTR;

/*******************************************************************************
Opaque, polymorphal HANDLE. Base class. Used internally.
*******************************************************************************/
class CBaseHandle
{
public:
  CBaseHandle() {}
  virtual ~CBaseHandle() {}
  virtual bool wait(unsigned numMs) { numMs=numMs; return false; }
  virtual bool close() { return false; }
};

typedef CBaseHandle* HANDLE;

WINBASEAPI DWORD  WINAPI WaitForSingleObject( HANDLE hHandle, DWORD dwMilliseconds );
WINBASEAPI DWORD  WINAPI WaitForMultipleObjects( DWORD nCount, CONST HANDLE *lpHandles, BOOL bWaitAll, DWORD dwMilliseconds );
WINBASEAPI BOOL   WINAPI SetEvent( HANDLE hEvent );
WINBASEAPI BOOL   WINAPI ResetEvent( HANDLE hEvent );
WINBASEAPI BOOL   WINAPI PulseEvent( HANDLE hEvent );  // Used in CRsEvent.cpp
WINBASEAPI HANDLE WINAPI CreateEvent( LPSECURITY_ATTRIBUTES lpEventAttributes, BOOL bManualReset, BOOL bInitialState, LPCWSTR lpName );
WINBASEAPI HANDLE WINAPI CreateEventA( LPSECURITY_ATTRIBUTES lpEventAttributes, BOOL bManualReset, BOOL bInitialState, const char *pszName );
WINBASEAPI HANDLE WINAPI OpenEvent(DWORD dwDesiredAccess, BOOL bInheritHandle, LPCWSTR lpName);
WINBASEAPI BOOL   WINAPI CloseHandle(HANDLE hObject);




class CCriticalSection
{
  bool            m_bConstructed;
  pthread_mutex_t m_Mutex;
public:
  CCriticalSection(bool recursive = true) : m_bConstructed(false)
  {
    Constructor( recursive );
    
#if defined(_DEBUG) || defined(DEBUG)
    fprintf(stderr, "*****> CCriticalSection::CCriticalSection() this = %p\n", this ); 
#endif
  }

  void Constructor(bool recursive = true)
  {
    if ( m_bConstructed )
    {
#if defined(_DEBUG) || defined(DEBUG)
      fprintf(stderr, "*****> CCriticalSection already contructed  this = %p\n", this ); 
#endif
      return;
    }

#if defined(_DEBUG) || defined(DEBUG)
    fprintf(stderr, "*****> CCriticalSection::Constructor()      this = %p\n", this ); 
#endif

    m_bConstructed = true;

    if (recursive)
    {
      int iRes = 0;
      pthread_mutexattr_t attr;

      iRes = pthread_mutexattr_init(&attr);

#if defined(_DEBUG) || defined(DEBUG)
      if (iRes) fprintf(stderr, "pthread_mutexattr_init failed with %s\n", strerror(iRes)); 
#endif

#if defined(__APPLE__)
      iRes = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
#else
      iRes = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP);
#endif

#if defined(_DEBUG) || defined(DEBUG)
      if (iRes) fprintf(stderr, "pthread_mutexattr_init failed with %s\n", strerror(iRes)); 
#endif

      iRes = pthread_mutex_init(&m_Mutex, &attr);

#if defined(_DEBUG) || defined(DEBUG)
      if (iRes) fprintf(stderr, "pthread_mutex_init failed with %s\n", strerror(iRes));
#endif
    }
    else
    {
      pthread_mutex_init(&m_Mutex, 0);
    }
  }

  void Destructor( void )
  {
    if ( m_bConstructed )
    {
      pthread_mutex_destroy(&m_Mutex);

      m_bConstructed = false;

#if defined(_DEBUG) || defined(DEBUG)
      fprintf(stderr, "*****> CCriticalSection::Destructor()        this = %p\n", this ); 
#endif
    }
    else
    {
#if defined(_DEBUG) || defined(DEBUG)
      fprintf(stderr, "*****> CCriticalSection::already destructed  this = %p\n", this ); 
#endif
    }
  }


  ~CCriticalSection()
  {
#if defined(_DEBUG) || defined(DEBUG)
    fprintf(stderr, "*****> CCriticalSection::~CCriticalSection() this = %p\n", this ); 
#endif

    Destructor();
  }

#if defined(__APPLE__)
  void enter()
  {
      int iRes = pthread_mutex_lock(&m_Mutex);
#if defined(_DEBUG) || defined(DEBUG)
      if ( iRes == EDEADLK )
		  fprintf( stderr, "### lock() -> EDEADLK\n" );
	  else if ( iRes == EINVAL )
		  fprintf( stderr, "### lock() -> EINVAL\n" );
#endif	  
  }
  void leave()
  {
      int iRes = pthread_mutex_unlock(&m_Mutex);
#if defined(_DEBUG) || defined(DEBUG)
      if ( iRes == EPERM )
		  fprintf( stderr, "### unlock() -> EPERM\n" );
	  else if ( iRes == EINVAL )
		  fprintf( stderr, "### unlock() -> EINVAL\n" );
#endif	  
  }
#else
  inline void enter() { pthread_mutex_lock(&m_Mutex); }
  inline void leave() { pthread_mutex_unlock(&m_Mutex); }
#endif
};

#define CRITICAL_SECTION CCriticalSection
inline void EnterCriticalSection( CRITICAL_SECTION *pCS )
{
    pCS->enter();
}
inline void LeaveCriticalSection( CRITICAL_SECTION *pCS )
{
    pCS->leave();
}
//#define InitializeCriticalSection(x)
//#define DeleteCriticalSection(x)

inline void InitializeCriticalSection( CRITICAL_SECTION *pCS )
{
  pCS->Constructor();
}

inline void DeleteCriticalSection( CRITICAL_SECTION *pCS )
{
  pCS->Destructor();
}

inline BOOL IsBadReadPtr( void *p, size_t s )
{
    if ( (p == 0) || (s == 0) )
        return TRUE;
    return FALSE;
}

inline BOOL IsBadWritePtr( void *p, size_t s )
{
    return IsBadReadPtr( p, s );
}

#endif

